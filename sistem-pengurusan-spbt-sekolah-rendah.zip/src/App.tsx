import { useState, useEffect } from 'react';
import { Book, Pupil, Loan, SystemData, UserAccount } from './types';
import { defaultBooks, defaultPupils, defaultLoans, defaultUsers } from './data/defaultData';
import { fetchFromGoogleSheet, pushToGoogleSheet } from './utils/googleSheetsSync';

// Lucide Icons
import { 
  LayoutDashboard, 
  UserPlus, 
  BookMarked, 
  ArrowLeftRight, 
  CheckSquare, 
  TrendingUp, 
  Archive, 
  Link2,
  Calendar,
  Sun,
  Moon,
  Zap,
  ChevronDown,
  ChevronUp,
  School,
  ArrowRight,
  LogOut,
  Users
} from 'lucide-react';

// Components
import Dashboard from './components/Dashboard';
import DaftarMurid from './components/DaftarMurid';
import UrusBuku from './components/UrusBuku';
import PinjamBuku from './components/PinjamBuku';
import PulangBuku from './components/PulangBuku';
import ProfilMuridView from './components/ProfilMuridView';
import LaporanSPBTView from './components/LaporanSPBTView';
import ArkibView from './components/ArkibView';
import GoogleSheetsConfig from './components/GoogleSheetsConfig';
import LoginScreen from './components/LoginScreen';
import DaftarPengguna from './components/DaftarPengguna';
import PrintModal from './components/PrintModal';

export default function App() {
  // Authentication State
  const [isLoggedIn, setIsLoggedIn] = useState<boolean>(() => localStorage.getItem('spbt_logged_in') === 'true');

  // Navigation State
  const [activeTab, setActiveTab] = useState<string>('dashboard');
  const [selectedProfilePupil, setSelectedProfilePupil] = useState<Pupil | null>(null);

  // Core SPBT Data State
  const [books, setBooks] = useState<Book[]>([]);
  const [pupils, setPupils] = useState<Pupil[]>([]);
  const [loans, setLoans] = useState<Loan[]>([]);
  const [currentSession, setCurrentSession] = useState<string>('2026');
  const [users, setUsers] = useState<UserAccount[]>([]);

  // Theme State
  const [isDarkMode, setIsDarkMode] = useState<boolean>(false);

  // Printing Job State
  const [activePrintJob, setActivePrintJob] = useState<{
    type: 'individu-pinjam' | 'individu-pulang' | 'pukal-pinjam' | 'pukal-pulang';
    pupilId?: string;
    year?: number;
  } | null>(null);

  // Logout Confirmation State (Custom modal to replace window.confirm)
  const [showLogoutConfirm, setShowLogoutConfirm] = useState<boolean>(false);

  // Google Sheets Sync State
  const [googleSheetUrl, setGoogleSheetUrl] = useState<string>('');
  const [syncStatus, setSyncStatus] = useState<'idle' | 'syncing' | 'success' | 'error'>('idle');
  const [lastSyncDate, setLastSyncDate] = useState<string | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  // Modal Sesi
  const [showSessionModal, setShowSessionModal] = useState<boolean>(false);

  // --- INITIAL LOAD & SYNCHRONIZATION ---
  useEffect(() => {
    // 1. Ambil pilihan Tema
    const savedTheme = localStorage.getItem('spbt_theme');
    if (savedTheme === 'dark') {
      setIsDarkMode(true);
    }

    // 2. Muat naik data tempatan (local storage)
    const localDataRaw = localStorage.getItem('spbt_database');
    const localUrl = localStorage.getItem('spbt_sheets_url') || '';
    setGoogleSheetUrl(localUrl);

    let initialDataLoaded = false;
    if (localDataRaw) {
      try {
        const parsed = JSON.parse(localDataRaw) as SystemData;
        if (parsed.books && parsed.pupils && parsed.loans) {
          setBooks(parsed.books);
          setPupils(parsed.pupils);
          setLoans(parsed.loans);
          setCurrentSession(parsed.currentSession || '2026');
          setUsers(parsed.users && parsed.users.length > 0 ? parsed.users : defaultUsers);
          initialDataLoaded = true;
        }
      } catch (e) {
        console.error('Gagal membaca data dari Local Storage. Memulihkan default.', e);
      }
    }

    if (!initialDataLoaded) {
      // Jika kosong, seadikan data lalai mesra sekolah
      setBooks(defaultBooks);
      setPupils(defaultPupils);
      setLoans(defaultLoans);
      setCurrentSession('2026');
      setUsers(defaultUsers);
      
      const payload: SystemData = {
        books: defaultBooks,
        pupils: defaultPupils,
        loans: defaultLoans,
        currentSession: '2026',
        users: defaultUsers
      };
      localStorage.setItem('spbt_database', JSON.stringify(payload));
    }

    // 3. Tarik data secara automatik jika URL Sheets sedia dikonfigurasi
    if (localUrl) {
      autoPullOnStart(localUrl);
    }
  }, []);

  // --- PERSISTENCE TO LOCAL STORAGE & SHEETS ---
  const saveAndSyncData = async (
    updatedBooks: Book[], 
    updatedPupils: Pupil[], 
    updatedLoans: Loan[], 
    sessionToSave: string,
    updatedUsers: UserAccount[] = users
  ) => {
    // Simpan ke local storage serta-merta
    const payload: SystemData = {
      books: updatedBooks,
      pupils: updatedPupils,
      loans: updatedLoans,
      currentSession: sessionToSave,
      users: updatedUsers
    };
    localStorage.setItem('spbt_database', JSON.stringify(payload));

    // Jika bersambung ke Google Sheets, hantar laporan segerak di belakang tab
    if (googleSheetUrl) {
      setSyncStatus('syncing');
      try {
        const success = await pushToGoogleSheet(googleSheetUrl, payload);
        if (success) {
          setSyncStatus('success');
          setLastSyncDate(new Date().toLocaleTimeString('ms-MY', { hour: '2-digit', minute: '2-digit', second: '2-digit' }));
          setErrorMessage(null);
        } else {
          setSyncStatus('error');
          setErrorMessage('Google Sheets menolak kemas kini data. Semak semula persediaan Apps Script.');
        }
      } catch (err: any) {
        setSyncStatus('error');
        setErrorMessage(err.message || 'Gagal menghantar data. Sila semak pautan Apps Script anda.');
      }
    }
  };

  const autoPullOnStart = async (url: string) => {
    setSyncStatus('syncing');
    try {
      const remoteData = await fetchFromGoogleSheet(url);
      if (remoteData && remoteData.books && remoteData.pupils && remoteData.loans) {
        setBooks(remoteData.books);
        setPupils(remoteData.pupils);
        setLoans(remoteData.loans);
        setCurrentSession(remoteData.currentSession || '2026');
        if (remoteData.users && remoteData.users.length > 0) {
          setUsers(remoteData.users);
        }
        setSyncStatus('success');
        setLastSyncDate(new Date().toLocaleTimeString('ms-MY', { hour: '2-digit', minute: '2-digit' }));
        setErrorMessage(null);

        // Kemaskini simpanan tempatan
        localStorage.setItem('spbt_database', JSON.stringify(remoteData));
      }
    } catch (err: any) {
      setSyncStatus('error');
      setErrorMessage('Penyelarasan automatik gagal. Aplikasi menggunakan storan peranti.');
    }
  };

  // --- MANUAL ACTIONS FOR SHEET SYNC ---
  const handleManualPull = async () => {
    if (!googleSheetUrl) {
      alert('Sila isi alamat pautan Google Apps Script terlebih dahulu!');
      return;
    }
    setSyncStatus('syncing');
    try {
      const remote = await fetchFromGoogleSheet(googleSheetUrl);
      if (remote && remote.books && remote.pupils && remote.loans) {
        setBooks(remote.books);
        setPupils(remote.pupils);
        setLoans(remote.loans);
        setCurrentSession(remote.currentSession || '2026');
        if (remote.users && remote.users.length > 0) {
          setUsers(remote.users);
        }
        setSyncStatus('success');
        setLastSyncDate(new Date().toLocaleTimeString('ms-MY'));
        setErrorMessage(null);
        
        localStorage.setItem('spbt_database', JSON.stringify(remote));
        alert('Data Google Sheets BERJAYA ditarik sepenuhnya ke peranti ini!');
      } else {
        throw new Error('Siri data tidak lengkap.');
      }
    } catch (err: any) {
      setSyncStatus('error');
      setErrorMessage(err.message || 'Gagal menarik data dari Sheets.');
      alert(`Ralat tarik data: ${err.message || 'Sila semak semula Web App URL'}`);
    }
  };

  const handleManualPush = async () => {
    if (!googleSheetUrl) {
      alert('Sila isi alamat pautan Google Apps Script terlebih dahulu!');
      return;
    }
    setSyncStatus('syncing');
    const payload: SystemData = { books, pupils, loans, currentSession, users };
    try {
      const success = await pushToGoogleSheet(googleSheetUrl, payload);
      if (success) {
        setSyncStatus('success');
        setLastSyncDate(new Date().toLocaleTimeString('ms-MY'));
        setErrorMessage(null);
        alert('Seluruh data di peranti ini BERJAYA dieksport dan ditimpa di Google Sheets anda!');
      } else {
        throw new Error('Apps Script mengembalikan ralat.');
      }
    } catch (err: any) {
      setSyncStatus('error');
      setErrorMessage(err.message || 'Gagal menghantar data.');
      alert(`Ralat hantar data: ${err.message}`);
    }
  };

  const handleSaveSheetUrl = (url: string) => {
    setGoogleSheetUrl(url);
    localStorage.setItem('spbt_sheets_url', url);
    autoPullOnStart(url);
  };

  // --- USER ACCESS MANAGEMENT HANDLERS ---
  const handleAddUser = (username: string, name: string, role: 'Guru Penyelaras' | 'Pengawas SPBT', password: string) => {
    const newUser: UserAccount = {
      id: 'U-' + Math.random().toString(36).substr(2, 9).toUpperCase(),
      username,
      name,
      role,
      password
    };
    const updated = [...users, newUser];
    setUsers(updated);
    saveAndSyncData(books, pupils, loans, currentSession, updated);
  };

  const handleDeleteUser = (id: string) => {
    const updated = users.filter(u => u.id !== id);
    setUsers(updated);
    saveAndSyncData(books, pupils, loans, currentSession, updated);
  };

  // --- SYSTEM LOGIC ACTIONS ---

  // 1. Pendaftaran Murid Baru
  const handleAddPupil = (name: string, year: number, className: string) => {
    const newPupil: Pupil = {
      id: 'P-' + Math.random().toString(36).substr(2, 9).toUpperCase(),
      name,
      year,
      className,
      session: currentSession,
      isArchived: false
    };

    const updated = [newPupil, ...pupils];
    setPupils(updated);
    saveAndSyncData(books, updated, loans, currentSession);
  };

  const handleEditPupil = (id: string, name: string, year: number, className: string) => {
    const updated = pupils.map(p => {
      if (p.id === id) {
        return { ...p, name, year, className };
      }
      return p;
    });
    setPupils(updated);
    saveAndSyncData(books, updated, loans, currentSession);
  };

  const handleDeletePupil = (id: string) => {
    const updatedPupils = pupils.filter(p => p.id !== id);
    // Cuci rekod pinjaman murid ini sekali
    const updatedLoans = loans.filter(l => l.pupid !== id && l.pupilId !== id);
    
    setPupils(updatedPupils);
    setLoans(updatedLoans);
    saveAndSyncData(books, updatedPupils, updatedLoans, currentSession);
  };

  const handleClearAllData = () => {
    setPupils([]);
    setLoans([]);
    saveAndSyncData(books, [], [], currentSession);
  };

  // 2. Pengurusan Buku SPBT
  const handleAddBook = (title: string, year: number) => {
    const newBook: Book = {
      id: `B${year}-` + Math.random().toString(36).substr(2, 4).toUpperCase(),
      title,
      year
    };

    const updated = [...books, newBook];
    setBooks(updated);
    saveAndSyncData(updated, pupils, loans, currentSession);
  };

  const handleEditBook = (id: string, title: string, year: number) => {
    const updated = books.map(b => {
      if (b.id === id) {
        return { ...b, title, year };
      }
      return b;
    });
    setBooks(updated);
    saveAndSyncData(updated, pupils, loans, currentSession);
  };

  const handleDeleteBook = (id: string) => {
    const updatedBooks = books.filter(b => b.id !== id);
    // Cuci pinjaman berkemungkinan
    const updatedLoans = loans.filter(l => l.bookId !== id);
    
    setBooks(updatedBooks);
    setLoans(updatedLoans);
    saveAndSyncData(updatedBooks, pupils, updatedLoans, currentSession);
  };

  // 3. Peminjaman Buku (Tanda dan Cabut)
  const handleUpdateLoanStatus = (pupilId: string, bookId: string, status: 'Belum Dipinjam' | 'Dipinjam', date: string | null) => {
    // Semak jika rekod pinjaman sedia ada
    const existingLoanIndex = loans.findIndex(
      l => l.pupilId === pupilId && l.bookId === bookId && l.session === currentSession
    );

    let updatedLoans = [...loans];

    if (existingLoanIndex > -1) {
      if (status === 'Belum Dipinjam') {
        // Cabut dari pinjaman
        updatedLoans.splice(existingLoanIndex, 1);
      } else {
        // Tukar status
        updatedLoans[existingLoanIndex] = {
          ...updatedLoans[existingLoanIndex],
          status,
          lendDate: date
        };
      }
    } else if (status === 'Dipinjam') {
      // Bina pinjaman baru
      const newLoan: Loan = {
        id: 'L-' + Math.random().toString(36).substr(2, 9).toUpperCase(),
        pupilId,
        bookId,
        lendDate: date,
        returnDate: null,
        status: 'Dipinjam',
        session: currentSession
      };
      updatedLoans.push(newLoan);
    }

    setLoans(updatedLoans);
    saveAndSyncData(books, pupils, updatedLoans, currentSession);
  };

  const handleUpdateMultipleLoans = (pupilId: string, bookIds: string[], status: 'Belum Dipinjam' | 'Dipinjam', date: string | null) => {
    let updatedLoans = [...loans];

    bookIds.forEach(bookId => {
      const existingLoanIndex = updatedLoans.findIndex(
        l => l.pupilId === pupilId && l.bookId === bookId && l.session === currentSession
      );

      if (existingLoanIndex > -1) {
        if (status === 'Belum Dipinjam') {
          updatedLoans.splice(existingLoanIndex, 1);
        } else {
          updatedLoans[existingLoanIndex] = {
            ...updatedLoans[existingLoanIndex],
            status,
            lendDate: date
          };
        }
      } else if (status === 'Dipinjam') {
        const newLoan: Loan = {
          id: 'L-' + Math.random().toString(36).substr(2, 9).toUpperCase(),
          pupilId,
          bookId,
          lendDate: date,
          returnDate: null,
          status: 'Dipinjam',
          session: currentSession
        };
        updatedLoans.push(newLoan);
      }
    });

    setLoans(updatedLoans);
    saveAndSyncData(books, pupils, updatedLoans, currentSession);
  };

  // 4. Pemulangan Buku (Kemaskini Status)
  const handleUpdateReturnStatus = (
    loanId: string, 
    status: 'Dipulangkan' | 'Hilang' | 'Rosak' | 'Dipinjam', 
    returnDate: string | null
  ) => {
    const updated = loans.map(l => {
      if (l.id === loanId) {
        return { ...l, status, returnDate };
      }
      return l;
    });

    setLoans(updated);
    saveAndSyncData(books, pupils, updated, currentSession);
  };

  // 5. PESTA NAIK TAHUN / PROMOSI SESI BAHARU
  const handleNewSessionPromote = () => {
    // Sesi baru dibina dengan tambahan tahun akademik
    const oldSession = currentSession;
    const currentYearNum = parseInt(currentSession);
    const nextSession = (isNaN(currentYearNum) ? 2026 : currentYearNum + 1).toString();

    // Promosi Murid
    const updatedPupils = pupils.map(pupil => {
      // Hanya murid aktif dalam sesi sedia ada yang dikonfigurasi
      if (!pupil.isArchived && pupil.session === oldSession) {
        if (pupil.year === 6) {
          // Tahun 6 dipindahkan ke Arkib
          return {
            ...pupil,
            isArchived: true,
            archiveSession: oldSession
          };
        } else {
          // Tahun 1 - 5 naik setahun
          return {
            ...pupil,
            year: pupil.year + 1,
            session: nextSession
          };
        }
      }
      return pupil;
    });

    // Sesi baru ditetapkan
    setCurrentSession(nextSession);
    setPupils(updatedPupils);
    
    // Rekod pinjaman terdahulu selamat disimpan di bawah 'session: oldSession'
    saveAndSyncData(books, updatedPupils, loans, nextSession);
    setShowSessionModal(false);
    setActiveTab('dashboard');
    alert(`Sesi Baharu (${nextSession}) Berjaya Dimulakan!\nSemua murid Tahun 1-5 naik kelas. Murid Tahun 6 telah dialihkan ke Arkib.`);
  };

  // Navigasi Terus Dari Modul Lain ke Profil
  const handleSelectProfilePupil = (pupil: Pupil) => {
    setSelectedProfilePupil(pupil);
    setActiveTab('profil');
  };

  const handleToggleTheme = () => {
    const newTheme = !isDarkMode;
    setIsDarkMode(newTheme);
    localStorage.setItem('spbt_theme', newTheme ? 'dark' : 'light');
  };

  if (!isLoggedIn) {
    return (
      <div className={isDarkMode ? 'dark min-h-screen bg-slate-950 text-slate-100' : 'min-h-screen bg-stone-50/70 text-slate-900'}>
        <LoginScreen onLogin={() => setIsLoggedIn(true)} users={users} />
      </div>
    );
  }

  return (
    <div className={isDarkMode ? 'dark min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-emerald-800 selection:text-white' : 'min-h-screen bg-stone-50/70 text-slate-900 flex flex-col font-sans selection:bg-emerald-100 selection:text-slate-900'}>
      
      {/* 1. Header Atas dengan Estetika Editorial */}
      <header className="bg-white dark:bg-slate-900 border-b border-stone-200 dark:border-slate-800/80 py-4 px-4 sm:px-8 sticky top-0 z-40 shadow-sm print:hidden">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-slate-900 dark:bg-emerald-950 text-white dark:text-emerald-400 rounded-lg border border-slate-800 dark:border-emerald-800/60 shadow-md">
              <School className="w-5 h-5 text-emerald-400" />
            </div>
            <div>
              <h1 className="text-base font-sans font-bold tracking-tight text-slate-900 dark:text-white">
                Sistem Pengurusan SPBT <span className="font-sans text-xs font-semibold uppercase px-2 py-0.5 ml-2 bg-emerald-50 dark:bg-emerald-900/40 text-emerald-700 dark:text-emerald-300 rounded border border-emerald-100 dark:border-emerald-800/30">SK FELDA LUI MUDA</span>
              </h1>
              <p className="text-[10px] text-slate-500 dark:text-slate-400 font-mono tracking-widest uppercase">Sekolah Rendah Kerajaan • Buku Teks Kebangsaan</p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            {/* Status Synced */}
            {googleSheetUrl && (
              <span className={`text-[10px] font-mono font-bold px-3 py-1 rounded-full flex items-center gap-1.5 border transition-all ${
                syncStatus === 'syncing' 
                  ? 'bg-amber-50 text-amber-700 border-amber-200 dark:bg-amber-950/20 dark:text-amber-400' 
                  : syncStatus === 'error'
                    ? 'bg-rose-50 text-rose-700 border-rose-200 dark:bg-rose-950/20 dark:text-rose-400'
                    : 'bg-emerald-50 text-emerald-750 border-emerald-150 dark:bg-emerald-950/20 dark:text-emerald-400'
              }`}>
                <span className={`w-1.5 h-1.5 rounded-full ${syncStatus === 'error' ? 'bg-rose-500' : 'bg-emerald-500 animate-pulse'}`} />
                <span className="hidden sm:inline">Sheets: {syncStatus === 'syncing' ? 'SEGERAK...' : syncStatus === 'error' ? 'RALAT' : 'DISELARAS'}</span>
              </span>
            )}

            {/* Butang Sesi Semasa */}
            <div className="bg-stone-100 dark:bg-slate-800 border border-stone-200/60 dark:border-slate-700/65 px-3 py-1.5 rounded-lg text-xs font-bold text-slate-700 dark:text-slate-300 flex items-center gap-1.5">
              <Calendar className="w-3.5 h-3.5 text-slate-600 dark:text-slate-400" />
              <span>Sesi {currentSession}</span>
            </div>

            {/* Mod Terang / Gelap Toggle */}
            <button
              id="theme_toggle_btn"
              onClick={handleToggleTheme}
              className="p-2 hover:bg-neutral-100 dark:hover:bg-neutral-800 rounded-xl text-neutral-500 hover:text-neutral-900 dark:text-neutral-400 dark:hover:text-white transition-colors cursor-pointer mr-1"
              title="Tukar Mode Gelap/Terang"
            >
              {isDarkMode ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
            </button>

            {/* Butang Log Keluar */}
            <button
              id="logout_btn"
              onClick={() => {
                setShowLogoutConfirm(true);
              }}
              className="text-xs font-bold text-rose-600 dark:text-rose-450 hover:bg-rose-50 dark:hover:bg-rose-950/20 px-3 py-1.5 rounded-lg border border-rose-200/60 dark:border-rose-950/50 cursor-pointer transition-colors flex items-center gap-1.5 shadow-2xs"
              title="Log Keluar"
            >
              <LogOut className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Log Keluar</span>
            </button>
          </div>
        </div>
      </header>      {/* 2. Menu Navigasi Utama dengan Estetika Editorial */}
      <nav className="bg-white/90 dark:bg-slate-900/90 backdrop-blur-md border-b border-stone-200 dark:border-slate-800 px-4 sm:px-8 py-3 sticky top-[73px] z-30 shadow-xs print:hidden overflow-x-auto whitespace-nowrap">
        <div className="max-w-7xl mx-auto flex gap-2 justify-start items-center">
          
          <button
            id="nav_dashboard"
            onClick={() => { setActiveTab('dashboard'); setSelectedProfilePupil(null); }}
            className={`flex items-center gap-1.5 px-4_5 py-2.5 rounded-lg text-xs font-bold transition-all duration-250 cursor-pointer ${
              activeTab === 'dashboard'
                ? 'bg-slate-900 text-white dark:bg-emerald-950 dark:text-emerald-400 border border-slate-900 dark:border-emerald-800 shadow-sm'
                : 'text-slate-650 dark:text-slate-400 hover:bg-stone-100 dark:hover:bg-slate-800/60'
            }`}
          >
            <LayoutDashboard className="w-4 h-4" />
            <span>Dashboard</span>
          </button>

          <button
            id="nav_pinjam"
            onClick={() => { setActiveTab('pinjam'); setSelectedProfilePupil(null); }}
            className={`flex items-center gap-1.5 px-4_5 py-2.5 rounded-lg text-xs font-bold transition-all duration-250 cursor-pointer ${
              activeTab === 'pinjam'
                ? 'bg-slate-900 text-white dark:bg-emerald-950 dark:text-emerald-400 border border-slate-900 dark:border-emerald-800 shadow-sm'
                : 'text-slate-650 dark:text-slate-400 hover:bg-stone-100 dark:hover:bg-slate-800/60'
            }`}
          >
            📚 Peminjaman
          </button>

          <button
            id="nav_pulang"
            onClick={() => { setActiveTab('pulang'); setSelectedProfilePupil(null); }}
            className={`flex items-center gap-1.5 px-4_5 py-2.5 rounded-lg text-xs font-bold transition-all duration-250 cursor-pointer ${
              activeTab === 'pulang'
                ? 'bg-slate-900 text-white dark:bg-emerald-950 dark:text-emerald-400 border border-slate-900 dark:border-emerald-800 shadow-sm'
                : 'text-slate-650 dark:text-slate-400 hover:bg-stone-100 dark:hover:bg-slate-800/60'
            }`}
          >
            📥 Pemulangan
          </button>

          <button
            id="nav_laporan"
            onClick={() => { setActiveTab('laporan'); setSelectedProfilePupil(null); }}
            className={`flex items-center gap-1.5 px-4_5 py-2.5 rounded-lg text-xs font-bold transition-all duration-250 cursor-pointer ${
              activeTab === 'laporan'
                ? 'bg-slate-900 text-white dark:bg-emerald-950 dark:text-emerald-400 border border-slate-900 dark:border-emerald-800 shadow-sm'
                : 'text-slate-650 dark:text-slate-400 hover:bg-stone-100 dark:hover:bg-slate-800/60'
            }`}
          >
            📊 Laporan SPBT
          </button>

          <button
            id="nav_daftar"
            onClick={() => { setActiveTab('daftar'); setSelectedProfilePupil(null); }}
            className={`flex items-center gap-1.5 px-4_5 py-2.5 rounded-lg text-xs font-bold transition-all duration-250 cursor-pointer ${
              activeTab === 'daftar'
                ? 'bg-slate-900 text-white dark:bg-emerald-950 dark:text-emerald-400 border border-slate-900 dark:border-emerald-800 shadow-sm'
                : 'text-slate-650 dark:text-slate-400 hover:bg-stone-100 dark:hover:bg-slate-800/60'
            }`}
          >
            <UserPlus className="w-4 h-4" />
            <span>Pendaftaran Murid</span>
          </button>

          <button
            id="nav_buku"
            onClick={() => { setActiveTab('buku'); setSelectedProfilePupil(null); }}
            className={`flex items-center gap-1.5 px-4_5 py-2.5 rounded-lg text-xs font-bold transition-all duration-250 cursor-pointer ${
              activeTab === 'buku'
                ? 'bg-slate-900 text-white dark:bg-emerald-950 dark:text-emerald-400 border border-slate-900 dark:border-emerald-800 shadow-sm'
                : 'text-slate-650 dark:text-slate-400 hover:bg-stone-100 dark:hover:bg-slate-800/60'
            }`}
          >
            <BookMarked className="w-4 h-4" />
            <span>Urus Buku SPBT</span>
          </button>

          <button
            id="nav_arkib"
            onClick={() => { setActiveTab('arkib'); setSelectedProfilePupil(null); }}
            className={`flex items-center gap-1.5 px-4_5 py-2.5 rounded-lg text-xs font-bold transition-all duration-250 cursor-pointer ${
              activeTab === 'arkib'
                ? 'bg-slate-900 text-white dark:bg-emerald-950 dark:text-emerald-400 border border-slate-900 dark:border-emerald-800 shadow-sm'
                : 'text-slate-650 dark:text-slate-400 hover:bg-stone-100 dark:hover:bg-slate-800/60'
            }`}
          >
            <Archive className="w-4 h-4" />
            <span>Arkib</span>
          </button>

          <button
            id="nav_sheets"
            onClick={() => { setActiveTab('sheets'); setSelectedProfilePupil(null); }}
            className={`flex items-center gap-1.5 px-4_5 py-2.5 rounded-lg text-xs font-bold transition-all duration-250 cursor-pointer ${
              activeTab === 'sheets'
                ? 'bg-slate-900 text-white dark:bg-emerald-950 dark:text-emerald-400 border border-slate-900 dark:border-emerald-800 shadow-sm'
                : 'text-slate-650 dark:text-slate-400 hover:bg-stone-100 dark:hover:bg-slate-800/60'
            }`}
            title="Konfigurasi integrasi Google Sheets"
          >
            <Link2 className="w-4 h-4" />
            <span>Integrasi Sheets</span>
          </button>

          <button
            id="nav_pengguna"
            onClick={() => { setActiveTab('pengguna'); setSelectedProfilePupil(null); }}
            className={`flex items-center gap-1.5 px-4_5 py-2.5 rounded-lg text-xs font-bold transition-all duration-250 cursor-pointer ${
              activeTab === 'pengguna'
                ? 'bg-slate-900 text-white dark:bg-emerald-950 dark:text-emerald-400 border border-slate-900 dark:border-emerald-800 shadow-sm'
                : 'text-slate-650 dark:text-slate-400 hover:bg-stone-100 dark:hover:bg-slate-800/60'
            }`}
            title="Daftar & Urus Pengguna Sistem"
          >
            <Users className="w-4 h-4" />
            <span>Akaun Pengguna</span>
          </button>

          <div className="flex-1" />

          {/* Butang Sesi Sedia Naik */}
          <button
            id="nav_naik_tahun_trigger"
            onClick={() => setShowSessionModal(true)}
            className="flex items-center gap-1.5 bg-rose-50 hover:bg-rose-100/80 text-rose-700 dark:bg-rose-950/20 dark:text-rose-450 px-4 py-2 rounded-lg text-xs font-bold transition-all cursor-pointer border border-rose-150 dark:border-rose-950/40"
            title="Klik untuk memulakan promosi sesi baru"
          >
            <Zap className="w-3.5 h-3.5" />
            <span>Naik Sesi Baru</span>
          </button>
        </div>
      </nav>

      {/* 3. Kandungan Halaman Utama (Main Canvas) */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-4 sm:p-6 pb-12">
        {selectedProfilePupil && activeTab === 'profil' ? (
          <ProfilMuridView
            pupil={selectedProfilePupil}
            books={books}
            loans={loans}
            currentSession={currentSession}
            onBack={() => {
              setSelectedProfilePupil(null);
              // Kembalikan ke modul pendaftaran atau tab lepas
              setActiveTab('daftar');
            }}
          />
        ) : (
          <>
            {activeTab === 'dashboard' && (
              <Dashboard
                pupils={pupils}
                books={books}
                loans={loans}
                currentSession={currentSession}
                onNavigate={(tab) => setActiveTab(tab)}
              />
            )}

            {activeTab === 'pinjam' && (
              <PinjamBuku
                pupils={pupils}
                books={books}
                loans={loans}
                currentSession={currentSession}
                onUpdateLoanStatus={handleUpdateLoanStatus}
                onUpdateMultipleLoans={handleUpdateMultipleLoans}
                onSelectPupil={handleSelectProfilePupil}
                onPrintIndividu={(pupilId) => {
                  setActivePrintJob({ type: 'individu-pinjam', pupilId });
                }}
                onPrintPukal={(year) => {
                  setActivePrintJob({ type: 'pukal-pinjam', year });
                }}
              />
            )}

            {activeTab === 'pulang' && (
              <PulangBuku
                pupils={pupils}
                books={books}
                loans={loans}
                currentSession={currentSession}
                onUpdateReturnStatus={handleUpdateReturnStatus}
                onSelectPupil={handleSelectProfilePupil}
                onPrintIndividu={(pupilId) => {
                  setActivePrintJob({ type: 'individu-pulang', pupilId });
                }}
                onPrintPukal={(year) => {
                  setActivePrintJob({ type: 'pukal-pulang', year });
                }}
              />
            )}

            {activeTab === 'laporan' && (
              <LaporanSPBTView
                pupils={pupils}
                books={books}
                loans={loans}
                currentSession={currentSession}
              />
            )}

            {activeTab === 'daftar' && (
              <DaftarMurid
                pupils={pupils}
                currentSession={currentSession}
                onAddPupil={handleAddPupil}
                onEditPupil={handleEditPupil}
                onDeletePupil={handleDeletePupil}
                onClearAllPupils={handleClearAllData}
                onSelectPupil={handleSelectProfilePupil}
              />
            )}

            {activeTab === 'buku' && (
              <UrusBuku
                books={books}
                onAddBook={handleAddBook}
                onEditBook={handleEditBook}
                onDeleteBook={handleDeleteBook}
              />
            )}

            {activeTab === 'arkib' && (
              <ArkibView
                pupils={pupils}
                books={books}
                loans={loans}
                currentSession={currentSession}
              />
            )}

            {activeTab === 'sheets' && (
              <GoogleSheetsConfig
                sheetUrl={googleSheetUrl}
                onSaveUrl={handleSaveSheetUrl}
                onPullData={handleManualPull}
                onPushData={handleManualPush}
                syncStatus={syncStatus}
                lastSyncDate={lastSyncDate}
                errorMessage={errorMessage}
              />
            )}

            {activeTab === 'pengguna' && (
              <DaftarPengguna
                users={users}
                onAddUser={handleAddUser}
                onDeleteUser={handleDeleteUser}
              />
            )}
          </>
        )}
      </main>

      {/* 4. Dialog Modal Naik Tahun Sesi Baharu (Dangerous Action Protection) */}
      {showSessionModal && (
        <div className="fixed inset-0 bg-neutral-900/60 dark:bg-black/80 flex items-center justify-center p-4 z-50 animate-fade-in">
          <div className="bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-3xl p-6 max-w-md w-full shadow-2xl space-y-6">
            <div className="text-center space-y-2">
              <span className="p-3 bg-rose-50 dark:bg-rose-950/40 text-rose-600 dark:text-rose-400 rounded-2xl inline-block">
                <Zap className="w-8 h-8 animate-bounce" />
              </span>
              <h3 className="text-lg font-black text-neutral-900 dark:text-white">Naik Tahun Sesi Baharu?</h3>
              <p className="text-xs text-neutral-500 leading-normal">
                Tindakan ini tidak boleh diundurkan. Sila pastikan semua peminjaman dan pulang buku untuk Sesi sedia ada ({currentSession}) telah direkodkan.
              </p>
            </div>

            <div className="p-4 bg-rose-50/50 dark:bg-rose-950/15 border border-rose-100 dark:border-rose-950/45 rounded-2xl space-y-2.5 text-xs text-rose-800 dark:text-rose-300">
              <span className="font-bold block">🚀 Kesan Naik Tahun Sesi Baharu:</span>
              <ul className="list-disc list-inside space-y-1 text-[11px] leading-normal font-semibold">
                <li>Murid Tahun 1-5 akan dinaikkan setaraf ke Tahun 2-6.</li>
                <li>Murid Tahun 6 dialihkan terus ke dalam modul Arkib.</li>
                <li>Sesi persekolahan akan dianaktirikan setahun ke depan (Sesi {parseInt(currentSession) + 1}).</li>
                <li>Guru SPBT hanya perlu mendaftarkan murid Tahun 1 yang baru bagi pengedaran sesi baru!</li>
              </ul>
            </div>

            <div className="grid grid-cols-2 gap-3 pt-2">
              <button
                id="btn_cancel_naik_tahun"
                onClick={() => setShowSessionModal(false)}
                className="py-2.5 px-4 border border-neutral-200 dark:border-neutral-800 text-neutral-600 dark:text-neutral-400 hover:bg-neutral-50 dark:hover:bg-neutral-800/80 rounded-xl text-xs font-bold transition-all cursor-pointer"
              >
                Batalkan
              </button>
              
              <button
                id="btn_confirm_naik_tahun"
                onClick={handleNewSessionPromote}
                className="py-2.5 px-4 bg-rose-600 hover:bg-rose-700 text-white rounded-xl text-xs font-bold transition-all shadow-xs flex items-center justify-center gap-1 cursor-pointer"
              >
                <span>Ya, Naik Tahun Sesi Baru</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 5. Footer */}
      <footer className="bg-white dark:bg-neutral-900 border-t border-neutral-200 dark:border-neutral-800/80 py-4 px-4 text-center text-xs text-neutral-400 font-semibold uppercase tracking-wider mt-auto print:hidden">
        Sistem Pengurusan SPBT Sekolah Rendah © {new Date().getFullYear()} • Bersepadu Google Sheets & Local storage
      </footer>

      {/* 6. Dialog Modal Log Keluar (Custom 100% Iframe Safe) */}
      {showLogoutConfirm && (
        <div className="fixed inset-0 bg-slate-900/60 dark:bg-black/80 flex items-center justify-center p-4 z-50 animate-fade-in print-hidden">
          <div className="bg-white dark:bg-slate-900 border border-stone-200 dark:border-slate-800 rounded-2xl p-6 max-w-sm w-full shadow-2xl space-y-5">
            <div className="text-center space-y-2">
              <span className="p-3 bg-rose-50 dark:bg-rose-950/40 text-rose-600 dark:text-rose-450 rounded-2xl inline-block">
                <LogOut className="w-6 h-6 animate-pulse" />
              </span>
              <h3 className="text-base font-bold text-slate-900 dark:text-white">Log Keluar dari Sistem?</h3>
              <p className="text-xs text-slate-500 leading-relaxed">
                Adakah anda pasti untuk log keluar? Anda perlu memasukkan nama laluan dan kata laluan semula untuk masuk.
              </p>
            </div>

            <div className="grid grid-cols-2 gap-3 pt-1">
              <button
                id="btn_cancel_logout"
                onClick={() => setShowLogoutConfirm(false)}
                className="py-2.5 px-4 border border-stone-200 dark:border-slate-800 text-slate-650 dark:text-slate-400 hover:bg-stone-50 dark:hover:bg-slate-800 rounded-xl text-xs font-bold transition-all cursor-pointer"
              >
                Kembali
              </button>
              
              <button
                id="btn_confirm_logout"
                onClick={() => {
                  localStorage.removeItem('spbt_logged_in');
                  setIsLoggedIn(false);
                  setShowLogoutConfirm(false);
                }}
                className="py-2.5 px-4 bg-rose-600 hover:bg-rose-700 text-white rounded-xl text-xs font-bold transition-all shadow-xs flex items-center justify-center gap-1 cursor-pointer"
              >
                <span>Ya, Log Keluar</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 7. Dialog Modal Cetakan SPBT */}
      {activePrintJob && (
        <PrintModal
          books={books}
          pupils={pupils}
          loans={loans}
          currentSession={currentSession}
          job={activePrintJob}
          onClose={() => setActivePrintJob(null)}
        />
      )}

    </div>
  );
}
