import { useState } from 'react';
import { Book, Pupil, Loan } from '../types';
import { Archive, Search, User, Clipboard } from 'lucide-react';

interface ArkibViewProps {
  pupils: Pupil[];
  books: Book[];
  loans: Loan[];
  currentSession: string;
}

export default function ArkibView({ pupils, books, loans, currentSession }: ArkibViewProps) {
  // Saring semua murid yang telah diarkibkan
  const archivedPupils = pupils.filter(p => p.isArchived);
  
  // Dapatkan semua nama sesi arkib yang wujud
  const archiveSessionsSet = new Set(
    archivedPupils
      .map(p => p.archiveSession || p.session)
      .filter(s => s !== currentSession) // Sesi semasa tidak diklasifikasikan sebagai arkib
  );
  
  // Tambahkan beberapa tahun sesi standard jika kosong agar kelihatan kukuh
  if (archiveSessionsSet.size === 0) {
    archiveSessionsSet.add('2025');
    archiveSessionsSet.add('2024');
  }

  const archiveSessions = Array.from(archiveSessionsSet).sort().reverse();

  const [activeSession, setActiveSession] = useState<string>(archiveSessions[0] || '2025');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedPupilId, setSelectedPupilId] = useState<string | null>(null);

  // Saring murid arkib bersesuaian dengan sesi terpilih
  const pupilsInArchiveSession = archivedPupils.filter(p => 
    (p.archiveSession === activeSession || p.session === activeSession)
  );

  // Cari murid arkib berdasarkan input carian
  const filteredPupils = pupilsInArchiveSession.filter(p => 
    p.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
    p.className.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const selectedPupil = archivedPupils.find(p => p.id === selectedPupilId);
  const selectedPupilLoans = selectedPupil 
    ? loans.filter(l => l.pupilId === selectedPupil.id && l.session === activeSession) 
    : [];

  return (
    <div className="space-y-6 animate-fade-in">
      
      {/* Pilihan Sesi Arkib */}
      <div className="bg-white dark:bg-slate-900 border border-stone-200 dark:border-slate-800 p-5 rounded-xl shadow-2xs flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 font-sans">
        <div>
          <h3 className="font-sans font-bold text-slate-950 dark:text-white text-lg flex items-center gap-2">
            <Archive className="w-5 h-5 text-emerald-500" />
            Teroka Sejarah Arkib SPBT
          </h3>
          <p className="text-xs text-slate-400 mt-1">Semak sejarah pengedaran buku murid bertahun-tahun terdahulu.</p>
        </div>

        <div className="flex gap-2 w-full sm:w-auto font-mono">
          {archiveSessions.map(sess => (
            <button
              key={sess}
              id={`btn_arkib_sesi_${sess}`}
              onClick={() => {
                setActiveSession(sess);
                setSelectedPupilId(null);
              }}
              className={`flex-1 sm:flex-initial text-[10px] font-bold px-4 py-2 uppercase tracking-wider rounded border transition-all cursor-pointer ${
                activeSession === sess
                  ? 'bg-slate-900 border-slate-900 dark:bg-emerald-950 dark:border-emerald-800 text-white dark:text-emerald-400 shadow-xs'
                  : 'bg-transparent border-stone-200 dark:border-slate-800 text-slate-600 dark:text-slate-400 hover:bg-stone-55 dark:hover:bg-slate-850'
              }`}
            >
              Arkib Sesi {sess}
            </button>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        
        {/* Senarai Murid dalam Arkib Terpilih */}
        <div className="bg-white dark:bg-slate-900 border border-stone-200 dark:border-slate-800 rounded-xl shadow-2xs p-5 space-y-4 self-start font-sans">
          <h4 className="font-sans font-bold text-slate-950 dark:text-white text-base">Cari Murid Lama ({activeSession})</h4>
          
          <div className="relative">
            <Search className="w-4 h-4 absolute left-3 top-2.5 text-slate-400" />
            <input
              id="arkib_carian_murid"
              type="text"
              placeholder="Cari nama murid / kelas arkib..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-stone-50/50 dark:bg-slate-955 border border-stone-200 dark:border-slate-850 rounded-lg pl-9 pr-3 py-2 text-xs text-slate-950 dark:text-white focus:outline-none focus:border-slate-900 dark:focus:border-emerald-600 focus:bg-white transition-all font-sans"
            />
          </div>

          <div className="divide-y divide-stone-100 dark:divide-slate-800/40 max-h-[350px] overflow-y-auto pr-1">
            {filteredPupils.length === 0 ? (
              <div className="py-12 text-center text-xs text-slate-400 dark:text-slate-500 font-medium">
                Tiada rekod murid arkib ditemui untuk Sesi {activeSession}.
              </div>
            ) : (
              filteredPupils.map((pupil) => {
                const isSelected = selectedPupilId === pupil.id;

                return (
                  <button
                    key={pupil.id}
                    id={`btn_pilih_murid_arkib_${pupil.id}`}
                    onClick={() => setSelectedPupilId(pupil.id)}
                    className={`w-full flex items-center justify-between p-3 rounded-lg text-left transition-all mt-1.5 cursor-pointer ${
                      isSelected 
                        ? 'bg-slate-900 dark:bg-emerald-955 text-white dark:text-emerald-450 font-bold shadow-xs' 
                        : 'hover:bg-stone-50/70 dark:hover:bg-slate-855/35 text-slate-850 dark:text-slate-300'
                    }`}
                  >
                    <div>
                      <p className="text-xs font-bold leading-tight">{pupil.name}</p>
                      <p className={`text-[10px] mt-1 font-mono uppercase ${isSelected ? 'text-slate-300 dark:text-emerald-500/85' : 'text-slate-450'}`}>
                        Kelas asal: {pupil.className} • Gred {pupil.year}
                      </p>
                    </div>
                  </button>
                );
              })
            )}
          </div>
        </div>

        {/* Butiran Sejarah Buku untuk Murid Arkib Terpilih */}
        <div className="lg:col-span-2 bg-white dark:bg-slate-900 border border-stone-200 dark:border-slate-800 rounded-xl shadow-2xs p-6 flex flex-col min-h-[400px]">
          {selectedPupil ? (
            <div className="space-y-6">
              
              {/* Kepala Profil Arkib */}
              <div className="flex items-center gap-3 bg-stone-50 dark:bg-slate-955 p-4 rounded-lg border border-stone-200 dark:border-slate-850/60 font-sans">
                <div className="p-2.5 bg-stone-200 dark:bg-slate-800 text-slate-700 dark:text-slate-300 rounded">
                  <User className="w-5 h-5 text-emerald-555" />
                </div>
                <div>
                  <h4 className="font-sans font-bold text-slate-900 dark:text-white text-base">{selectedPupil.name}</h4>
                  <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                    Sejarah Rekod Sesi Arkib: <span className="font-mono font-bold">{activeSession}</span> • Kelas lama: <span className="font-mono uppercase font-bold">{selectedPupil.className}</span> • Gred asal: <span className="font-mono uppercase font-bold">Tahun {selectedPupil.year}</span>
                  </p>
                </div>
              </div>

              {/* Senarai Rekod Buku */}
              <div className="space-y-4">
                <h5 className="font-sans font-bold text-slate-900 dark:text-white text-sm flex items-center gap-1.5">
                  <Clipboard className="w-4 h-4 text-emerald-500" />
                  Rekod Peminjaman Buku Sekolah Rendah ({selectedPupilLoans.length} rekod)
                </h5>

                <div className="border border-stone-200 dark:border-slate-800 rounded-lg overflow-hidden shadow-3xs">
                  <table className="w-full text-left text-xs border-collapse">
                    <thead>
                      <tr className="bg-stone-50 dark:bg-slate-950 text-slate-550 dark:text-slate-400 text-[10px] font-bold uppercase tracking-wider border-b border-stone-200 dark:border-slate-850 font-mono">
                        <th className="px-6 py-3.5">Nama Buku Teks</th>
                        <th className="px-4 py-3.5">Tarikh Pinjam</th>
                        <th className="px-4 py-3.5">Tarikh Pulang</th>
                        <th className="px-6 py-3.5 text-right font-bold">Status Akhir</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-stone-100 dark:divide-slate-800/60 bg-white dark:bg-slate-900 text-slate-750 dark:text-slate-350 font-sans">
                      {selectedPupilLoans.length === 0 ? (
                        <tr>
                          <td colSpan={4} className="p-12 text-center text-xs text-slate-450 font-medium">
                            Tiada rekod data dijumpai bagi pengedaran buku murid ini semasa Sesi {activeSession}.
                          </td>
                        </tr>
                      ) : (
                        selectedPupilLoans.map((loan) => {
                          const book = books.find(b => b.id === loan.bookId);
                          if (!book) return null;

                          let statusStyle = 'bg-stone-100 text-slate-650';
                          if (loan.status === 'Dipinjam') statusStyle = 'bg-amber-50 text-amber-700 dark:bg-amber-955/40 dark:text-amber-450';
                          if (loan.status === 'Dipulangkan') statusStyle = 'bg-emerald-50 text-emerald-700 dark:bg-emerald-955 dark:text-emerald-455';
                          if (loan.status === 'Hilang') statusStyle = 'bg-rose-50 text-rose-700 dark:bg-rose-955/40 dark:text-rose-455';
                          if (loan.status === 'Rosak') statusStyle = 'bg-orange-50 text-orange-700 dark:bg-orange-955/40 dark:text-orange-455';

                          return (
                            <tr key={loan.id} className="hover:bg-stone-50/50 dark:hover:bg-slate-955/20 transition-colors">
                              <td className="px-6 py-4">
                                <p className="font-bold text-slate-900 dark:text-white leading-tight">{book.title}</p>
                                <span className="text-[10px] font-mono text-slate-400 dark:text-slate-500 mt-1 block">Kod: {book.id}</span>
                              </td>
                              <td className="px-4 py-4 font-mono text-slate-550 dark:text-slate-400">
                                {loan.lendDate || '—'}
                              </td>
                              <td className="px-4 py-4 font-mono text-slate-550 dark:text-slate-400">
                                {loan.returnDate || '—'}
                              </td>
                              <td className="px-6 py-4 text-right">
                                <span className={`inline-block text-[10px] font-bold font-mono uppercase tracking-wider px-2 py-0.5 rounded ${statusStyle}`}>
                                  {loan.status}
                                </span>
                              </td>
                            </tr>
                          );
                        })
                      )}
                    </tbody>
                  </table>
                </div>
              </div>

            </div>
          ) : (
            <div className="flex-1 flex flex-col items-center justify-center text-slate-400 dark:text-slate-500 p-12 space-y-4">
              <Archive className="w-10 h-10 text-stone-300 dark:text-slate-750" />
              <div className="text-center">
                <p className="text-sm font-sans font-bold text-slate-800 dark:text-slate-200">Teroka Butiran Profil Murid Lama</p>
                <p className="text-[11px] text-slate-400 dark:text-slate-500 mt-1.5 max-w-sm leading-relaxed mx-auto">
                  Pilih sejarah nama murid pada kolum sebelah kiri untuk memaparkan senarai terperinci buku teks yang telah diuruskan pada sesi lama bertaraf Arkib.
                </p>
              </div>
            </div>
          )}
        </div>

      </div>
    </div>
  );
}
