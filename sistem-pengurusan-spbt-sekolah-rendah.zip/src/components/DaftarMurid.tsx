import React, { useState } from 'react';
import { Pupil } from '../types';
import { UserPlus, Search, GraduationCap, School, Edit2, Trash2, Check, X } from 'lucide-react';

interface DaftarMuridProps {
  pupils: Pupil[];
  currentSession: string;
  onAddPupil: (name: string, year: number, className: string) => void;
  onEditPupil: (id: string, name: string, year: number, className: string) => void;
  onDeletePupil: (id: string) => void;
  onClearAllPupils?: () => void;
  onSelectPupil: (pupil: Pupil) => void;
}

export default function DaftarMurid({ 
  pupils, 
  currentSession, 
  onAddPupil, 
  onEditPupil, 
  onDeletePupil,
  onClearAllPupils,
  onSelectPupil 
}: DaftarMuridProps) {

  // Form State
  const [name, setName] = useState('');
  const [year, setYear] = useState<number>(1);
  const [className, setClassName] = useState('');
  
  // Search state
  const [searchQuery, setSearchQuery] = useState('');
  const [searchYear, setSearchYear] = useState<string>('all');
  const [searchClass, setSearchClass] = useState<string>('all');

  // Edit State
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editName, setEditName] = useState('');
  const [editYear, setEditYear] = useState<number>(1);
  const [editClassName, setEditClassName] = useState('');

  // Delete confirm state
  const [deleteConfirmId, setDeleteConfirmId] = useState<string | null>(null);
  const [deleteConfirmName, setDeleteConfirmName] = useState<string>('');
  const [showClearConfirm, setShowClearConfirm] = useState(false);

  // Saring murid aktif sahaja mengikut sesi semasa
  const activePupils = pupils.filter(p => !p.isArchived && p.session === currentSession);

  // Senarai Kelas yang wujud untuk ditapis
  const uniqueClasses = Array.from(new Set(activePupils.map(p => p.className))).filter(Boolean);

  // Filter logic
  const filteredPupils = activePupils.filter(p => {
    const matchesName = p.name.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesYear = searchYear === 'all' ? true : p.year === parseInt(searchYear);
    const matchesClass = searchClass === 'all' ? true : p.className === searchClass;
    return matchesName && matchesYear && matchesClass;
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !className.trim()) {
      alert('Sila isi maklumat nama murid dan nama kelas!');
      return;
    }
    onAddPupil(name.trim(), year, className.trim());
    setName('');
    setClassName('');
    // Be friendly
  };

  const startEdit = (p: Pupil) => {
    setEditingId(p.id);
    setEditName(p.name);
    setEditYear(p.year);
    setEditClassName(p.className);
  };

  const saveEdit = (id: string) => {
    if (!editName.trim() || !editClassName.trim()) {
      alert('Sila lengkapkan nama murid dan nama kelas.');
      return;
    }
    onEditPupil(id, editName.trim(), editYear, editClassName.trim());
    setEditingId(null);
  };

  const cancelEdit = () => {
    setEditingId(null);
  };

  const handleDelete = (id: string, name: string) => {
    setDeleteConfirmId(id);
    setDeleteConfirmName(name);
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 animate-fade-in">
      
      {/* Bahagian 1: Borang Pendaftaran Buku/Murid Baru dengan Gaya Editorial */}
      <div className="space-y-6">
        <div className="bg-white dark:bg-slate-900 border border-stone-200 dark:border-slate-800 p-6 rounded-xl shadow-xs">
          <div className="flex items-center gap-2 mb-5 text-slate-800 dark:text-emerald-400 border-b border-stone-100 dark:border-slate-800 pb-3">
            <UserPlus className="w-4 h-4 text-emerald-500" />
            <h3 className="font-sans font-bold text-slate-900 dark:text-white text-base">Daftar Murid Baharu</h3>
          </div>

          <form onSubmit={handleSubmit} className="space-y-5">
            <div>
              <label className="block text-[10px] font-bold text-slate-400 dark:text-slate-500 mb-1.5 uppercase tracking-widest font-mono">Nama Penuh Murid</label>
              <input
                id="murid_nama_input"
                type="text"
                required
                placeholder="Contoh: Muhammad Ali bin Ahmad"
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full bg-stone-50/50 dark:bg-slate-950 border border-stone-200 dark:border-slate-850 rounded-lg px-4 py-2.5 text-sm text-slate-900 dark:text-white focus:outline-none focus:border-slate-900 dark:focus:border-emerald-600 focus:bg-white transition-colors"
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-[10px] font-bold text-slate-400 dark:text-slate-500 mb-1.5 uppercase tracking-widest font-mono">Tahun / Gred</label>
                <select
                  id="murid_tahun_select"
                  value={year}
                  onChange={(e) => setYear(parseInt(e.target.value))}
                  className="w-full bg-stone-50/50 dark:bg-slate-950 border border-stone-200 dark:border-slate-850 rounded-lg px-3 py-2.5 text-sm text-slate-900 dark:text-white focus:outline-none focus:border-slate-900 dark:focus:border-emerald-600 focus:bg-white transition-colors"
                >
                  <option value={1}>Tahun 1</option>
                  <option value={2}>Tahun 2</option>
                  <option value={3}>Tahun 3</option>
                  <option value={4}>Tahun 4</option>
                  <option value={5}>Tahun 5</option>
                  <option value={6}>Tahun 6</option>
                </select>
              </div>

              <div>
                <label className="block text-[10px] font-bold text-slate-400 dark:text-slate-500 mb-1.5 uppercase tracking-widest font-mono">Nama Kelas</label>
                <input
                  id="murid_kelas_input"
                  type="text"
                  required
                  placeholder="Contoh: Ibnu Sina"
                  value={className}
                  onChange={(e) => setClassName(e.target.value)}
                  className="w-full bg-stone-50/50 dark:bg-slate-950 border border-stone-200 dark:border-slate-850 rounded-lg px-4 py-2.5 text-sm text-slate-900 dark:text-white focus:outline-none focus:border-slate-900 dark:focus:border-emerald-600 focus:bg-white transition-colors"
                />
              </div>
            </div>

            <button
              id="murid_daftar_submit"
              type="submit"
              className="w-full bg-slate-900 dark:bg-emerald-950 text-white dark:text-emerald-400 font-bold py-2.5 px-4 rounded-lg text-xs uppercase tracking-wider font-mono border border-slate-900 dark:border-emerald-800 hover:bg-slate-800 dark:hover:bg-emerald-800/20 transition-all shadow-xs cursor-pointer flex items-center justify-center gap-1.5"
            >
              <UserPlus className="w-3.5 h-3.5" />
              <span>Daftarkan Murid Murba</span>
            </button>
          </form>

          <div className="mt-5 p-4 bg-stone-50 dark:bg-slate-950/40 border border-stone-200/50 dark:border-slate-800/60 rounded-lg text-[10.5px] text-slate-500 dark:text-slate-450 leading-relaxed font-sans">
            ⭐ <strong className="font-semibold text-slate-700 dark:text-white">Tip Sesi:</strong> Murid yang dicarikan akan terus diletakkan di bawah sesi aktif sedia ada (<span className="font-mono">{currentSession}</span>). Rekod secara sedia laku disegerakkan terus ke Google Sheets jika integrasi beroperasi.
          </div>
        </div>
      </div>

      {/* Bahagian 2: Carian & Senarai Murid Aktif dengan Gaya Editorial */}
      <div className="lg:col-span-2 space-y-6">
        
        {/* Penapis Carian */}
        <div className="bg-white dark:bg-slate-900 border border-stone-200 dark:border-slate-800 p-5 rounded-xl shadow-2xs space-y-3">
          <div className="flex flex-col sm:flex-row gap-3">
            <div className="relative flex-1">
              <Search className="w-4 h-4 absolute left-3.5 top-3.5 text-slate-400" />
              <input
                id="murid_carian_input"
                type="text"
                placeholder="Cari nama murid..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full bg-stone-50/50 dark:bg-slate-950 border border-stone-200 dark:border-slate-850 rounded-lg pl-10 pr-4 py-2.5 text-sm text-slate-900 dark:text-white focus:outline-none focus:border-slate-900 dark:focus:border-emerald-600 focus:bg-white transition-colors"
              />
            </div>

            <div className="flex gap-2">
              <select
                id="murid_saring_tahun"
                value={searchYear}
                onChange={(e) => setSearchYear(e.target.value)}
                className="bg-stone-50/50 dark:bg-slate-950 border border-stone-200 dark:border-slate-850 rounded-lg px-3 py-2 text-xs font-bold text-slate-750 dark:text-slate-300 focus:outline-none focus:border-slate-900 dark:focus:border-emerald-600 focus:bg-white transition-colors font-mono uppercase"
              >
                <option value="all">Semua Tahun</option>
                <option value="1">Tahun 1</option>
                <option value="2">Tahun 2</option>
                <option value="3">Tahun 3</option>
                <option value="4">Tahun 4</option>
                <option value="5">Tahun 5</option>
                <option value="6">Tahun 6</option>
              </select>

              <select
                id="murid_saring_kelas"
                value={searchClass}
                onChange={(e) => setSearchClass(e.target.value)}
                className="bg-stone-50/50 dark:bg-slate-950 border border-stone-200 dark:border-slate-850 rounded-lg px-3 py-2 text-xs font-bold text-slate-750 dark:text-slate-300 focus:outline-none focus:border-slate-900 dark:focus:border-emerald-600 focus:bg-white transition-colors font-mono uppercase"
              >
                <option value="all">Semua Kelas</option>
                {uniqueClasses.map(cls => (
                  <option key={cls} value={cls}>{cls}</option>
                ))}
              </select>
            </div>
          </div>
        </div>

        {/* Senarai Jadual Murid */}
        <div className="bg-white dark:bg-slate-900 border border-stone-200 dark:border-slate-800 rounded-xl overflow-hidden shadow-2xs">
          <div className="p-5 border-b border-stone-200 dark:border-slate-800 flex flex-wrap justify-between items-center bg-stone-50/50 dark:bg-slate-950 gap-3">
            <h4 className="font-sans font-bold text-slate-900 dark:text-white text-base">Senarai Murid Aktif ({filteredPupils.length} orang)</h4>
            
            <div className="flex items-center gap-3">
              {onClearAllPupils && pupils.length > 0 && (
                <button
                  type="button"
                  id="btn_clear_all_pupils"
                  onClick={() => setShowClearConfirm(true)}
                  className="text-xs font-bold text-rose-600 dark:text-rose-455 hover:bg-rose-50 dark:hover:bg-rose-950/20 px-3 py-1.5 rounded-lg border border-rose-150 dark:border-rose-950/50 cursor-pointer transition-colors"
                  title="Kosongkan seluruh data murid dan pinjaman contoh untuk mula memasukkan data sekolah sebenar"
                >
                  🧹 Kosongkan Contoh Murid & Rekod
                </button>
              )}
              <span className="text-[10px] font-bold text-slate-400 dark:text-slate-500 font-mono bg-stone-150 dark:bg-slate-800/80 px-2.5 py-1 rounded">SEK. SESI: {currentSession}</span>
            </div>
          </div>

          {filteredPupils.length === 0 ? (
            <div className="p-12 text-center text-neutral-400 dark:text-neutral-500 space-y-2">
              <School className="w-10 h-10 mx-auto text-neutral-300" />
              <p className="text-sm">Tiada murid yang sepadan dengan carian.</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left text-sm border-collapse">
                <thead>
                  <tr className="bg-neutral-50 dark:bg-neutral-950 text-neutral-500 dark:text-neutral-400 text-xs uppercase tracking-wider border-b border-neutral-200 dark:border-neutral-800">
                    <th className="px-6 py-3 font-semibold">Nama Murid</th>
                    <th className="px-4 py-3 font-semibold">Tahun</th>
                    <th className="px-4 py-3 font-semibold">Kelas</th>
                    <th className="px-6 py-3 font-semibold text-right">Tindakan</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-neutral-200 dark:divide-neutral-800">
                  {filteredPupils.map((pupil) => {
                    const isEditing = editingId === pupil.id;

                    return (
                      <tr 
                        key={pupil.id} 
                        className="hover:bg-neutral-50/50 dark:hover:bg-neutral-800/30 transition-colors"
                      >
                        {/* Nama */}
                        <td className="px-6 py-4 font-medium text-neutral-900 dark:text-white">
                          {isEditing ? (
                            <input
                              type="text"
                              value={editName}
                              onChange={(e) => setEditName(e.target.value)}
                              className="w-full bg-white dark:bg-neutral-950 border border-neutral-300 dark:border-neutral-700 px-2 py-1 rounded-lg text-sm text-neutral-900 dark:text-white"
                            />
                          ) : (
                            <button
                              onClick={() => onSelectPupil(pupil)}
                              className="text-emerald-600 dark:text-emerald-400 hover:underline text-left font-semibold"
                            >
                              {pupil.name}
                            </button>
                          )}
                        </td>

                        {/* Tahun */}
                        <td className="px-4 py-4">
                          {isEditing ? (
                            <select
                              value={editYear}
                              onChange={(e) => setEditYear(parseInt(e.target.value))}
                              className="bg-white dark:bg-neutral-950 border border-neutral-300 dark:border-neutral-700 px-2 py-1 rounded-lg text-sm text-neutral-900 dark:text-white"
                            >
                              {[1, 2, 3, 4, 5, 6].map(yr => (
                                <option key={yr} value={yr}>Tahun {yr}</option>
                              ))}
                            </select>
                          ) : (
                            <span className="inline-flex items-center gap-1 bg-neutral-100 dark:bg-neutral-800 text-neutral-800 dark:text-neutral-200 px-2 py-1 rounded-md text-xs font-semibold">
                              Year {pupil.year}
                            </span>
                          )}
                        </td>

                        {/* Kelas */}
                        <td className="px-4 py-4 text-neutral-600 dark:text-neutral-300">
                          {isEditing ? (
                            <input
                              type="text"
                              value={editClassName}
                              onChange={(e) => setEditClassName(e.target.value)}
                              className="w-24 bg-white dark:bg-neutral-950 border border-neutral-300 dark:border-neutral-700 px-2 py-1 rounded-lg text-sm text-neutral-900 dark:text-white"
                            />
                          ) : (
                            pupil.className
                          )}
                        </td>

                        {/* Tindakan */}
                        <td className="px-6 py-4 text-right">
                          <div className="flex gap-2 justify-end">
                            {isEditing ? (
                              <>
                                <button
                                  onClick={() => saveEdit(pupil.id)}
                                  className="p-1.5 bg-emerald-50 text-emerald-600 dark:bg-emerald-950/40 dark:text-emerald-400 hover:bg-emerald-100 rounded-lg transition-colors"
                                  title="Simpan"
                                >
                                  <Check className="w-4 h-4" />
                                </button>
                                <button
                                  onClick={cancelEdit}
                                  className="p-1.5 bg-neutral-50 text-neutral-500 dark:bg-neutral-800 dark:text-neutral-400 hover:bg-neutral-100 rounded-lg transition-colors"
                                  title="Batal"
                                >
                                  <X className="w-4 h-4" />
                                </button>
                              </>
                            ) : (
                              <>
                                <button
                                  onClick={() => startEdit(pupil)}
                                  className="p-1.5 bg-neutral-50 text-neutral-600 dark:bg-neutral-800 dark:text-neutral-300 hover:bg-neutral-100 dark:hover:bg-neutral-700 rounded-lg transition-colors"
                                  title="Ubah Butiran"
                                >
                                  <Edit2 className="w-3.5 h-3.5" />
                                </button>
                                <button
                                  onClick={() => handleDelete(pupil.id, pupil.name)}
                                  className="p-1.5 bg-red-50 text-red-600 dark:bg-red-950/20 dark:text-red-400 hover:bg-red-100 dark:hover:bg-red-950/50 rounded-lg transition-colors"
                                  title="Padam"
                                >
                                  <Trash2 className="w-3.5 h-3.5" />
                                </button>
                              </>
                            )}
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>

      {/* Model Overlay Padam Murid Kastam */}
      {deleteConfirmId && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-fade-in">
          <div className="bg-white dark:bg-slate-900 rounded-xl p-6 max-w-sm w-full border border-stone-200 dark:border-slate-800 shadow-xl space-y-4">
            <div className="flex items-center gap-2.5 text-rose-600 dark:text-rose-400">
              <Trash2 className="w-5 h-5" />
              <h3 className="text-base font-sans font-bold text-slate-900 dark:text-white">
                Padam Murid Terpilih?
              </h3>
            </div>
            <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed">
              Adakah anda pasti untuk memadam murid bernama <strong className="text-slate-800 dark:text-slate-200">"{deleteConfirmName}"</strong>? 
              Semua rekod pinjaman berkaitan murid ini akan turut dipadam kekal.
            </p>
            <div className="flex justify-end gap-2.5 pt-2">
              <button
                type="button"
                id="btn_cancel_delete_pupil"
                onClick={() => {
                  setDeleteConfirmId(null);
                  setDeleteConfirmName('');
                }}
                className="px-3.5 py-2 text-xs font-bold text-slate-700 dark:text-slate-300 bg-stone-100 hover:bg-stone-200 dark:bg-slate-800 dark:hover:bg-slate-755 rounded-lg cursor-pointer transition-colors"
              >
                Batal
              </button>
              <button
                type="button"
                id="btn_confirm_delete_pupil"
                onClick={() => {
                  onDeletePupil(deleteConfirmId);
                  setDeleteConfirmId(null);
                  setDeleteConfirmName('');
                }}
                className="px-3.5 py-2 text-xs font-bold text-white bg-rose-600 hover:bg-rose-700 rounded-lg cursor-pointer transition-colors"
              >
                Ya, Padam
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Model Overlay Kosongkan Murid & Rekod Kastam */}
      {showClearConfirm && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-fade-in">
          <div className="bg-white dark:bg-slate-900 rounded-xl p-6 max-w-sm w-full border border-stone-200 dark:border-slate-800 shadow-xl space-y-4">
            <div className="flex items-center gap-2.5 text-rose-600 dark:text-rose-400 font-sans">
              <Trash2 className="w-5 h-5 animate-pulse" />
              <h3 className="text-base font-bold text-slate-900 dark:text-white">
                Kosongkan Semua Data?
              </h3>
            </div>
            <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed font-sans">
              Tindakan ini akan memadam <strong>SEMUA DATA MURID</strong> dan <strong>REKOD PINJAMAN</strong> sedia ada. 
              Sila gunakan ini untuk membersihkan nama-nama contoh bagi mula mengisi nama murid sekolah sebenar.
            </p>
            <div className="flex justify-end gap-2.5 pt-2 font-sans">
              <button
                type="button"
                id="btn_cancel_clear_all"
                onClick={() => setShowClearConfirm(false)}
                className="px-3.5 py-2 text-xs font-bold text-slate-705 dark:text-slate-300 bg-stone-105 hover:bg-stone-200 dark:bg-slate-800 dark:hover:bg-slate-750 rounded-lg cursor-pointer transition-colors"
              >
                Batal
              </button>
              <button
                type="button"
                id="btn_confirm_clear_all"
                onClick={() => {
                  if (onClearAllPupils) onClearAllPupils();
                  setShowClearConfirm(false);
                }}
                className="px-3.5 py-2 text-xs font-bold text-white bg-rose-600 hover:bg-rose-700 rounded-lg cursor-pointer transition-colors"
              >
                Ya, Kosongkan Semua
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
}
