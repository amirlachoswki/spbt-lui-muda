import React, { useState } from 'react';
import { UserPlus, Trash2, Eye, EyeOff, ShieldCheck, User, Users, Search, AlertCircle } from 'lucide-react';
import { UserAccount } from '../types';

interface DaftarPenggunaProps {
  users: UserAccount[];
  onAddUser: (username: string, name: string, role: 'Guru Penyelaras' | 'Pengawas SPBT', password: string) => void;
  onDeleteUser: (id: string) => void;
}

export default function DaftarPengguna({ users, onAddUser, onDeleteUser }: DaftarPenggunaProps) {
  // Form State
  const [username, setUsername] = useState('');
  const [name, setName] = useState('');
  const [role, setRole] = useState<'Guru Penyelaras' | 'Pengawas SPBT'>('Pengawas SPBT');
  const [password, setPassword] = useState('');
  const [showFormPassword, setShowFormPassword] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  
  // Search & List State
  const [searchQuery, setSearchQuery] = useState('');
  const [visiblePasswords, setVisiblePasswords] = useState<{ [key: string]: boolean }>({});

  const handleTogglePassword = (userId: string) => {
    setVisiblePasswords(prev => ({
      ...prev,
      [userId]: !prev[userId]
    }));
  };

  const handleAddSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);

    const cleanUsername = username.trim().toLowerCase();
    const cleanName = name.trim();
    const cleanPassword = password.trim();

    if (!cleanUsername || !cleanName || !cleanPassword) {
      setErrorMsg('Semua ruangan pendaftaran wajib diisi.');
      return;
    }

    if (cleanUsername.length < 3) {
      setErrorMsg('ID Pengguna mustahak sekurang-kurangnya 3 aksara.');
      return;
    }

    // Check duplication
    const isDuplicate = users.some(u => u.username.toLowerCase() === cleanUsername);
    if (isDuplicate) {
      setErrorMsg(`ID Pengguna "${cleanUsername}" telah digunakan oleh akaun lain. Sila pilih yang lain.`);
      return;
    }

    onAddUser(cleanUsername, cleanName, role, cleanPassword);
    
    // Clear Form
    setUsername('');
    setName('');
    setPassword('');
    setRole('Pengawas SPBT');
    setErrorMsg(null);
  };

  const filteredUsers = users.filter(u => 
    u.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    u.username.toLowerCase().includes(searchQuery.toLowerCase()) ||
    u.role.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="space-y-6 animate-fade-in font-sans">
      
      {/* Header Panel */}
      <div className="bg-white dark:bg-slate-900 border border-stone-200 dark:border-slate-800 p-6 rounded-xl shadow-xs relative overflow-hidden">
        <div className="absolute top-0 left-0 w-1.5 h-full bg-slate-900 dark:bg-emerald-600" />
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <h2 className="text-xl font-bold text-slate-900 dark:text-white flex items-center gap-2">
              <Users className="w-5 h-5 text-emerald-500" />
              Sistem Akses & Daftar Pengguna
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
              Urus keselamatan akses guru penyelaras dan pengawas SPBT SK Felda Lui Muda
            </p>
          </div>
          <div className="text-xs bg-stone-100 dark:bg-slate-850 border border-stone-200 dark:border-slate-800 rounded-lg px-3 py-1.5 text-slate-600 dark:text-slate-300 font-mono self-start sm:self-auto">
            JUMLAH AKAUN: {users.length} AKTIF
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Form Daftar Baharu */}
        <div className="bg-white dark:bg-slate-900 border border-stone-200 dark:border-slate-800 rounded-xl p-5 shadow-xs space-y-4">
          <div className="border-b border-stone-150 dark:border-slate-800 pb-3">
            <h3 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-1.5">
              <UserPlus className="w-4 h-4 text-emerald-500" />
              Daftar Akaun Baru
            </h3>
            <p className="text-[11px] text-slate-400 dark:text-slate-500 mt-0.5">
              Daftarkan ID masuk guru atau barisan pengawas SPBT
            </p>
          </div>

          {errorMsg && (
            <div className="p-3 bg-rose-50 dark:bg-rose-950/20 border border-rose-150 dark:border-rose-900/40 text-rose-700 dark:text-rose-450 rounded-lg flex items-start gap-1.5 text-xs">
              <AlertCircle className="w-4 h-4 mt-0.5 shrink-0" />
              <span>{errorMsg}</span>
            </div>
          )}

          <form onSubmit={handleAddSubmit} className="space-y-4">
            
            {/* ID Pengguna */}
            <div className="space-y-1">
              <label className="text-xs font-bold text-slate-705 dark:text-slate-350 font-mono uppercase tracking-wider block">
                ID PENGGUNA (USERNAME)
              </label>
              <input
                type="text"
                id="reg_username"
                required
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                placeholder="cth: amir_spbt, pengawas1"
                className="w-full bg-stone-50 focus:bg-white dark:bg-slate-950 border border-stone-250 dark:border-slate-800 focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 focus:outline-none py-2 px-3 rounded-lg text-xs md:text-sm text-slate-900 dark:text-white placeholder:text-slate-400 dark:placeholder:text-slate-600 font-mono"
              />
            </div>

            {/* Nama Penuh */}
            <div className="space-y-1">
              <label className="text-xs font-bold text-slate-705 dark:text-slate-350 font-mono uppercase tracking-wider block">
                NAMA PENUH PENGGUNA
              </label>
              <input
                type="text"
                id="reg_name"
                required
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="cth: Ahmad Danish bin Azmi"
                className="w-full bg-stone-50 focus:bg-white dark:bg-slate-950 border border-stone-250 dark:border-slate-800 focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 focus:outline-none py-2 px-3 rounded-lg text-xs md:text-sm text-slate-900 dark:text-white placeholder:text-slate-400"
              />
            </div>

            {/* Kategori / Peranan */}
            <div className="space-y-1">
              <label className="text-xs font-bold text-slate-705 dark:text-slate-350 font-mono uppercase tracking-wider block">
                PERANAN PENGGUNA
              </label>
              <select
                id="reg_role"
                value={role}
                onChange={(e) => setRole(e.target.value as 'Guru Penyelaras' | 'Pengawas SPBT')}
                className="w-full bg-stone-50 focus:bg-white dark:bg-slate-950 border border-stone-250 dark:border-slate-800 focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 focus:outline-none py-2 px-3 rounded-lg text-xs md:text-sm text-slate-900 dark:text-white cursor-pointer"
              >
                <option value="Pengawas SPBT">👤 Pengawas SPBT</option>
                <option value="Guru Penyelaras">🛡️ Guru Penyelaras</option>
              </select>
            </div>

            {/* Kata Laluan */}
            <div className="space-y-1 relative">
              <label className="text-xs font-bold text-slate-705 dark:text-slate-350 font-mono uppercase tracking-wider block">
                KATA LALUAN SEMENTARA
              </label>
              <div className="relative">
                <input
                  type={showFormPassword ? 'text' : 'password'}
                  id="reg_password"
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Masukkan kata laluan..."
                  className="w-full bg-stone-50 focus:bg-white dark:bg-slate-950 border border-stone-250 dark:border-slate-800 focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 focus:outline-none py-2 pl-3 pr-9 rounded-lg text-xs md:text-sm text-slate-900 dark:text-white placeholder:text-slate-400 dark:placeholder:text-slate-600 font-mono"
                />
                <button
                  type="button"
                  id="toggle_form_pw"
                  onClick={() => setShowFormPassword(!showFormPassword)}
                  className="absolute right-2.5 top-2 text-slate-400 hover:text-slate-600 dark:text-slate-500 dark:hover:text-slate-300 transition-colors cursor-pointer"
                >
                  {showFormPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            <button
              type="submit"
              id="btn_submit_reg"
              className="w-full bg-emerald-600 hover:bg-emerald-700 text-white font-bold py-2.5 px-4 rounded-lg text-xs font-mono uppercase tracking-wider shadow-xs transition-colors cursor-pointer flex items-center justify-center gap-2"
            >
              <ShieldCheck className="w-4 h-4" />
              <span>Daftar Pengguna</span>
            </button>

          </form>
        </div>

        {/* Senarai Pengguna Sedia Ada */}
        <div className="bg-white dark:bg-slate-900 border border-stone-200 dark:border-slate-800 rounded-xl p-5 shadow-xs sm:col-span-2 space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-3 border-b border-stone-150 dark:border-slate-800 pb-3">
            <div>
              <h3 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-1.5">
                <Users className="w-4 h-4 text-emerald-500" />
                Senarai Pengguna Berdaftar
              </h3>
              <p className="text-[11px] text-slate-400 dark:text-slate-500 mt-0.5">
                Semua akaun yang sah untuk melog masuk sistem SPBT
              </p>
            </div>

            {/* Carian Pengguna */}
            <div className="relative">
              <Search className="w-3.5 h-3.5 text-stone-405 dark:text-slate-500 absolute left-2.5 top-2" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Cari pengguna..."
                className="bg-stone-50 dark:bg-slate-950 border border-stone-200 dark:border-slate-800 focus:border-emerald-500 focus:outline-none pl-8 pr-3 py-1.5 rounded-lg text-xs text-slate-900 dark:text-white w-48 transition-all"
              />
            </div>
          </div>

          {filteredUsers.length === 0 ? (
            <div className="text-center py-10">
              <span className="block text-2xl mb-1">🔍</span>
              <p className="text-xs text-slate-430 dark:text-slate-500 font-medium">Tiada padanan pengguna ditemui untuk "{searchQuery}".</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="border-b border-stone-100 dark:border-slate-800/80 text-[10px] font-bold text-slate-400 dark:text-slate-500 font-mono uppercase tracking-wider">
                    <th className="pb-3 pl-2">Kategori</th>
                    <th className="pb-3">ID (Username)</th>
                    <th className="pb-3">Nama Penuh</th>
                    <th className="pb-3">Kata Laluan</th>
                    <th className="pb-3 pr-2 text-right">Tindakan</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-stone-100/50 dark:divide-slate-800/55">
                  {filteredUsers.map((user) => {
                    const isVip = user.username.toLowerCase() === 'admin';
                    return (
                      <tr 
                        key={user.id} 
                        className="group hover:bg-stone-50/50 dark:hover:bg-slate-950/20 text-xs sm:text-sm text-slate-800 dark:text-slate-200 transition-colors"
                      >
                        <td className="py-3.5 pl-2">
                          {user.role === 'Guru Penyelaras' ? (
                            <span className="inline-flex items-center gap-1 text-[11px] font-bold border border-emerald-150 dark:border-emerald-950 bg-emerald-50 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-400 px-2 py-0.5 rounded-full">
                              🛡️ Guru
                            </span>
                          ) : (
                            <span className="inline-flex items-center gap-1 text-[11px] font-bold border border-amber-100 dark:border-amber-950/80 bg-amber-50 dark:bg-amber-950/20 text-amber-705 dark:text-amber-400 px-2 py-0.5 rounded-full">
                              👤 Pengawas
                            </span>
                          )}
                        </td>
                        <td className="py-3.5 font-mono text-xs font-bold text-slate-900 dark:text-slate-250">
                          {user.username}
                        </td>
                        <td className="py-3.5 font-medium max-w-[140px] truncate" title={user.name}>
                          {user.name}
                        </td>
                        <td className="py-3.5 font-mono text-xs">
                          <div className="flex items-center gap-1.5">
                            <span className="text-slate-500 dark:text-slate-400">
                              {visiblePasswords[user.id] ? user.password : '••••••••'}
                            </span>
                            <button
                              type="button"
                              onClick={() => handleTogglePassword(user.id)}
                              className="text-stone-400 hover:text-slate-650 dark:hover:text-slate-300 p-1 rounded-md hover:bg-stone-100 dark:hover:bg-slate-800 cursor-pointer"
                              title="Tengok/Sembunyi Kata Laluan"
                            >
                              {visiblePasswords[user.id] ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                            </button>
                          </div>
                        </td>
                        <td className="py-3.5 pr-2 text-right">
                          {isVip ? (
                            <span className="text-[10px] text-slate-400 dark:text-slate-500 italic">Sistem Utama</span>
                          ) : (
                            <button
                              type="button"
                              onClick={() => {
                                const conf = window.confirm(`Adakah anda pasti untuk memadam rekod akaun "${user.name}" (${user.username})?`);
                                if (conf) {
                                  onDeleteUser(user.id);
                                }
                              }}
                              className="text-rose-650 hover:text-rose-700 dark:text-rose-455 hover:dark:text-rose-350 p-2 rounded-lg hover:bg-rose-50 dark:hover:bg-rose-950/20 cursor-pointer transition-colors"
                              title="Padam Pengguna"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          )}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </div>

      </div>

    </div>
  );
}
