import { Book, Pupil, Loan } from '../types';
import { 
  Users, 
  BookOpen, 
  CheckCircle, 
  AlertTriangle, 
  XCircle, 
  TrendingUp, 
  ArrowRight,
  ShieldAlert,
  GraduationCap
} from 'lucide-react';
import SchoolLogo from './SchoolLogo';

interface DashboardProps {
  pupils: Pupil[];
  books: Book[];
  loans: Loan[];
  currentSession: string;
  onNavigate: (tab: string) => void;
}

export default function Dashboard({ pupils, books, loans, currentSession, onNavigate }: DashboardProps) {
  // Filter active pupils and loans for current session
  const activePupils = pupils.filter(p => !p.isArchived && p.session === currentSession);
  const totalActivePupils = activePupils.length;

  // Active loans for current session
  const activeLoans = loans.filter(l => l.session === currentSession);
  
  // Calculate book stats
  const totalLent = activeLoans.filter(l => l.status === 'Dipinjam').length;
  const totalReturned = activeLoans.filter(l => l.status === 'Dipulangkan').length;
  const totalLost = activeLoans.filter(l => l.status === 'Hilang').length;
  const totalDamaged = activeLoans.filter(l => l.status === 'Rosak').length;
  
  // Peratus Pemulangan = (Returned / Total loans created) * 100
  // Total loans created is basically anywhere status is not Belum Dipinjam, which is everything in activeLoans
  const totalProcessedLoans = activeLoans.length;
  const returnPercentage = totalProcessedLoans > 0 
    ? Math.round((totalReturned / totalProcessedLoans) * 100) 
    : 0;

  // Distribution by year for returning textbooks
  const years = [1, 2, 3, 4, 5, 6];
  const yearStats = years.map(yr => {
    const pupilsInYear = activePupils.filter(p => p.year === yr).map(p => p.id);
    const loansInYear = activeLoans.filter(l => pupilsInYear.includes(l.pupilId));
    const returnedInYear = loansInYear.filter(l => l.status === 'Dipulangkan').length;
    const totalInYear = loansInYear.length;
    const pct = totalInYear > 0 ? Math.round((returnedInYear / totalInYear) * 100) : 0;
    return { year: yr, total: totalInYear, returned: returnedInYear, pct };
  });

  return (
    <div className="space-y-8 animate-fade-in">
      {/* Header Sesi dengan Estetika Editorial */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between bg-white dark:bg-slate-900 border border-stone-200 dark:border-slate-800 p-8 rounded-xl shadow-xs gap-4 relative overflow-hidden">
        <div className="absolute top-0 left-0 w-2 h-full bg-slate-900 dark:bg-emerald-600" />
        <div className="flex items-center gap-4 pl-2">
          <SchoolLogo className="w-12 h-12 shrink-0 hidden sm:block" />
          <div>
            <h2 className="text-2xl font-sans font-bold text-slate-900 dark:text-white tracking-tight">Sistem Pengurusan SPBT</h2>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5 uppercase tracking-wider font-mono">Rekod Digital - SK Felda Lui Muda</p>
          </div>
        </div>
        <div className="flex items-center gap-2 bg-slate-900 dark:bg-emerald-950 text-white dark:text-emerald-400 border border-slate-800 dark:border-emerald-800/60 px-5 py-2.5 rounded-lg text-xs font-mono font-bold self-start md:self-auto shadow-sm">
          <GraduationCap className="w-4 h-4 text-emerald-400" />
          <span>SESI AKTIF: {currentSession}</span>
        </div>
      </div>

      {/* Grid Ringkasan (Stats) - Reka Bentuk Editorial Kemas */}
      <div className="grid grid-cols-2 lg:grid-cols-6 gap-4">
        {/* Murid Aktif */}
        <div className="bg-white dark:bg-slate-900 border border-stone-200 dark:border-slate-800 p-5 rounded-lg shadow-2xs flex flex-col justify-between transition-all hover:shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider font-mono">Murid Aktif</span>
            <span className="p-1.5 bg-slate-50 dark:bg-slate-850 text-slate-700 dark:text-emerald-400 rounded border border-stone-150 dark:border-slate-750">
              <Users className="w-3.5 h-3.5" />
            </span>
          </div>
          <div className="mt-4">
            <h3 className="text-3xl font-sans font-extrabold text-slate-900 dark:text-white">{totalActivePupils}</h3>
            <p className="text-[10px] text-slate-400 dark:text-slate-500 uppercase tracking-widest mt-1">orang murid aktif</p>
          </div>
        </div>

        {/* Buku Dipinjam */}
        <div className="bg-white dark:bg-slate-900 border border-stone-200 dark:border-slate-800 p-5 rounded-lg shadow-2xs flex flex-col justify-between transition-all hover:shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider font-mono">Pinjaman</span>
            <span className="p-1.5 bg-slate-50 dark:bg-slate-850 text-amber-600 dark:text-amber-400 rounded border border-stone-150 dark:border-slate-750">
              <BookOpen className="w-3.5 h-3.5" />
            </span>
          </div>
          <div className="mt-4">
            <h3 className="text-3xl font-sans font-extrabold text-slate-900 dark:text-white">{totalLent}</h3>
            <p className="text-[10px] text-slate-400 dark:text-slate-500 uppercase tracking-widest mt-1">buku dipinjam</p>
          </div>
        </div>

        {/* Buku Dipulangkan */}
        <div className="bg-white dark:bg-slate-900 border border-stone-200 dark:border-slate-800 p-5 rounded-lg shadow-2xs flex flex-col justify-between transition-all hover:shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider font-mono">Pulang</span>
            <span className="p-1.5 bg-slate-50 dark:bg-slate-850 text-emerald-600 dark:text-emerald-400 rounded border border-stone-150 dark:border-slate-750">
              <CheckCircle className="w-3.5 h-3.5" />
            </span>
          </div>
          <div className="mt-4">
            <h3 className="text-3xl font-sans font-extrabold text-slate-900 dark:text-white">{totalReturned}</h3>
            <p className="text-[10px] text-slate-400 dark:text-slate-500 uppercase tracking-widest mt-1">buku dipulang</p>
          </div>
        </div>

        {/* Buku Hilang */}
        <div className="bg-white dark:bg-slate-900 border border-stone-200 dark:border-slate-800 p-5 rounded-lg shadow-2xs flex flex-col justify-between transition-all hover:shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider font-mono">Hilang</span>
            <span className="p-1.5 bg-rose-50 dark:bg-rose-950/20 text-rose-600 dark:text-rose-400 rounded border border-rose-100 dark:border-rose-950/30">
              <XCircle className="w-3.5 h-3.5" />
            </span>
          </div>
          <div className="mt-4">
            <h3 className="text-3xl font-sans font-extrabold text-slate-900 dark:text-white">{totalLost}</h3>
            <p className="text-[10px] text-rose-600 dark:text-rose-400 mt-1 uppercase tracking-widest font-bold">perlu ganti</p>
          </div>
        </div>

        {/* Buku Rosak */}
        <div className="bg-white dark:bg-slate-900 border border-stone-200 dark:border-slate-800 p-5 rounded-lg shadow-2xs flex flex-col justify-between transition-all hover:shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider font-mono">Rosak</span>
            <span className="p-1.5 bg-orange-50 dark:bg-orange-950/20 text-orange-600 dark:text-orange-400 rounded border border-orange-100 dark:border-orange-950/30">
              <AlertTriangle className="w-3.5 h-3.5" />
            </span>
          </div>
          <div className="mt-4">
            <h3 className="text-3xl font-sans font-extrabold text-slate-900 dark:text-white">{totalDamaged}</h3>
            <p className="text-[10px] text-orange-600 dark:text-orange-400 mt-1 uppercase tracking-widest font-bold">perlu ganti</p>
          </div>
        </div>

        {/* Peratus Pemulangan */}
        <div className="bg-white dark:bg-slate-900 border border-stone-200 dark:border-slate-800 p-5 rounded-lg shadow-2xs flex flex-col justify-between transition-all hover:shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider font-mono">Kadar</span>
            <span className="p-1.5 bg-slate-50 dark:bg-slate-850 text-slate-700 dark:text-emerald-400 rounded border border-stone-150 dark:border-slate-750">
              <TrendingUp className="w-3.5 h-3.5" />
            </span>
          </div>
          <div className="mt-4">
            <h3 className="text-3xl font-sans font-extrabold text-slate-900 dark:text-white">{returnPercentage}%</h3>
            <p className="text-[10px] text-slate-400 dark:text-slate-500 uppercase tracking-widest mt-1">kadar selesai</p>
          </div>
        </div>
      </div>

      {/* Grid Kandungan Utama */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        
        {/* Pilihan Utama Modul */}
        <div className="md:col-span-2 space-y-6">
          <h4 className="text-xs font-bold text-slate-400 dark:text-slate-500 uppercase tracking-widest font-mono border-b border-stone-200 dark:border-slate-800 pb-2">Pintasan Dokumentari & Tindakan</h4>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            {/* Peminjaman */}
            <button
              id="dashboard_pinjam_btn"
              onClick={() => onNavigate('pinjam')} 
              className="group bg-white dark:bg-slate-900 border border-stone-200 dark:border-slate-800 p-6 rounded-xl hover:border-slate-900 dark:hover:border-emerald-700 hover:shadow-md transition-all text-left flex flex-col justify-between h-44 shadow-2xs cursor-pointer"
            >
              <div className="p-2.5 bg-stone-50 dark:bg-slate-800 border border-stone-250/50 dark:border-slate-700 text-slate-800 dark:text-emerald-400 rounded group-hover:scale-105 transition-transform self-start">
                <BookOpen className="w-5 h-5" />
              </div>
              <div>
                <h3 className="font-sans font-bold text-slate-900 dark:text-white text-base group-hover:text-emerald-600 dark:group-hover:text-emerald-400 transition-colors">📚 Peminjaman</h3>
                <p className="text-[11px] text-slate-400 dark:text-slate-500 mt-1 leading-normal">Serahan buku teks baharu & rekod kelulusan kelas siri digital.</p>
              </div>
            </button>

            {/* Pemulangan */}
            <button
              id="dashboard_pulang_btn"
              onClick={() => onNavigate('pulang')}
              className="group bg-white dark:bg-slate-900 border border-stone-200 dark:border-slate-800 p-6 rounded-xl hover:border-slate-900 dark:hover:border-emerald-700 hover:shadow-md transition-all text-left flex flex-col justify-between h-44 shadow-2xs cursor-pointer"
            >
              <div className="p-2.5 bg-stone-50 dark:bg-slate-800 border border-stone-250/50 dark:border-slate-700 text-slate-800 dark:text-emerald-400 rounded group-hover:scale-105 transition-transform self-start">
                <CheckCircle className="w-5 h-5" />
              </div>
              <div>
                <h3 className="font-sans font-bold text-slate-900 dark:text-white text-base group-hover:text-emerald-600 dark:group-hover:text-emerald-400 transition-colors">📥 Pemulangan</h3>
                <p className="text-[11px] text-slate-400 dark:text-slate-500 mt-1 leading-normal">Penerimaan kembali buku berserta pengiraan denda, hilang & rosak.</p>
              </div>
            </button>

            {/* Laporan */}
            <button
              id="dashboard_laporan_btn"
              onClick={() => onNavigate('laporan')}
              className="group bg-white dark:bg-slate-900 border border-stone-200 dark:border-slate-800 p-6 rounded-xl hover:border-slate-900 dark:hover:border-emerald-700 hover:shadow-md transition-all text-left flex flex-col justify-between h-44 shadow-2xs cursor-pointer"
            >
              <div className="p-2.5 bg-stone-50 dark:bg-slate-800 border border-stone-250/50 dark:border-slate-700 text-slate-800 dark:text-violet-400 rounded group-hover:scale-105 transition-transform self-start">
                <TrendingUp className="w-5 h-5" />
              </div>
              <div>
                <h3 className="font-sans font-bold text-slate-900 dark:text-white text-base group-hover:text-violet-600 dark:group-hover:text-violet-400 transition-colors">📊 Laporan SPBT</h3>
                <p className="text-[11px] text-slate-400 dark:text-slate-500 mt-1 leading-normal">Analitis menyeluruh, cetakan dokumen rasmi, penapis gred cemerlang.</p>
              </div>
            </button>
          </div>

          {/* Status Pemulangan Buku mengikut Tahun */}
          <div className="bg-white dark:bg-slate-900 border border-stone-200 dark:border-slate-800 p-8 rounded-xl shadow-2xs">
            <h4 className="font-sans font-bold text-slate-950 dark:text-white text-base mb-6">Prestasi Pengembalian Mengikut Tahun Penilaian</h4>
            <div className="space-y-5">
              {yearStats.map(stat => (
                <div key={stat.year} className="space-y-1.5">
                  <div className="flex justify-between text-xs font-bold">
                    <span className="text-slate-700 dark:text-slate-350 font-mono">TAHUN {stat.year}</span>
                    <span className="text-slate-500 dark:text-slate-400 font-mono">
                      {stat.returned} / {stat.total} unit ({stat.pct}%)
                    </span>
                  </div>
                  <div className="w-full bg-stone-100 dark:bg-slate-800 h-2 rounded-full overflow-hidden border border-stone-200/40 dark:border-slate-700/30">
                    <div 
                      className={`h-full rounded-full transition-all duration-500 ${
                        stat.pct >= 85 
                          ? 'bg-emerald-500' 
                          : stat.pct >= 45 
                            ? 'bg-amber-500' 
                            : 'bg-rose-500'
                      }`}
                      style={{ width: `${stat.pct}%` }}
                    />
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Makluman & Pemantauan Pengawas SPBT */}
        <div className="space-y-6">
          <h4 className="text-xs font-bold text-slate-400 dark:text-slate-500 uppercase tracking-widest font-mono border-b border-stone-200 dark:border-slate-800 pb-2">Status & Tindakan</h4>
          
          <div className="bg-white dark:bg-slate-900 border border-stone-200 dark:border-slate-800 p-6 rounded-xl shadow-2xs space-y-5">
            <h5 className="font-sans font-bold text-slate-900 dark:text-white text-sm flex items-center gap-1.5">
              <ShieldAlert className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
              Garis Panduan Sesi Digital
            </h5>
            
            <div className="space-y-4 text-xs">
              <div className="p-3.5 bg-rose-50/50 dark:bg-rose-950/15 border border-rose-100/75 dark:border-rose-900/30 rounded-lg space-y-1">
                <span className="font-bold text-rose-800 dark:text-rose-400 uppercase tracking-wider font-mono text-[10px]">Tindakan Segera</span>
                <p className="text-slate-600 dark:text-slate-300 leading-relaxed text-[11px]">
                  Semua kes status <strong className="font-semibold">"Hilang"</strong> atau <strong className="font-semibold">"Rosak"</strong> hendaklah dikilangkan ke rekod Google Sheets supaya perolehan ganti boleh dipantau guru besar.
                </p>
              </div>

              <div className="p-3.5 bg-amber-50/50 dark:bg-amber-950/15 border border-amber-100/75 dark:border-amber-900/30 rounded-lg space-y-1">
                <span className="font-bold text-amber-800 dark:text-amber-400 uppercase tracking-wider font-mono text-[10px]">Pemberitahuan Promosi</span>
                <p className="text-slate-600 dark:text-slate-300 leading-relaxed text-[11px]">
                  Tandas peratus sesi lama sebelum mencetus <strong className="font-semibold">"Naik Sesi Baru"</strong>. Siri kenaikan automatik meluluskan Tahun 1-5 ke tahun gred berikutnya.
                </p>
              </div>

              <div className="p-3.5 bg-slate-50 dark:bg-slate-850/65 border border-stone-200 dark:border-slate-750 rounded-lg space-y-1">
                <span className="font-bold text-slate-800 dark:text-emerald-450 uppercase tracking-wider font-mono text-[10px]">Google Sheets Sync</span>
                <p className="text-slate-600 dark:text-slate-300 leading-relaxed text-[11px]">
                  Konfigurasi pautan Apps Script di tab Web untuk membolehkan guru memantau status secara bersekutu pada telefon bimbit & tablet.
                </p>
              </div>
            </div>
            
            <button 
              id="dashboard_buku_btn"
              onClick={() => onNavigate('buku')}
              className="w-full flex items-center justify-between text-xs font-bold text-slate-900 dark:text-emerald-400 hover:text-emerald-700 dark:hover:text-emerald-350 p-2.5 hover:bg-stone-50 dark:hover:bg-slate-800/50 border border-stone-200 dark:border-slate-800 rounded-lg transition-all cursor-pointer"
            >
              <span className="font-mono uppercase tracking-wider text-[10px]">Senarai Indeks Buku Teks</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
