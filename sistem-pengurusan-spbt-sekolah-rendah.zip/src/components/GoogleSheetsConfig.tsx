import React, { useState } from 'react';
import { APPS_SCRIPT_TEMPLATE } from '../utils/googleSheetsSync';
import { Database, Link, Copy, Check, UploadCloud, DownloadCloud, AlertCircle, HelpCircle, Save } from 'lucide-react';
import { SystemData } from '../types';

interface GoogleSheetsConfigProps {
  sheetUrl: string;
  onSaveUrl: (url: string) => void;
  onPullData: () => Promise<void>;
  onPushData: () => Promise<void>;
  syncStatus: 'idle' | 'syncing' | 'success' | 'error';
  lastSyncDate: string | null;
  errorMessage: string | null;
}

export default function GoogleSheetsConfig({
  sheetUrl,
  onSaveUrl,
  onPullData,
  onPushData,
  syncStatus,
  lastSyncDate,
  errorMessage
}: GoogleSheetsConfigProps) {
  const [urlInput, setUrlInput] = useState(sheetUrl);
  const [copied, setCopied] = useState(false);
  const [isSaving, setIsSaving] = useState(false);

  const handleCopyCode = () => {
    navigator.clipboard.writeText(APPS_SCRIPT_TEMPLATE);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleSaveUrl = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSaving(true);
    onSaveUrl(urlInput.trim());
    setTimeout(() => {
      setIsSaving(false);
      alert('Alamat sambungan Google Apps Script berjaya disimpan!');
    }, 500);
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 animate-fade-in">
      
      {/* Kolum Kiri: Pautan & Pengurusan Sincronisasi */}
      <div className="space-y-6">
        
        {/* Status Penyambungan & Borang URL */}
        <div className="bg-white dark:bg-slate-900 border border-stone-200 dark:border-slate-800 p-6 rounded-xl shadow-2xs space-y-4">
          <div className="flex items-center gap-2 text-slate-850 dark:text-emerald-400 border-b border-stone-100 dark:border-slate-800 pb-3">
            <Link className="w-4 h-4 text-emerald-500" />
            <h3 className="font-sans font-bold text-slate-950 dark:text-white text-base">Sambungan Google Sheets</h3>
          </div>

          <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed font-sans">
            Sistem pengurusan ini menyokong penyimpanan di Google Sheets sebagai pangkalan data awan. Ini membolehkan data diakses secara masa nyata dan selamat tanpa sebarang bil bulanan.
          </p>

          <form onSubmit={handleSaveUrl} className="space-y-4">
            <div>
              <label className="block text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-widest font-mono mb-1.5">GOOGLE APPS SCRIPT WEB APP URL</label>
              <input
                id="sheets_url_input"
                type="url"
                required
                placeholder="https://script.google.com/macros/s/.../exec"
                value={urlInput}
                onChange={(e) => setUrlInput(e.target.value)}
                className="w-full bg-stone-50/50 dark:bg-slate-950 border border-stone-200 dark:border-slate-850 rounded-lg px-4 py-2.5 text-xs text-slate-950 dark:text-white font-mono focus:outline-none focus:border-slate-900 dark:focus:border-emerald-600 focus:bg-white transition-colors"
              />
            </div>

            <button
              id="sheets_save_url_btn"
              type="submit"
              disabled={isSaving}
              className="w-full bg-slate-900 hover:bg-slate-800 dark:bg-emerald-950 dark:hover:bg-emerald-900 text-white dark:text-emerald-400 font-bold py-2.5 px-4 rounded-lg text-xs uppercase tracking-wider font-mono border border-slate-900 dark:border-emerald-800 transition-all shadow-xs flex items-center justify-center gap-1.5 cursor-pointer"
            >
              <Save className="w-3.5 h-3.5" />
              <span>{isSaving ? 'Menyimpan...' : 'Simpan dan Uji Pautan'}</span>
            </button>
          </form>

          {/* Sincronis Status Card */}
          {sheetUrl && (
            <div className="bg-stone-50 dark:bg-slate-950 p-4.5 border border-stone-200 dark:border-slate-850 rounded-lg space-y-4">
              <span className="text-[10px] text-slate-400 dark:text-slate-500 font-bold block uppercase tracking-wider font-mono">Status Komunikasi Data</span>
              
              <div className="flex items-center justify-between text-xs font-sans">
                <span className="text-slate-650 dark:text-slate-300">Integrasi Google Sheets:</span>
                <span className="inline-flex items-center gap-1.5 font-bold">
                  <span className={`w-2 h-2 rounded-full ${syncStatus === 'error' ? 'bg-rose-500' : 'bg-emerald-500 animate-pulse'}`} />
                  {syncStatus === 'error' ? (
                    <span className="text-rose-600 font-mono text-[11px] uppercase tracking-wider">Terputus / Ralat</span>
                  ) : (
                    <span className="text-emerald-600 font-mono text-[11px] uppercase tracking-wider">Aktif & Sedia</span>
                  )}
                </span>
              </div>

              {lastSyncDate && (
                <div className="flex items-center justify-between text-xs text-slate-500 dark:text-slate-405 font-mono">
                  <span>Penyelarasan Terakhir:</span>
                  <span>{lastSyncDate}</span>
                </div>
              )}

              {errorMessage && (
                <div className="p-3 bg-rose-50 dark:bg-rose-950/20 border border-rose-100 rounded text-[11px] text-rose-550 font-medium flex items-start gap-1.5 leading-relaxed font-sans">
                  <AlertCircle className="w-3.5 h-3.5 mt-0.5 shrink-0" />
                  <span>{errorMessage}</span>
                </div>
              )}

              {/* Aksi Sincronis */}
              <div className="grid grid-cols-2 gap-2 pt-2">
                <button
                  id="sheets_pull_data_btn"
                  onClick={onPullData}
                  disabled={syncStatus === 'syncing'}
                  className="flex items-center justify-center gap-1.5 py-2 px-3 border border-stone-200 hover:bg-stone-55 dark:border-slate-800 dark:hover:bg-slate-850 rounded-lg text-xs font-bold text-slate-700 dark:text-slate-300 transition-all cursor-pointer"
                >
                  <DownloadCloud className="w-3.5 h-3.5" />
                  <span>Tarik Data</span>
                </button>
                
                <button
                  id="sheets_push_data_btn"
                  onClick={onPushData}
                  disabled={syncStatus === 'syncing'}
                  className="flex items-center justify-center gap-1.5 py-2 px-3 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-xs font-bold transition-all cursor-pointer shadow-3xs"
                >
                  <UploadCloud className="w-3.5 h-3.5" />
                  <span>Hantar Data</span>
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Penerangan Manfaat Web Apps Script */}
        <div className="bg-stone-50 dark:bg-slate-950/45 border border-stone-200 dark:border-slate-800 rounded-lg p-5 space-y-3 font-sans">
          <h4 className="font-sans font-bold text-slate-900 dark:text-white text-sm flex items-center gap-1.5">
            <HelpCircle className="w-4 h-4 text-emerald-500" />
            Mengapa menggunakan Google Apps Script?
          </h4>
          <ol className="list-decimal list-inside text-[11px] text-slate-650 dark:text-slate-400 space-y-2 leading-relaxed">
            <li>Menghubungkan sistem web ini terus dengan Google Sheets akaun Delima / peribadi secara masa nyata.</li>
            <li>Menggelakkan pendedahan kunci API sensitif atau persediaan konsol Google Cloud yang sangat rumit.</li>
            <li>Menulis semua rekod peminjaman dan pemulangan buku secara automatik di latar belakang.</li>
            <li>Sistem akan terus beroperasi secara Local-First sekiranya pautan Sheets tidak diisi, memudahkan anda mengujinya sedia kala!</li>
          </ol>
        </div>
      </div>

      {/* Kolum Kanan: Salinan Kod Google Apps Script */}
      <div className="bg-white dark:bg-slate-900 border border-stone-200 dark:border-slate-800 p-6 rounded-xl shadow-2xs space-y-4 flex flex-col justify-between">
        <div className="space-y-3">
          <div className="flex items-center justify-between border-b border-stone-100 dark:border-slate-800 pb-3">
            <h3 className="font-sans font-bold text-slate-950 dark:text-white text-base flex items-center gap-1.5">
              <Database className="w-4 h-4 text-emerald-500" />
              Skrip Integrasi Google Apps Script
            </h3>
            <button
              id="btn_copy_script"
              onClick={handleCopyCode}
              className="flex items-center gap-1.5 text-[10px] font-bold font-mono tracking-wider uppercase text-slate-700 hover:text-slate-905 dark:text-slate-300 dark:hover:text-white bg-stone-50 hover:bg-stone-100 dark:bg-slate-850 dark:hover:bg-slate-800 border border-stone-200 dark:border-slate-750 px-3 py-1.5 rounded transition-all cursor-pointer"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-500" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copied ? 'Disalin!' : 'Salin Skrip'}</span>
            </button>
          </div>
          <p className="text-[11px] text-slate-500 dark:text-slate-400 leading-relaxed font-sans">
            Sila salin kod lengkap di bawah, dan tampalkannya di dalam editor <strong>"Extensions" &gt; "Apps Script"</strong> di fail Google Sheet anda. Kemudian pilih "Deploy" sebagai Web App dengan akses "Anyone".
          </p>
        </div>

        <div className="relative flex-1 bg-stone-950 dark:bg-slate-950 text-slate-300 rounded-lg p-4 font-mono text-[10px] overflow-auto max-h-[280px] border border-stone-850 dark:border-slate-850 mt-2">
          <pre className="whitespace-pre">{APPS_SCRIPT_TEMPLATE}</pre>
        </div>
      </div>

    </div>
  );
}
