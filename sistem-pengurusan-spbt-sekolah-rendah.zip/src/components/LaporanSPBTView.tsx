import { useState } from 'react';
import { Book, Pupil, Loan } from '../types';
import { 
  TrendingUp, 
  BookOpen, 
  CheckCircle, 
  XCircle, 
  AlertTriangle, 
  Search, 
  Printer, 
  FileDown, 
  Filter,
  GraduationCap
} from 'lucide-react';

interface LaporanSPBTViewProps {
  pupils: Pupil[];
  books: Book[];
  loans: Loan[];
  currentSession: string;
}

export default function LaporanSPBTView({ pupils, books, loans, currentSession }: LaporanSPBTViewProps) {
  // Saring mengikut Tahun, Kelas, Sesi dan Status Buku
  const [filterYear, setFilterYear] = useState<string>('all');
  const [filterClass, setFilterClass] = useState<string>('all');
  const [filterStatus, setFilterStatus] = useState<string>('all');
  const [filterSession, setFilterSession] = useState<string>(currentSession);

  // Cari sesi yang unik di dalam pangkalan data
  const uniqueSessions = Array.from(new Set(pupils.map(p => p.session || currentSession))).sort();

  // Cari nama kelas sekiranya ada
  const filteredClassesPupils = pupils.filter(p => filterSession === 'all' ? true : p.session === filterSession);
  const uniqueClassesList = Array.from(new Set(filteredClassesPupils.map(p => p.className))).filter(Boolean);

  // Saring murid berdasarkan sesi terlebih dahulu
  const targetPupils = pupils.filter(p => {
    const matchesSession = filterSession === 'all' ? true : p.session === filterSession;
    const matchesYear = filterYear === 'all' ? true : p.year === parseInt(filterYear);
    const matchesClass = filterClass === 'all' ? true : p.className === filterClass;
    return matchesSession && matchesYear && matchesClass;
  });

  const targetPupilIds = targetPupils.map(p => p.id);

  // Semak rekod pinjaman bagi kumpulan murid ini
  const targetLoans = loans.filter(l => {
    // Saring mengikut murid sasaran
    const matchesPupil = targetPupilIds.includes(l.pupilId);
    // Saring mengikut status
    const matchesStatus = filterStatus === 'all' ? true : l.status === filterStatus;
    // Saring mengikut sesi pinjaman
    const matchesSession = filterSession === 'all' ? true : l.session === filterSession;
    
    return matchesPupil && matchesStatus && matchesSession;
  });

  // Statistik Laporan Keseluruhan berdasarkan penapis
  const countLent = targetLoans.filter(l => l.status === 'Dipinjam').length;
  const countReturned = targetLoans.filter(l => l.status === 'Dipulangkan').length;
  const countLost = targetLoans.filter(l => l.status === 'Hilang').length;
  const countDamaged = targetLoans.filter(l => l.status === 'Rosak').length;
  const totalLoansProcessed = targetLoans.length;

  const returnPercentage = totalLoansProcessed > 0
    ? Math.round((countReturned / totalLoansProcessed) * 100)
    : 0;

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="space-y-8 animate-fade-in">
      
      {/* Bahagian Penapis (Filter) - Gaya Editorial Menawan */}
      <div className="bg-white dark:bg-slate-900 border border-stone-200 dark:border-slate-800 p-5 rounded-xl shadow-2xs space-y-4 print:hidden">
        <div className="flex items-center justify-between border-b border-stone-100 dark:border-slate-800 pb-3">
          <h3 className="font-sans font-bold text-slate-900 dark:text-white text-base flex items-center gap-1.5">
            <Filter className="w-4 h-4 text-emerald-500" />
            Saring Statistik Buku SPBT
          </h3>
          
          <div className="flex gap-2">
            <button
              id="btn_print_penerima"
              onClick={handlePrint}
              className="flex items-center gap-1.5 bg-stone-50 hover:bg-stone-100 dark:bg-slate-850 dark:hover:bg-slate-800 text-slate-700 dark:text-slate-200 text-[10px] font-bold font-mono tracking-wider uppercase py-2 px-3 border border-stone-200 dark:border-slate-750 rounded transition-all cursor-pointer"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>Cetak Laporan</span>
            </button>
            <button
              id="btn_export_pdf"
              onClick={handlePrint}
              className="flex items-center gap-1.5 bg-slate-900 hover:bg-slate-800 dark:bg-emerald-950 dark:hover:bg-emerald-900 text-white dark:text-emerald-400 text-[10px] font-bold font-mono tracking-wider uppercase py-2 px-3 border border-slate-900 dark:border-emerald-800 rounded transition-all cursor-pointer shadow-xs"
            >
              <FileDown className="w-3.5 h-3.5" />
              <span>Eksport PDF</span>
            </button>
          </div>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {/* Sesi */}
          <div>
            <label className="block text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-wider font-mono mb-1.5">Sesi Persekolahan</label>
            <select
              id="lap_saring_sesi"
              value={filterSession}
              onChange={(e) => {
                setFilterSession(e.target.value);
                setFilterClass('all'); // Reset class filter when session changes
              }}
              className="w-full bg-stone-50/50 dark:bg-slate-950 border border-stone-200 dark:border-slate-850 rounded-lg px-3 py-2 text-xs font-bold text-slate-700 dark:text-slate-350 focus:outline-none focus:border-slate-900 dark:focus:border-emerald-600 focus:bg-white transition-colors"
            >
              <option value="all">Semua Sesi</option>
              {uniqueSessions.map(sess => (
                <option key={sess} value={sess}>Sesi {sess}</option>
              ))}
            </select>
          </div>

          {/* Tahun */}
          <div>
            <label className="block text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-wider font-mono mb-1.5">Tahun / Gred</label>
            <select
              id="lap_saring_tahun"
              value={filterYear}
              onChange={(e) => setFilterYear(e.target.value)}
              className="w-full bg-stone-50/50 dark:bg-slate-950 border border-stone-200 dark:border-slate-850 rounded-lg px-3 py-2 text-xs font-bold text-slate-700 dark:text-slate-350 focus:outline-none focus:border-slate-900 dark:focus:border-emerald-600 focus:bg-white transition-colors"
            >
              <option value="all">Semua Tahun</option>
              <option value="1">Tahun 1</option>
              <option value="2">Tahun 2</option>
              <option value="3">Tahun 3</option>
              <option value="4">Tahun 4</option>
              <option value="5">Tahun 5</option>
              <option value="6">Tahun 6</option>
            </select>
          </div>

          {/* Kelas */}
          <div>
            <label className="block text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-wider font-mono mb-1.5">Kumpulan Kelas</label>
            <select
              id="lap_saring_kelas"
              value={filterClass}
              onChange={(e) => setFilterClass(e.target.value)}
              className="w-full bg-stone-50/50 dark:bg-slate-950 border border-stone-200 dark:border-slate-850 rounded-lg px-3 py-2 text-xs font-bold text-slate-700 dark:text-slate-350 focus:outline-none focus:border-slate-900 dark:focus:border-emerald-600 focus:bg-white transition-colors"
            >
              <option value="all">Semua Kelas</option>
              {uniqueClassesList.map(cls => (
                <option key={cls} value={cls}>{cls}</option>
              ))}
            </select>
          </div>

          {/* Status Buku */}
          <div>
            <label className="block text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-wider font-mono mb-1.5">Status Buku</label>
            <select
              id="lap_saring_status"
              value={filterStatus}
              onChange={(e) => setFilterStatus(e.target.value)}
              className="w-full bg-stone-50/50 dark:bg-slate-950 border border-stone-200 dark:border-slate-850 rounded-lg px-3 py-2 text-xs font-bold text-slate-700 dark:text-slate-350 focus:outline-none focus:border-slate-900 dark:focus:border-emerald-600 focus:bg-white transition-colors"
            >
              <option value="all">Semua Status</option>
              <option value="Dipinjam">Dipinjam</option>
              <option value="Dipulangkan">Dipulangkan</option>
              <option value="Hilang">Hilang</option>
              <option value="Rosak">Rosak</option>
            </select>
          </div>
        </div>
      </div>

      {/* Bahagian Kad Statistik Laporan - Rekabentuk Lembaran Berita Klasik */}
      <div className="bg-white dark:bg-slate-900 border border-stone-200 dark:border-slate-800 p-6 sm:p-8 rounded-xl shadow-2xs space-y-6 print:border-none print:shadow-none print:p-0">
        
        {/* Kepala Cetak Laporan */}
        <div className="border-b border-stone-200 dark:border-slate-800 pb-5 flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div className="space-y-1">
            <span className="text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-widest font-mono block">DOKUMEN INTEGRAL RASMI</span>
            <h2 className="text-xl font-sans font-bold text-slate-900 dark:text-white">Laporan Statistik Skim Pinjaman Buku Teks (SPBT)</h2>
            <p className="text-xs text-slate-500 dark:text-slate-400 font-sans">
              Sesi: <span className="font-mono">{filterSession === 'all' ? 'SEMUA SESI' : filterSession}</span> • Kelas: <span className="font-mono">{filterClass === 'all' ? 'SEMUA' : filterClass.toUpperCase()}</span> • Tahun: <span className="font-mono">{filterYear === 'all' ? 'SEMUA' : `TAHUN ${filterYear}`}</span>
            </p>
          </div>
          <div className="bg-stone-50 dark:bg-slate-950/60 border border-stone-200 dark:border-slate-850 p-4 rounded-lg flex items-center gap-3 self-start md:self-auto">
            <TrendingUp className="w-6 h-6 text-emerald-500" />
            <div>
              <p className="text-[9px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-wider font-mono">Kadar Pemulangan</p>
              <h3 className="text-lg font-bold font-mono text-emerald-600 dark:text-emerald-400">{returnPercentage}%</h3>
            </div>
          </div>
        </div>

        {/* Ringkasan Grid Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 font-sans">
          <div className="p-4.5 bg-stone-50 dark:bg-slate-950/60 border border-stone-200 dark:border-slate-850 rounded-lg">
            <div className="flex justify-between items-center text-slate-400">
              <span className="text-[10px] font-bold tracking-widest uppercase font-mono text-slate-400 dark:text-slate-500">Dipinjam</span>
              <BookOpen className="w-3.5 h-3.5 text-amber-500" />
            </div>
            <h3 className="text-2xl font-bold font-mono text-slate-850 dark:text-white mt-2">{countLent}</h3>
            <p className="text-[10px] text-slate-400 dark:text-slate-500 font-mono">Buku di tangan murid</p>
          </div>

          <div className="p-4.5 bg-emerald-50/50 dark:bg-emerald-950/15 border border-emerald-100/60 dark:border-emerald-900/10 rounded-lg">
            <div className="flex justify-between items-center text-emerald-600 dark:text-emerald-400">
              <span className="text-[10px] font-bold tracking-widest uppercase font-mono text-emerald-600 dark:text-emerald-500">Dipulangkan</span>
              <CheckCircle className="w-3.5 h-3.5" />
            </div>
            <h3 className="text-2xl font-bold font-mono text-emerald-800 dark:text-emerald-400 mt-2">{countReturned}</h3>
            <p className="text-[10px] text-emerald-600 dark:text-emerald-500 font-mono">Dikembalikan selamat</p>
          </div>

          <div className="p-4.5 bg-rose-50/50 dark:bg-rose-950/15 border border-rose-100/60 dark:border-rose-900/10 rounded-lg">
            <div className="flex justify-between items-center text-rose-600 dark:text-rose-450">
              <span className="text-[10px] font-bold tracking-widest uppercase font-mono text-rose-600 dark:text-rose-500">Hilang</span>
              <XCircle className="w-3.5 h-3.5" />
            </div>
            <h3 className="text-2xl font-bold font-mono text-rose-800 dark:text-rose-400 mt-2">{countLost}</h3>
            <p className="text-[10px] text-rose-600 dark:text-rose-500 font-mono">Perlu ganti perolehan</p>
          </div>

          <div className="p-4.5 bg-amber-50/50 dark:bg-amber-950/15 border border-amber-100/60 dark:border-amber-900/10 rounded-lg">
            <div className="flex justify-between items-center text-amber-600 dark:text-amber-450">
              <span className="text-[10px] font-bold tracking-widest uppercase font-mono text-amber-600 dark:text-amber-500">Rosak</span>
              <AlertTriangle className="w-3.5 h-3.5" />
            </div>
            <h3 className="text-2xl font-bold font-mono text-amber-800 dark:text-amber-400 mt-2">{countDamaged}</h3>
            <p className="text-[10px] text-amber-600 dark:text-amber-550 font-mono">Gred lusuh / rosak</p>
          </div>
        </div>

        {/* Butiran Senarai mengikut Murid Terhasil */}
        <div className="space-y-4 pt-4">
          <h4 className="font-sans font-bold text-slate-900 dark:text-white text-base">Butiran Pengedaran Buku Teks mengikut Individu</h4>
          
          <div className="border border-stone-200 dark:border-slate-800 rounded-lg overflow-hidden shadow-3xs">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="bg-stone-50 dark:bg-slate-950 text-slate-500 dark:text-slate-400 text-[10px] font-bold uppercase tracking-wider border-b border-stone-200 dark:border-slate-850 font-mono">
                  <th className="px-6 py-3.5">Nama Murid</th>
                  <th className="px-4 py-3.5">Tahun</th>
                  <th className="px-4 py-3.5">Kelas</th>
                  <th className="px-4 py-3.5 text-center">Dipinjam</th>
                  <th className="px-4 py-3.5 text-center">Pulang</th>
                  <th className="px-4 py-3.5 text-center">Hilang</th>
                  <th className="px-4 py-3.5 text-center">Rosak</th>
                  <th className="px-6 py-3.5 text-right">Status Sesi</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-stone-100 dark:divide-slate-800/60 bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-350">
                {targetPupils.length === 0 ? (
                  <tr>
                    <td colSpan={8} className="p-12 text-center text-slate-400 dark:text-slate-500 font-medium">
                      Tiada data murid padanan sedia ada.
                    </td>
                  </tr>
                ) : (
                  targetPupils.map((pupil) => {
                    const pupilLoans = loans.filter(l => l.pupilId === pupil.id && (filterSession === 'all' ? true : l.session === filterSession));
                    const lCurrent = pupilLoans.filter(l => l.status === 'Dipinjam').length;
                    const rCurrent = pupilLoans.filter(l => l.status === 'Dipulangkan').length;
                    const lostCurrent = pupilLoans.filter(l => l.status === 'Hilang').length;
                    const dCurrent = pupilLoans.filter(l => l.status === 'Rosak').length;

                    const hasIncomplete = lCurrent > 0 || lostCurrent > 0 || dCurrent > 0;

                    return (
                      <tr 
                        key={pupil.id} 
                        className="hover:bg-stone-50/50 dark:hover:bg-slate-950/20 transition-colors"
                      >
                        <td className="px-6 py-4 font-bold text-slate-900 dark:text-white">
                          {pupil.name}
                        </td>
                        <td className="px-4 py-4 text-slate-500 dark:text-slate-400 font-mono">
                          TAHUN {pupil.year}
                        </td>
                        <td className="px-4 py-4 text-slate-500 dark:text-slate-400 uppercase font-mono">
                          {pupil.className}
                        </td>
                        <td className="px-4 py-4 text-center font-bold font-mono text-xs text-amber-600 dark:text-amber-500">
                          {lCurrent}
                        </td>
                        <td className="px-4 py-4 text-center font-bold font-mono text-xs text-emerald-600 dark:text-emerald-500">
                          {rCurrent}
                        </td>
                        <td className="px-4 py-4 text-center font-bold font-mono text-xs text-rose-600 dark:text-rose-500">
                          {lostCurrent}
                        </td>
                        <td className="px-4 py-4 text-center font-bold font-mono text-xs text-orange-600 dark:text-orange-500">
                          {dCurrent}
                        </td>
                        <td className="px-6 py-4 text-right">
                          <span className={`inline-block text-[10px] font-bold font-mono uppercase tracking-wider px-2 py-0.5 rounded ${
                            pupilLoans.length === 0 
                              ? 'bg-stone-100 dark:bg-slate-800 text-slate-400 dark:text-slate-500'
                              : !hasIncomplete 
                                ? 'bg-emerald-50 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-450' 
                                : 'bg-rose-50 dark:bg-rose-950/40 text-rose-750 dark:text-rose-400'
                          }`}>
                            {pupilLoans.length === 0 ? 'Tiada Pinjaman' : !hasIncomplete ? 'Selesai' : 'Belum Selesai'}
                          </span>
                        </td>
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>
        </div>

        {/* Pengesahan Cetak Khas */}
        <div className="hidden print:flex justify-between items-center pt-16 text-xs text-slate-400 font-mono">
          <span>Dicetak melalui Sistem Pengurusan SPBT Pintar Terpadu</span>
          <span>Tarikh Cetakan: {new Date().toLocaleDateString('ms-MY')}</span>
        </div>

      </div>
    </div>
  );
}
