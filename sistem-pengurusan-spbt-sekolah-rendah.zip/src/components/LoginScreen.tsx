import React, { useState } from 'react';
import { School, ShieldCheck, Key, User, Eye, EyeOff, AlertCircle } from 'lucide-react';
import { UserAccount } from '../types';
import SchoolLogo from './SchoolLogo';

interface LoginScreenProps {
  onLogin: () => void;
  users: UserAccount[];
}

export default function LoginScreen({ onLogin, users }: LoginScreenProps) {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    const normUser = username.trim().toLowerCase();
    const normPass = password.trim();

    // Find custom dynamic users first (including default ones)
    const foundUser = users.find(
      u => u.username.toLowerCase() === normUser && u.password === normPass
    );

    if (foundUser) {
      localStorage.setItem('spbt_logged_in', 'true');
      localStorage.setItem('spbt_username', foundUser.username);
      localStorage.setItem('spbt_user_name', foundUser.name);
      localStorage.setItem('spbt_user_role', foundUser.role);
      onLogin();
    } else {
      setError('ID Pengguna atau Kata Laluan tidak sah. Sila semak dengan Pentadbir / Penyelaras SPBT Sekolah.');
    }
  };

  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-stone-50/60 dark:bg-slate-950 p-4 transition-colors font-sans selection:bg-emerald-100 dark:selection:bg-emerald-800 animate-fade-in">
      
      <div className="w-full max-w-md bg-white dark:bg-slate-900 border border-stone-200 dark:border-slate-800 rounded-2xl shadow-xl p-8 space-y-6 relative overflow-hidden">
        
        {/* Accented top border */}
        <div className="absolute top-0 left-0 right-0 h-1.5 bg-emerald-600 dark:bg-emerald-500" />

        {/* Headings */}
        <div className="text-center space-y-3">
          <div className="mx-auto flex justify-center">
            <SchoolLogo className="w-20 h-20 transition-transform hover:scale-105 duration-300" />
          </div>
          
          <div className="space-y-1">
            <p className="text-[10px] sm:text-xs font-bold font-mono tracking-widest text-emerald-600 dark:text-emerald-400 uppercase">
              REKOD DIGITAL KEBANGSAAN
            </p>
            <h2 className="text-xl sm:text-2xl font-bold text-slate-950 dark:text-white tracking-tight">
              Sistem Pengurusan SPBT
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed max-w-xs mx-auto">
              Rekod Digital - SK Felda Lui Muda
            </p>
          </div>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="space-y-4 pt-2">
          {error && (
            <div className="p-3 bg-rose-50 dark:bg-rose-950/20 border border-rose-150 dark:border-rose-900/40 text-rose-700 dark:text-rose-400 rounded-lg flex items-start gap-2 text-xs">
              <AlertCircle className="w-4 h-4 mt-0.5 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          <div className="space-y-1.5">
            <label className="text-xs font-bold text-slate-700 dark:text-slate-350 flex items-center gap-1.5 font-mono uppercase tracking-wider">
              <User className="w-3.5 h-3.5 text-slate-400" />
              ID Pengguna (Username)
            </label>
            <input
              type="text"
              id="login_username"
              required
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              placeholder="Masukkan ID Pengguna..."
              className="w-full bg-stone-50 focus:bg-white dark:bg-slate-950 focus:dark:bg-slate-950/20 border border-stone-250 dark:border-slate-800 focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 focus:outline-none py-2.5 px-3.5 rounded-xl text-sm transition-all text-slate-900 dark:text-white placeholder:text-slate-400 dark:placeholder:text-slate-600"
            />
          </div>

          <div className="space-y-1.5 relative">
            <label className="text-xs font-bold text-slate-700 dark:text-slate-350 flex items-center gap-1.5 font-mono uppercase tracking-wider">
              <Key className="w-3.5 h-3.5 text-slate-400" />
              Kata Laluan
            </label>
            <div className="relative">
              <input
                type={showPassword ? 'text' : 'password'}
                id="login_password"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Masukkan Kata Laluan..."
                className="w-full bg-stone-50 focus:bg-white dark:bg-slate-950 focus:dark:bg-slate-950/20 border border-stone-250 dark:border-slate-800 focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 focus:outline-none py-2.5 pl-3.5 pr-10 rounded-xl text-sm transition-all text-slate-900 dark:text-white placeholder:text-slate-400 dark:placeholder:text-slate-600"
              />
              <button
                type="button"
                id="toggle_password_btn"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-3 top-2.5 text-slate-450 hover:text-slate-650 dark:text-slate-500 dark:hover:text-slate-300 transition-colors cursor-pointer"
              >
                {showPassword ? <EyeOff className="w-4.5 h-4.5" /> : <Eye className="w-4.5 h-4.5" />}
              </button>
            </div>
          </div>

          <button
            type="submit"
            id="login_submit_btn"
            className="w-full bg-slate-900 hover:bg-slate-850 dark:bg-emerald-600 dark:hover:bg-emerald-700 text-white font-bold py-3 px-4 rounded-xl text-xs sm:text-sm uppercase tracking-widest shadow-md hover:shadow-lg transition-all duration-150 cursor-pointer flex items-center justify-center gap-2"
          >
            <ShieldCheck className="w-4 h-4" />
            <span>Log Masuk Sistem</span>
          </button>
        </form>

      </div>

      <div className="text-center mt-6 text-[10px] text-slate-400 dark:text-slate-500 uppercase font-mono tracking-widest">
        SPBT DIGITAL MANAGEMENT PORTAL • SK FELDA LUI MUDA
      </div>

    </div>
  );
}
