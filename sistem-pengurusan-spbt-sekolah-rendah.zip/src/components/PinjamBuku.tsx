import { useState } from 'react';
import { Book, Pupil, Loan } from '../types';
import { CheckCircle, BookOpen, AlertCircle, Search, User, Check, Square, ChevronRight, Printer } from 'lucide-react';

interface PinjamBukuProps {
  pupils: Pupil[];
  books: Book[];
  loans: Loan[];
  currentSession: string;
  onUpdateLoanStatus: (pupilId: string, bookId: string, status: 'Belum Dipinjam' | 'Dipinjam', date: string | null) => void;
  onUpdateMultipleLoans?: (pupilId: string, bookIds: string[], status: 'Belum Dipinjam' | 'Dipinjam', date: string | null) => void;
  onSelectPupil: (pupil: Pupil) => void;
  onPrintIndividu?: (pupilId: string) => void;
  onPrintPukal?: (year: number) => void;
}

export default function PinjamBuku({ 
  pupils, 
  books, 
  loans, 
  currentSession, 
  onUpdateLoanStatus,
  onUpdateMultipleLoans,
  onSelectPupil,
  onPrintIndividu,
  onPrintPukal
}: PinjamBukuProps) {
  const [activeYear, setActiveYear] = useState<number>(1);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedPupilId, setSelectedPupilId] = useState<string | null>(null);

  // Filter active, non-archived pupils for the current session in the active year
  const activePupilsInYear = pupils.filter(p => !p.isArchived && p.session === currentSession && p.year === activeYear);

  // Filter by search query (name or class)
  const filteredPupils = activePupilsInYear.filter(p => 
    p.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
    p.className.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const selectedPupil = pupils.find(p => p.id === selectedPupilId);
  
  // Textbooks defined for the active year
  const yearBooks = books.filter(b => b.year === activeYear);

  // Today's date in local ISO string format (YYYY-MM-DD)
  const getTodayDate = () => {
    const today = new Date();
    const offset = today.getTimezoneOffset();
    const localToday = new Date(today.getTime() - (offset * 60 * 1000));
    return localToday.toISOString().split('T')[0];
  };

  const handleToggleBook = (bookId: string, currentlyLent: boolean) => {
    if (!selectedPupilId) return;
    
    if (currentlyLent) {
      // Uncheck means return to "Belum Dipinjam"
      onUpdateLoanStatus(selectedPupilId, bookId, 'Belum Dipinjam', null);
    } else {
      // Check means mark "Dipinjam" with today's date
      onUpdateLoanStatus(selectedPupilId, bookId, 'Dipinjam', getTodayDate());
    }
  };

  const handleSelectPupil = (pupil: Pupil) => {
    setSelectedPupilId(pupil.id);
  };

  const handlePinjamSemua = () => {
    if (!selectedPupil || !onUpdateMultipleLoans) return;
    const today = getTodayDate();
    const booksToLend = yearBooks.map(b => b.id);
    onUpdateMultipleLoans(selectedPupil.id, booksToLend, 'Dipinjam', today);
  };

  const handleBatalPinjamSemua = () => {
    if (!selectedPupil || !onUpdateMultipleLoans) return;
    const booksToUnlend = yearBooks.map(b => b.id);
    onUpdateMultipleLoans(selectedPupil.id, booksToUnlend, 'Belum Dipinjam', null);
  };

  return (
    <div className="space-y-6 animate-fade-in">
      
      {/* Tab Filter Tahun 1 - 6 - Gaya Editorial Klasik */}
      <div className="bg-white dark:bg-slate-900 border border-stone-200 dark:border-slate-800 p-1.5 rounded-xl shadow-2xs flex flex-wrap gap-1">
        {[1, 2, 3, 4, 5, 6].map((yr) => (
          <button
            key={yr}
            id={`pinjam_tab_year_${yr}`}
            onClick={() => {
              setActiveYear(yr);
              setSelectedPupilId(null); // Reset pupil selection when year changes
            }}
            className={`flex-1 min-w-[75px] py-2.5 px-3 rounded-lg text-xs font-sans font-bold transition-all cursor-pointer ${
              activeYear === yr
                ? 'bg-slate-900 text-white dark:bg-emerald-950 dark:text-emerald-400 border border-slate-900 dark:border-emerald-800 shadow-sm'
                : 'bg-transparent text-slate-650 dark:text-slate-400 hover:bg-stone-50 dark:hover:bg-slate-800/40'
            }`}
          >
            Tahun {yr}
          </button>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        
        {/* Kolum Kiri: Senarai Murid mengikut Tahun terpilih */}
        <div className="bg-white dark:bg-slate-900 border border-stone-200 dark:border-slate-800 rounded-xl shadow-2xs p-6 space-y-4 self-start">
          <div className="flex justify-between items-center border-b border-stone-100 dark:border-slate-800 pb-3">
            <div>
              <h3 className="font-sans font-bold text-slate-950 dark:text-white text-base">Senarai Murid (T- {activeYear})</h3>
              <p className="text-[10px] text-slate-500 font-mono">SESI {currentSession}</p>
            </div>
            {onPrintPukal && (
              <button
                type="button"
                id="btn_print_pukal_pinjam"
                onClick={() => onPrintPukal(activeYear)}
                className="flex items-center gap-1.5 px-2.5 py-1 bg-emerald-50 hover:bg-emerald-100/80 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-400 border border-emerald-100 dark:border-emerald-800/80 rounded-lg text-[10px] font-bold cursor-pointer transition-colors"
                title="Cetak Borang Akuan Pukal/Kelas untuk tanda tangan murid"
              >
                <Printer className="w-3.5 h-3.5" />
                <span>Cetak Pukal</span>
              </button>
            )}
          </div>

          {/* Carian Murid */}
          <div className="relative">
            <Search className="w-3.5 h-3.5 absolute left-3 top-3 text-slate-400" />
            <input
              id="pinjam_carian_pupil"
              type="text"
              placeholder="Cari murid / nama kelas..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-stone-50/50 dark:bg-slate-950 border border-stone-200 dark:border-slate-850 rounded-lg pl-9 pr-3 py-2 text-xs text-slate-950 dark:text-white focus:outline-none focus:border-slate-900 dark:focus:border-emerald-600 focus:bg-white transition-colors"
            />
          </div>

          <div className="divide-y divide-stone-100 dark:divide-slate-800/50 max-h-[380px] overflow-y-auto pr-1 space-y-1">
            {filteredPupils.length === 0 ? (
              <div className="py-8 text-center text-xs text-neutral-400 dark:text-neutral-500">
                Tiada murid didaftarkan dalam Tahun {activeYear}.
              </div>
            ) : (
              filteredPupils.map((pupil) => {
                const isSelected = selectedPupilId === pupil.id;
                
                // Hitung jumlah buku dpinjam masa sedia ada
                const pupilLoans = loans.filter(l => l.pupilId === pupil.id && l.session === currentSession && l.status === 'Dipinjam');

                return (
                  <button
                    key={pupil.id}
                    id={`btn_pilih_murid_${pupil.id}`}
                    onClick={() => handleSelectPupil(pupil)}
                    className={`w-full flex items-center justify-between p-3 rounded-xl text-left transition-all cursor-pointer ${
                      isSelected 
                        ? 'bg-emerald-600 text-white font-semibold' 
                        : 'hover:bg-neutral-50 dark:hover:bg-neutral-800/40 text-neutral-800 dark:text-neutral-300'
                    }`}
                  >
                    <div className="space-y-1">
                      <p className="text-xs font-bold leading-tight">{pupil.name}</p>
                      <p className={`text-[10px] ${isSelected ? 'text-emerald-100' : 'text-neutral-400'}`}>
                        Kelas: {pupil.className}
                      </p>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className={`text-[10px] font-bold px-2 py-0.5 rounded-md ${isSelected ? 'bg-emerald-700 text-white' : 'bg-neutral-100 dark:bg-neutral-800 text-neutral-600 dark:text-neutral-400'}`}>
                        {pupilLoans.length} Buku
                      </span>
                      <ChevronRight className="w-3.5 h-3.5 opacity-50" />
                    </div>
                  </button>
                );
              })
            )}
          </div>
        </div>

        {/* Kolum Kanan: Helaian Menanda Peminjaman Buku - Gaya Panel Editorial */}
        <div className="lg:col-span-2 bg-white dark:bg-slate-900 border border-stone-200 dark:border-slate-800 rounded-xl shadow-2xs p-6 flex flex-col min-h-[400px]">
          {selectedPupil ? (
            <div className="space-y-6 flex-1 flex flex-col justify-between">
              
              {/* Profil Ringkas */}
              <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center bg-stone-50/50 dark:bg-slate-950 p-4 border border-stone-200/60 dark:border-slate-850 rounded-lg gap-3">
                <div className="flex items-center gap-3">
                  <div className="p-2.5 bg-slate-900 dark:bg-emerald-950 border border-slate-850 dark:border-emerald-800 text-white rounded-lg">
                    <User className="w-4 h-4 text-emerald-400" />
                  </div>
                  <div>
                    <h4 className="font-sans font-bold text-slate-900 dark:text-white text-base">{selectedPupil.name}</h4>
                    <p className="text-xs text-slate-500 dark:text-slate-400 font-mono">
                      TAHUN {selectedPupil.year} • KELAS {selectedPupil.className.toUpperCase()}
                    </p>
                  </div>
                </div>
                
                <div className="flex gap-1.5 self-end sm:self-auto">
                  <button
                    id="pinjam_lihat_profil_btn"
                    onClick={() => onSelectPupil(selectedPupil)}
                    className="text-[10px] font-bold text-slate-900 dark:text-white hover:bg-stone-50 bg-white dark:bg-slate-800 px-3 py-1.5 border border-stone-200 dark:border-slate-700/80 rounded shadow-xs cursor-pointer uppercase tracking-wider font-mono"
                  >
                    Profil
                  </button>
                  {onPrintIndividu && (
                    <button
                      type="button"
                      id="pinjam_print_individu_btn"
                      onClick={() => onPrintIndividu(selectedPupil.id)}
                      className="text-[10px] font-bold text-emerald-750 dark:text-emerald-400 hover:bg-emerald-100/30 bg-emerald-50 dark:bg-emerald-950/40 px-3 py-1.5 border border-emerald-100 dark:border-emerald-800/80 rounded shadow-xs cursor-pointer uppercase tracking-wider font-mono flex items-center gap-1.5"
                      title="Cetak Akuan Penerimaan Buku SPBT Murid ini"
                    >
                      <Printer className="w-3.5 h-3.5" />
                      <span>Cetak Slip</span>
                    </button>
                  )}
                </div>
              </div>

              {/* Senarai Buku Teks Tanda */}
              <div className="flex-1 space-y-4">
                <div className="flex flex-wrap items-center justify-between border-b border-stone-105 dark:border-slate-800/80 pb-3 gap-2">
                  <h4 className="text-xs font-bold text-slate-900 dark:text-white flex items-center gap-1.5 uppercase tracking-widest font-mono">
                    <BookOpen className="w-4 h-4 text-emerald-500" />
                    Bahan Tanda Dipinjam (Buku Tahun {activeYear})
                  </h4>
                  {onUpdateMultipleLoans && yearBooks.length > 0 && (
                    <div className="flex items-center gap-1.5">
                      <button
                        type="button"
                        id="btn_pinjam_pukal"
                        onClick={handlePinjamSemua}
                        className="text-[10px] bg-emerald-600 dark:bg-emerald-950 text-white dark:text-emerald-400 font-bold uppercase tracking-wider px-2.5 py-1.5 rounded-lg hover:bg-emerald-700 hover:dark:bg-emerald-900 shadow-xs cursor-pointer transition-colors"
                        title="Tanda semua sebagai dipinjami untuk mempercepatkan pertengahan tahun"
                      >
                        ⚡ Pinjam Semua ({yearBooks.length})
                      </button>
                      <button
                        type="button"
                        id="btn_batal_pukal"
                        onClick={handleBatalPinjamSemua}
                        className="text-[10px] bg-stone-100 hover:bg-stone-200 dark:bg-slate-850 text-slate-700 dark:text-slate-350 border border-stone-200 dark:border-slate-800 font-bold px-2.5 py-1.5 rounded-lg cursor-pointer transition-all"
                        title="Kosongkan senarai pinjaman murid"
                      >
                        Batal Semua
                      </button>
                    </div>
                  )}
                </div>

                {yearBooks.length === 0 ? (
                  <div className="p-12 text-center text-xs text-slate-400 dark:text-slate-500">
                    Ralat: Tiada senarai buku ditubuhkan bagi Tahun {activeYear} lagi. Sila tambah tajuk buku di panel "Urus Buku" terlebih dahulu.
                  </div>
                ) : (
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    {yearBooks.map((book) => {
                      // Semak status pinjaman untuk buku ini oleh murid ini
                      const loan = loans.find(
                        l => l.pupilId === selectedPupil.id && 
                             l.bookId === book.id && 
                             l.session === currentSession
                      );
                      
                      const isLent = loan?.status === 'Dipinjam';
                      const isOtherStatus = loan && !['Belum Dipinjam', 'Dipinjam'].includes(loan.status);

                      return (
                        <button
                          key={book.id}
                          id={`btn_pinjam_buku_${book.id}`}
                          disabled={!!isOtherStatus}
                          onClick={() => handleToggleBook(book.id, isLent)}
                          className={`flex items-start text-left p-4 rounded-lg border transition-all ${
                            isOtherStatus
                              ? 'bg-stone-50 dark:bg-slate-950/20 opacity-60 border-stone-200/60 dark:border-slate-850 cursor-not-allowed'
                              : isLent
                                ? 'bg-emerald-50 text-emerald-950 border-emerald-350 dark:bg-emerald-950/20 dark:border-emerald-700/60 dark:text-emerald-300'
                                : 'bg-white hover:bg-stone-50/50 dark:bg-slate-900 border-stone-200 dark:border-slate-800 text-slate-800 dark:text-slate-300'
                          } cursor-pointer`}
                        >
                          <div className="flex items-center h-5 mr-3">
                            {isLent ? (
                              <div className="p-0.5 bg-emerald-600 text-white rounded">
                                <Check className="w-3.5 h-3.5 stroke-[3]" />
                              </div>
                            ) : (
                              <div className="w-4 h-4 border border-stone-300 dark:border-slate-700 rounded bg-white dark:bg-slate-950" />
                            )}
                          </div>
                          <div className="space-y-1">
                            <span className="text-xs font-bold leading-normal block text-slate-800 dark:text-slate-250">{book.title}</span>
                            <div className="flex items-center gap-1.5 text-[9px] font-mono font-semibold text-slate-400">
                              <span>Kod: {book.id}</span>
                              {loan && (
                                <>
                                  <span>•</span>
                                  <span className={`px-1.5 py-0.2 rounded ${
                                    isLent 
                                      ? 'bg-emerald-105/80 dark:bg-emerald-950/50 text-emerald-750 dark:text-emerald-400' 
                                      : 'bg-stone-100 dark:bg-slate-800/80 text-slate-650 dark:text-slate-400'
                                  }`}>
                                    {loan.status}
                                  </span>
                                </>
                              )}
                            </div>
                          </div>
                        </button>
                      );
                    })}
                  </div>
                )}
              </div>

              {/* Status Pemaklum */}
              <div className="p-4 bg-stone-50 dark:bg-slate-950/30 border border-stone-200/60 dark:border-slate-850 rounded-lg flex items-start gap-2.5 mt-6">
                <CheckCircle className="w-4 h-4 text-emerald-500 self-start mt-0.5 shrink-0" />
                <p className="text-[10.5px] text-slate-500 dark:text-slate-400 leading-relaxed">
                  Mengetik kotak penanda di atas akan <strong className="font-semibold text-slate-800 dark:text-slate-200">merekodkan pinjaman secara automatik</strong> dengan tarikh hari ini ({getTodayDate()}) dan menyimpan rekod ke lembar kerja secara automatik. Tiada butang simpan manual diperlukan.
                </p>
              </div>

            </div>
          ) : (
            <div className="flex-1 flex flex-col items-center justify-center text-slate-400 dark:text-slate-550 p-12 space-y-4">
              <BookOpen className="w-10 h-10 text-stone-300 dark:text-slate-700" />
              <div className="text-center">
                <p className="text-sm font-sans font-bold text-slate-800 dark:text-slate-200">Pilih Murid Untuk Mengurus Pinjaman</p>
                <p className="text-[11px] text-slate-400 dark:text-slate-500 mt-1.5 max-w-sm leading-relaxed mx-auto">
                  Klik pada mana-mana nama murid di kolum sebelah kiri mengikut senarai Tahun sasaran untuk memaparkan lembaran buku teks SPBT yang dipinjam.
                </p>
              </div>
            </div>
          )}
        </div>

      </div>
    </div>
  );
}
