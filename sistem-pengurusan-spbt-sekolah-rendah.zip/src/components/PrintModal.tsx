import React from 'react';
import { X, Printer, FileText, Check, AlertCircle } from 'lucide-react';
import { Book, Pupil, Loan } from '../types';
import SchoolLogo from './SchoolLogo';

interface PrintJob {
  type: 'individu-pinjam' | 'individu-pulang' | 'pukal-pinjam' | 'pukal-pulang';
  pupilId?: string;
  year?: number;
  className?: string; // Additional filter for class
}

interface PrintModalProps {
  books: Book[];
  pupils: Pupil[];
  loans: Loan[];
  currentSession: string;
  job: PrintJob;
  onClose: () => void;
}

export default function PrintModal({
  books,
  pupils,
  loans,
  currentSession,
  job,
  onClose
}: PrintModalProps) {
  
  // 1. Resolve pupils and books based on job type
  const targetYear = job.year || (job.pupilId ? pupils.find(p => p.id === job.pupilId)?.year : 1) || 1;
  const targetClass = job.className || '';
  
  // Filter active pupils for the given year & optional class
  let targetPupils = pupils.filter(p => !p.isArchived && p.session === currentSession && p.year === targetYear);
  if (targetClass) {
    targetPupils = targetPupils.filter(p => p.className.toLowerCase() === targetClass.toLowerCase());
  }
  
  // Textbooks for the year
  const yearBooks = books.filter(b => b.year === targetYear);

  // Single pupil if individual
  const singlePupil = job.pupilId ? pupils.find(p => p.id === job.pupilId) : null;
  const singlePupilLoans = singlePupil 
    ? loans.filter(l => l.pupilId === singlePupil.id && l.session === currentSession)
    : [];

  const handlePrint = () => {
    window.print();
  };

  const getTodayFormatted = () => {
    const today = new Date();
    return today.toLocaleDateString('ms-MY', { day: 'numeric', month: 'long', year: 'numeric' });
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/70 backdrop-blur-xs flex items-center justify-center p-4 sm:p-6 print-hidden">
      
      {/* Dynamic CSS injection to determine landscape vs portrait orientation on physical paper */}
      {job.type.startsWith('pukal') ? (
        <style dangerouslySetInnerHTML={{ __html: `
          @media print {
            @page {
              size: landscape;
              margin: 0.5cm;
            }
          }
        `}} />
      ) : (
        <style dangerouslySetInnerHTML={{ __html: `
          @media print {
            @page {
              size: portrait;
              margin: 1cm;
            }
          }
        `}} />
      )}

      {/* Outer wrapper panel */}
      <div className="bg-slate-100 dark:bg-slate-950 rounded-2xl w-full max-w-5xl shadow-2xl flex flex-col h-[90vh] border border-stone-200 dark:border-slate-800 relative animate-fade-in print-hidden">
        
        {/* Modal Chrome Header */}
        <div className="p-4 sm:px-6 bg-white dark:bg-slate-900 border-b border-stone-200 dark:border-slate-800 rounded-t-2xl flex items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <div className="p-1.5 bg-emerald-100 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-400 rounded-lg">
              <Printer className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm sm:text-base font-bold text-slate-900 dark:text-white">
                Pratonton Borang Cetakan SPBT
              </h3>
              <p className="text-[11px] text-slate-500 dark:text-slate-400">
                Sahkan reka bentuk format sebelum dicetak keluar sebagai rekod fizikal bertandatangan
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              id="print_trigger_btn"
              onClick={handlePrint}
              className="bg-emerald-600 hover:bg-emerald-700 text-white font-bold py-2 px-4 rounded-xl text-xs flex items-center gap-1.5 shadow-sm transition-all cursor-pointer"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>Cetak Sekarang</span>
            </button>
            <button
              id="close_print_modal_btn"
              onClick={onClose}
              className="p-2 text-slate-400 hover:text-slate-650 dark:hover:text-slate-300 hover:bg-stone-50 dark:hover:bg-slate-800 rounded-lg transition-colors cursor-pointer"
            >
              <X className="w-4.5 h-4.5" />
            </button>
          </div>
        </div>

        {/* Modal Main Area split: left option controller, right dynamic preview sheet */}
        <div className="flex-1 overflow-hidden flex flex-col md:flex-row">
          
          {/* Left panel: Info & Help */}
          <div className="w-full md:w-72 bg-white dark:bg-slate-900/60 border-r border-stone-200 dark:border-slate-800 p-5 space-y-5 overflow-y-auto">
            <div className="space-y-2">
              <h4 className="text-xs font-bold text-slate-400 dark:text-slate-500 font-mono uppercase tracking-wider">GAYA BORANG</h4>
              <div className="p-3 bg-stone-50 dark:bg-slate-950/40 rounded-xl space-y-1">
                <span className="text-xs font-bold text-slate-800 dark:text-slate-200 block">
                  {job.type === 'individu-pinjam' && 'Borang Akuan Individu (Pinjam)'}
                  {job.type === 'individu-pulang' && 'Borang Akuan Individu (Pulang)'}
                  {job.type === 'pukal-pinjam' && 'Borang Kelas Berkelompok (Pinjam)'}
                  {job.type === 'pukal-pulang' && 'Borang Kelas Berkelompok (Pulang)'}
                </span>
                <span className="text-[10px] text-slate-500 dark:text-slate-400 block font-mono">
                  Sesi Akademik: {currentSession}
                </span>
                <span className="text-[10px] text-slate-500 dark:text-slate-400 block font-mono">
                  Tahun Sasaran: Tahun {targetYear}
                </span>
              </div>
            </div>

            <div className="bg-emerald-50/50 dark:bg-emerald-950/15 border border-emerald-100 dark:border-emerald-900/30 p-4 rounded-xl space-y-3">
              <h5 className="text-xs font-bold text-emerald-800 dark:text-emerald-450 flex items-center gap-1">
                <FileText className="w-3.5 h-3.5" />
                Panduan Penting Cetakan:
              </h5>
              <ul className="text-[10px] text-slate-600 dark:text-slate-450 space-y-1.5 list-disc pl-4 leading-normal">
                <li>Sesuai untuk ditandatangani oleh murid di hadapan guru atau pengawas SPBT.</li>
                <li>Helaian adalah format standard hitam-putih untuk menjimatkan dakwat pencetak sekolah.</li>
                <li><strong>Untuk hasil terbaik:</strong> Aktifkan pilihan <code className="font-mono bg-stone-100 dark:bg-slate-800/80 px-1 rounded text-red-650">"Background graphics"</code> di tetingkap cetakan pelayar jika mahu bayang kelabu dipaparkan.</li>
              </ul>
            </div>

            <div className="p-4 bg-slate-50 dark:bg-slate-950/20 rounded-xl border border-stone-150 dark:border-slate-850 flex items-start gap-2 text-[10px] text-slate-400 dark:text-slate-500 leading-relaxed">
              <AlertCircle className="w-4 h-4 shrink-0 mt-0.5 text-stone-400" />
              <span>Sistem menyusun saiz jadual secara automatik supaya muat dalam saiz halaman kertas standard A4 demi kemudahan arkib.</span>
            </div>
          </div>

          {/* Right panel: Printable Preview Sheet Container */}
          <div className="flex-1 bg-stone-300/40 dark:bg-slate-950/50 p-4 sm:p-8 overflow-y-auto flex justify-center items-start">
            
            {/* The Actual "Paper" document inside UI preview */}
            <div 
              className={`bg-white text-slate-900 p-8 shadow-xl border border-stone-300 rounded-xs font-sans text-sm relative select-text transition-all duration-300 ${
                job.type.startsWith('pukal') ? 'max-w-5xl w-full min-h-[8.5in]' : 'max-w-4xl w-full min-h-[11in]'
              }`} 
              style={{ color: '#000', backgroundColor: '#fff' }}
            >
              
              {/* Header Letterhead */}
              <div className="flex items-center gap-4 border-b-2 border-slate-950 pb-4 text-slate-950">
                <SchoolLogo className="w-16 h-16 shrink-0" />
                <div className="flex-1 text-left space-y-0.5">
                  <p className="text-[10px] font-bold tracking-widest text-slate-600 font-mono">REKOD DIGITAL KEBANGSAAN</p>
                  <h3 className="text-base sm:text-lg font-bold tracking-tight uppercase">SISTEM PENGURUSAN SPBT LUI MUDA</h3>
                  <h4 className="text-xs font-semibold tracking-normal uppercase">SEKOLAH KEBANGSAAN FELDA LUI MUDA</h4>
                  <p className="text-[11px] text-slate-500 italic">72120 Bandar Seri Jempol, Negeri Sembilan • Sesi Akademik {currentSession}</p>
                </div>
              </div>

              {/* Dynamic printable content rendering based on job type */}
              <div className="pt-6 space-y-6">
                
                {/* 1. INDIVIDU PINJAM */}
                {job.type === 'individu-pinjam' && singlePupil && (
                  <div className="space-y-6">
                    <div className="text-center bg-slate-100 p-2 rounded border border-slate-300/85">
                      <h4 className="text-xs font-extrabold uppercase tracking-wider">BORANG AKUAN PENERIMAAN BUKU TEKS (INDIVIDU)</h4>
                    </div>

                    {/* Metadata Table */}
                    <table className="w-full border-collapse border border-slate-350 text-xs text-left">
                      <tbody>
                        <tr>
                          <td className="border border-slate-350 bg-slate-50 p-2 font-bold w-1/4">NAMA MURID:</td>
                          <td className="border border-slate-350 p-2 uppercase" colSpan={3}>{singlePupil.name}</td>
                        </tr>
                        <tr>
                          <td className="border border-slate-350 bg-slate-50 p-2 font-bold w-1/4">TAHUN / DARJAH:</td>
                          <td className="border border-slate-350 p-2">Tahun {singlePupil.year}</td>
                          <td className="border border-slate-350 bg-slate-50 p-2 font-bold w-1/4">KELAS:</td>
                          <td className="border border-slate-350 p-2 uppercase">{singlePupil.className}</td>
                        </tr>
                        <tr>
                          <td className="border border-slate-350 bg-slate-50 p-2 font-bold w-1/4">TARIKH CETAKAN:</td>
                          <td className="border border-slate-350 p-2">{getTodayFormatted()}</td>
                          <td className="border border-slate-350 bg-slate-50 p-2 font-bold w-1/4">SESI AKADEMIK:</td>
                          <td className="border border-slate-350 p-2">{currentSession}</td>
                        </tr>
                      </tbody>
                    </table>

                    {/* Books Table */}
                    <div>
                      <p className="text-xs font-bold mb-2">SENARAI BUKU TEKS YANG DIPINJAM / DITERIMA:</p>
                      <table className="w-full border-collapse border border-slate-350 text-xs text-left">
                        <thead>
                          <tr className="bg-slate-100/90 text-[11px] font-bold">
                            <th className="border border-slate-350 p-2.5 w-12 text-center">BIL</th>
                            <th className="border border-slate-350 p-2.5 w-28">KOD BUKU</th>
                            <th className="border border-slate-350 p-2.5">JUDUL BUKU TEKS</th>
                            <th className="border border-slate-350 p-2.5 w-32 text-center">TARIKH TERIMA</th>
                            <th className="border border-slate-350 p-2.5 w-36 text-center">TANDATANGAN MURID</th>
                          </tr>
                        </thead>
                        <tbody>
                          {yearBooks.map((book, idx) => {
                            const matchedLoan = singlePupilLoans.find(l => l.bookId === book.id && l.status === 'Dipinjam');
                            return (
                              <tr key={book.id}>
                                <td className="border border-slate-350 p-2 text-center">{idx + 1}</td>
                                <td className="border border-slate-350 p-2 font-mono">{book.id}</td>
                                <td className="border border-slate-350 p-2 font-medium">{book.title}</td>
                                <td className="border border-slate-350 p-2 text-center">
                                  {matchedLoan ? matchedLoan.lendDate : '-'}
                                </td>
                                <td className="border border-slate-350 p-2 text-center text-slate-300 italic">
                                  {matchedLoan ? '_________________' : 'Tidak Dipinjam'}
                                </td>
                              </tr>
                            );
                          })}
                        </tbody>
                      </table>
                    </div>

                    <div className="text-[11px] leading-relaxed border border-dashed border-slate-300 p-3 rounded">
                      <strong>PENGAKUAN MURID:</strong><br />
                      Saya dengan ini mengaku telah menerima buku-buku teks di atas dalam keadaan baik. Saya bertanggungjawab sepenuhnya untuk membalut, menjaga kebersihan buku tumpuan tamat pengajian dan mengembalikan semua buku teks ini dalam keadaan baik kepada SPBT sekolah apabila diminta kelak atau di akhir sesi akademik.
                    </div>

                    {/* Double Sign Footer */}
                    <div className="grid grid-cols-2 gap-8 pt-12">
                      <div className="space-y-12">
                        <span className="block text-xs font-semibold">Tandatangan Penerima (Murid),</span>
                        <div>
                          <p className="border-b border-black w-48"></p>
                          <p className="text-[11px] mt-1">Nama: {singlePupil.name}</p>
                          <p className="text-[11px]">Tarikh: ___________________</p>
                        </div>
                      </div>

                      <div className="space-y-12">
                        <span className="block text-xs font-semibold">Tandatangan Guru / Pengawas SPBT,</span>
                        <div>
                          <p className="border-b border-black w-48"></p>
                          <p className="text-[11px] mt-1">Nama Pegawai: _______________________</p>
                          <p className="text-[11px]">Jawatan: ___________________________</p>
                        </div>
                      </div>
                    </div>
                  </div>
                )}

                {/* 2. INDIVIDU PULANG */}
                {job.type === 'individu-pulang' && singlePupil && (
                  <div className="space-y-6">
                    <div className="text-center bg-slate-100 p-2 rounded border border-slate-300/85">
                      <h4 className="text-xs font-extrabold uppercase tracking-wider">BORANG AKUAN PEMULANGAN BUKU TEKS (INDIVIDU)</h4>
                    </div>

                    {/* Metadata Table */}
                    <table className="w-full border-collapse border border-slate-350 text-xs text-left">
                      <tbody>
                        <tr>
                          <td className="border border-slate-350 bg-slate-50 p-2 font-bold w-1/4">NAMA MURID:</td>
                          <td className="border border-slate-350 p-2 uppercase" colSpan={3}>{singlePupil.name}</td>
                        </tr>
                        <tr>
                          <td className="border border-slate-350 bg-slate-50 p-2 font-bold w-1/4">TAHUN / DARJAH:</td>
                          <td className="border border-slate-350 p-2">Tahun {singlePupil.year}</td>
                          <td className="border border-slate-350 bg-slate-50 p-2 font-bold w-1/4">KELAS:</td>
                          <td className="border border-slate-350 p-2 uppercase">{singlePupil.className}</td>
                        </tr>
                        <tr>
                          <td className="border border-slate-350 bg-slate-50 p-2 font-bold w-1/4">TARIKH CETAKAN:</td>
                          <td className="border border-slate-350 p-2">{getTodayFormatted()}</td>
                          <td className="border border-slate-350 bg-slate-50 p-2 font-bold w-1/4">SESI AKADEMIK:</td>
                          <td className="border border-slate-350 p-2">{currentSession}</td>
                        </tr>
                      </tbody>
                    </table>

                    {/* Books Table */}
                    <div>
                      <p className="text-xs font-bold mb-2">SENARAI PEMULANGAN BUKU TEKS & CATATAN KEADAAN:</p>
                      <table className="w-full border-collapse border border-slate-350 text-xs text-left">
                        <thead>
                          <tr className="bg-slate-100/90 text-[11px] font-bold">
                            <th className="border border-slate-350 p-2.5 w-12 text-center">BIL</th>
                            <th className="border border-slate-350 p-2.5 w-28">KOD BUKU</th>
                            <th className="border border-slate-350 p-2.5">JUDUL BUKU TEKS</th>
                            <th className="border border-slate-350 p-2.5 w-28 text-center">TARIKH PULANG</th>
                            <th className="border border-slate-350 p-2.5 w-24 text-center">STATUS</th>
                            <th className="border border-slate-350 p-2.5 w-32 text-center">PENGESAHAN GURU</th>
                          </tr>
                        </thead>
                        <tbody>
                          {yearBooks.map((book, idx) => {
                            const matchedLoan = singlePupilLoans.find(l => l.bookId === book.id);
                            const isReturned = matchedLoan && ['Dipulangkan', 'Rosak', 'Hilang'].includes(matchedLoan.status);
                            
                            return (
                              <tr key={book.id}>
                                <td className="border border-slate-350 p-2 text-center">{idx + 1}</td>
                                <td className="border border-slate-350 p-2 font-mono">{book.id}</td>
                                <td className="border border-slate-350 p-2 font-medium">{book.title}</td>
                                <td className="border border-slate-350 p-2 text-center">
                                  {isReturned ? (matchedLoan?.returnDate || '-') : '-'}
                                </td>
                                <td className="border border-slate-350 p-2 text-center font-bold">
                                  {isReturned ? (
                                    <span className={matchedLoan?.status === 'Dipulangkan' ? 'text-green-800' : 'text-rose-800'}>
                                      {matchedLoan?.status}
                                    </span>
                                  ) : (
                                    <span className="text-amber-800 italic">Belum Pulang</span>
                                  )}
                                </td>
                                <td className="border border-slate-350 p-2 text-center text-slate-300 italic">
                                  {isReturned ? '✓ DISAHKAN' : '_________________'}
                                </td>
                              </tr>
                            );
                          })}
                        </tbody>
                      </table>
                    </div>

                    <div className="text-[11px] leading-relaxed border border-dashed border-slate-300 p-3 rounded bg-amber-50/20">
                      <strong>NOTA GANTI RUGI (JIKA TERLIBAT):</strong><br />
                      Mengikut Peraturan Am Kelayakan Kementerian Pendidikan Malaysia, mana-mana buku teks yang dihilangkan, dirosakkan secara sengaja, atau tidak dipulangkan wajib digantikan dengan fizikal senaskah buku baru tajuk yang serupa atau bayaran ganti rugi munasabah.
                    </div>

                    {/* Double Sign Footer */}
                    <div className="grid grid-cols-2 gap-8 pt-12">
                      <div className="space-y-12">
                        <span className="block text-xs font-semibold">Tandatangan Murid yang Menyerahkan,</span>
                        <div>
                          <p className="border-b border-black w-48"></p>
                          <p className="text-[11px] mt-1">Nama: {singlePupil.name}</p>
                          <p className="text-[11px]">Tarikh: ___________________</p>
                        </div>
                      </div>

                      <div className="space-y-12">
                        <span className="block text-xs font-semibold">Tandatangan Guru Penerima (SPBT),</span>
                        <div>
                          <p className="border-b border-black w-48"></p>
                          <p className="text-[11px] mt-1">Nama Penerima: _______________________</p>
                          <p className="text-[11px]">Tarikh: ___________________________</p>
                        </div>
                      </div>
                    </div>
                  </div>
                )}

                {/* 3. PUKAL PINJAM */}
                {job.type === 'pukal-pinjam' && (
                  <div className="space-y-6">
                    <div className="text-center bg-slate-100 p-2 rounded border border-slate-300/85">
                      <h4 className="text-xs font-extrabold uppercase tracking-wider">REKOD PENERIMAAN BUKU TEKS SPBT BERKELOMPOK (PUKAL KELAS)</h4>
                    </div>

                    {/* Metadata Header */}
                    <div className="flex justify-between text-xs font-mono font-bold bg-slate-50 p-3.5 border border-slate-300 rounded leading-normal">
                      <div>TAHUN / DARJAH: TAHUN {targetYear} {targetClass && ` / KELAS ${targetClass.toUpperCase()}`}</div>
                      <div>JUMLAH MURID: {targetPupils.length} ORANG</div>
                      <div>TARIKH: {getTodayFormatted()}</div>
                    </div>

                    {/* Massive Class List with signatures */}
                    <div className="overflow-x-auto">
                      <table className="w-full border-collapse border border-slate-350 text-[10px] text-left">
                        <thead>
                          <tr className="bg-slate-100 text-slate-800 font-bold">
                            <th className="border border-slate-350 p-2 w-10 text-center">BIL</th>
                            <th className="border border-slate-350 p-2">NAMA MURID (TAHUN {targetYear})</th>
                            <th className="border border-slate-350 p-2 w-16 text-center">KELAS</th>
                            {yearBooks.slice(0, 7).map(b => (
                              <th key={b.id} className="border border-slate-350 p-1 text-center w-20 leading-tight truncate max-w-[80px]" title={b.title}>
                                {b.id}<br />
                                <span className="text-[8px] font-normal font-sans opacity-75">{b.title.substr(0,10)}...</span>
                              </th>
                            ))}
                            <th className="border border-slate-350 p-2 w-32 text-center">TANDATANGAN AKUAN</th>
                          </tr>
                        </thead>
                        <tbody>
                          {targetPupils.map((pupil, idx) => {
                            const pupilLoans = loans.filter(l => l.pupilId === pupil.id && l.session === currentSession && l.status === 'Dipinjam');
                            return (
                              <tr key={pupil.id} className="hover:bg-slate-50/50">
                                <td className="border border-slate-350 p-2 text-center">{idx + 1}</td>
                                <td className="border border-slate-350 p-2 font-bold uppercase truncate max-w-[170px]">{pupil.name}</td>
                                <td className="border border-slate-350 p-2 text-center uppercase">{pupil.className}</td>
                                {yearBooks.slice(0, 7).map(b => {
                                  const wasLent = pupilLoans.some(l => l.bookId === b.id);
                                  return (
                                    <td key={b.id} className="border border-slate-350 p-1 text-center font-bold">
                                      {wasLent ? '✓' : '-'}
                                    </td>
                                  );
                                })}
                                <td className="border border-slate-350 p-1.5 text-center text-slate-350">
                                  <div className="flex items-center justify-between">
                                    <span className="text-[8px] font-mono text-slate-300">{idx+1}.</span>
                                    <span className="text-slate-300">___________________</span>
                                  </div>
                                </td>
                              </tr>
                            );
                          })}
                        </tbody>
                      </table>
                    </div>

                    {yearBooks.length > 7 && (
                      <p className="text-[9px] text-slate-500 italic">
                        * Nota: Menunjukkan 7 tajuk utama Year {targetYear} bagi tujuan pemadatan saiz cetakan landscape. Buku lain direkod dalam pangkalan data digital.
                      </p>
                    )}

                    {/* Double Sign Footer */}
                    <div className="grid grid-cols-2 gap-8 pt-12">
                      <div className="space-y-12">
                        <span className="block text-xs font-semibold">Tandatangan & Pengesahan Ketua Pengawas SPBT,</span>
                        <div>
                          <p className="border-b border-black w-48"></p>
                          <p className="text-[11px] mt-1">Nama: _______________________</p>
                          <p className="text-[11px]">Tarikh: _______________________</p>
                        </div>
                      </div>

                      <div className="space-y-12">
                        <span className="block text-xs font-semibold">Tandatangan & Pengesahan Guru Penyelaras Buku Teks,</span>
                        <div>
                          <p className="border-b border-black w-48"></p>
                          <p className="text-[11px] mt-1">Nama Cikgu: _______________________</p>
                          <p className="text-[11px]">Materi Cetakan Digital Tarikh: {getTodayFormatted()}</p>
                        </div>
                      </div>
                    </div>
                  </div>
                )}

                {/* 4. PUKAL PULANG */}
                {job.type === 'pukal-pulang' && (
                  <div className="space-y-6">
                    <div className="text-center bg-slate-100 p-2 rounded border border-slate-300/85">
                      <h4 className="text-xs font-extrabold uppercase tracking-wider">REKOD PEMULANGAN BUKU TEKS SPBT BERKELOMPOK (PUKAL KELAS)</h4>
                    </div>

                    {/* Metadata Header */}
                    <div className="flex justify-between text-xs font-mono font-bold bg-slate-50 p-3.5 border border-slate-300 rounded leading-normal">
                      <div>TAHUN / DARJAH: TAHUN {targetYear} {targetClass && ` / KELAS ${targetClass.toUpperCase()}`}</div>
                      <div>JUMLAH MURID: {targetPupils.length} ORANG</div>
                      <div>TARIKH: {getTodayFormatted()}</div>
                    </div>

                    {/* Massive Class List with signatures */}
                    <div className="overflow-x-auto">
                      <table className="w-full border-collapse border border-slate-350 text-[10px] text-left">
                        <thead>
                          <tr className="bg-slate-100 text-slate-800 font-bold">
                            <th className="border border-slate-350 p-2 w-10 text-center">BIL</th>
                            <th className="border border-slate-350 p-2">NAMA MURID (TAHUN {targetYear})</th>
                            <th className="border border-slate-350 p-2 w-16 text-center">KELAS</th>
                            {yearBooks.slice(0, 7).map(b => (
                              <th key={b.id} className="border border-slate-350 p-1 text-center w-20 leading-tight truncate max-w-[80px]" title={b.title}>
                                {b.id}<br />
                                <span className="text-[8px] font-normal font-sans opacity-75">{b.title.substr(0,10)}...</span>
                              </th>
                            ))}
                            <th className="border border-slate-350 p-2 w-32 text-center">TANDATANGAN AKUAN</th>
                          </tr>
                        </thead>
                        <tbody>
                          {targetPupils.map((pupil, idx) => {
                            const pupilLoans = loans.filter(l => l.pupilId === pupil.id && l.session === currentSession);
                            return (
                              <tr key={pupil.id} className="hover:bg-slate-50/50">
                                <td className="border border-slate-350 p-2 text-center">{idx + 1}</td>
                                <td className="border border-slate-350 p-2 font-bold uppercase truncate max-w-[170px]">{pupil.name}</td>
                                <td className="border border-slate-350 p-2 text-center uppercase">{pupil.className}</td>
                                {yearBooks.slice(0, 7).map(b => {
                                  const match = pupilLoans.find(l => l.bookId === b.id);
                                  const isReturned = match && ['Dipulangkan', 'Rosak', 'Hilang'].includes(match.status);
                                  return (
                                    <td key={b.id} className="border border-slate-350 p-1 text-center font-bold text-[9px]">
                                      {isReturned ? (match.status === 'Dipulangkan' ? '✓' : match.status.substr(0,1)) : '-'}
                                    </td>
                                  );
                                })}
                                <td className="border border-slate-350 p-1.5 text-center text-slate-350">
                                  <div className="flex items-center justify-between">
                                    <span className="text-[8px] font-mono text-slate-300">{idx+1}.</span>
                                    <span className="text-slate-300">___________________</span>
                                  </div>
                                </td>
                              </tr>
                            );
                          })}
                        </tbody>
                      </table>
                    </div>

                    {yearBooks.length > 7 && (
                      <p className="text-[9px] text-slate-500 italic">
                        * Nota: Menunjukkan {yearBooks.slice(0,7).length} tajuk utama Year {targetYear}. Simbol: ✓ = Dipulangkan, H = Hilang, R = Rosak.
                      </p>
                    )}

                    {/* Double Sign Footer */}
                    <div className="grid grid-cols-2 gap-8 pt-12">
                      <div className="space-y-12">
                        <span className="block text-xs font-semibold">Tandatangan & Pengesahan Ketua Pengawas SPBT,</span>
                        <div>
                          <p className="border-b border-black w-48"></p>
                          <p className="text-[11px] mt-1">Nama: _______________________</p>
                          <p className="text-[11px]">Tarikh: _______________________</p>
                        </div>
                      </div>

                      <div className="space-y-12">
                        <span className="block text-xs font-semibold">Tandatangan & Pengesahan Guru Penyelaras Buku Teks,</span>
                        <div>
                          <p className="border-b border-black w-48"></p>
                          <p className="text-[11px] mt-1">Nama Cikgu: _______________________</p>
                          <p className="text-[11px]">Materi Cetakan Digital Tarikh: {getTodayFormatted()}</p>
                        </div>
                      </div>
                    </div>
                  </div>
                )}

              </div>

            </div>

          </div>

        </div>

      </div>

      {/* Standalone hidden print preview container for window.print() */}
      {/* This renders pure plain white content for A4 paper and hides all modal buttons during physical printing! */}
      <div className="hidden print-block absolute top-0 left-0 bg-white font-sans text-xs w-full p-4 print:p-0 leading-normal" style={{ color: '#000', backgroundColor: '#fff' }}>
        
        <div className="flex items-center gap-4 border-b-2 border-black pb-4 text-black">
          <SchoolLogo className="w-16 h-16 shrink-0" />
          <div className="flex-1 text-left space-y-0.5">
            <p className="text-[10px] font-bold tracking-widest text-slate-600 font-mono">REKOD DIGITAL KEBANGSAAN</p>
            <h3 className="text-base font-bold uppercase">SISTEM PENGURUSAN SPBT LUI MUDA</h3>
            <h4 className="text-xs font-semibold uppercase">SEKOLAH KEBANGSAAN FELDA LUI MUDA</h4>
            <p className="text-[10px] text-slate-500 italic">72120 Bandar Seri Jempol, Negeri Sembilan • Sesi Akademik {currentSession}</p>
          </div>
        </div>

        <div className="pt-6 space-y-6">
          
          {/* Individual Print Job */}
          {singlePupil && (job.type === 'individu-pinjam' || job.type === 'individu-pulang') && (
            <div className="space-y-5">
              <div className="text-center bg-stone-100 border border-stone-300 p-1.5 rounded">
                <h4 className="text-[11px] font-bold uppercase">
                  {job.type === 'individu-pinjam' ? 'BORANG AKUAN PENERIMAAN BUKU TEKS (INDIVIDU)' : 'BORANG AKUAN PEMULANGAN BUKU TEKS (INDIVIDU)'}
                </h4>
              </div>

              <table className="w-full border-collapse border border-black text-[11px] text-left">
                <tbody>
                  <tr>
                    <td className="border border-black bg-stone-50 p-1.5 font-bold w-1/4">NAMA MURID:</td>
                    <td className="border border-black p-1.5 uppercase" colSpan={3}>{singlePupil.name}</td>
                  </tr>
                  <tr>
                    <td className="border border-black bg-stone-50 p-1.5 font-bold w-1/4">TAHUN / DARJAH:</td>
                    <td className="border border-black p-1.5">Tahun {singlePupil.year}</td>
                    <td className="border border-black bg-stone-50 p-1.5 font-bold w-1/4">KELAS:</td>
                    <td className="border border-black p-1.5 uppercase">{singlePupil.className}</td>
                  </tr>
                  <tr>
                    <td className="border border-black bg-stone-50 p-1.5 font-bold w-1/4">TARIKH CETAKAN:</td>
                    <td className="border border-black p-1.5">{getTodayFormatted()}</td>
                    <td className="border border-black bg-stone-50 p-1.5 font-bold w-1/4">SESI AKADEMIK:</td>
                    <td className="border border-black p-1.5">{currentSession}</td>
                  </tr>
                </tbody>
              </table>

              <div>
                <p className="text-[10px] font-bold mb-1.5 uppercase">
                  {job.type === 'individu-pinjam' ? 'SENARAI BUKU TEKS YANG DIPINJAM / DITERIMA:' : 'SENARAI PEMULANGAN BUKU TEKS & CATATAN KEADAAN:'}
                </p>
                <table className="w-full border-collapse border border-black text-[10px] text-left">
                  <thead>
                    <tr className="bg-stone-100 font-bold">
                      <th className="border border-black p-2 w-10 text-center">BIL</th>
                      <th className="border border-black p-2 w-28">KOD BUKU</th>
                      <th className="border border-black p-2">JUDUL BUKU TEKS</th>
                      <th className="border border-black p-2 w-28 text-center">{job.type === 'individu-pinjam' ? 'TARIKH TERIMA' : 'TARIKH PULANG'}</th>
                      <th className="border border-black p-2 w-28 text-center">{job.type === 'individu-pinjam' ? 'TANDATANGAN AKUAN' : 'STATUS'}</th>
                    </tr>
                  </thead>
                  <tbody>
                    {yearBooks.map((book, idx) => {
                      const matchedLoan = singlePupilLoans.find(l => l.bookId === book.id);
                      if (job.type === 'individu-pinjam') {
                        const isLent = matchedLoan?.status === 'Dipinjam';
                        return (
                          <tr key={book.id}>
                            <td className="border border-black p-1.5 text-center">{idx + 1}</td>
                            <td className="border border-black p-1.5">{book.id}</td>
                            <td className="border border-black p-1.5">{book.title}</td>
                            <td className="border border-black p-1.5 text-center">{isLent ? (matchedLoan?.lendDate || '-') : '-'}</td>
                            <td className="border border-black p-1.5 text-center font-bold text-stone-400">
                              {isLent ? '___________________' : 'Tidak Dipinjam'}
                            </td>
                          </tr>
                        );
                      } else {
                        const isReturned = matchedLoan && ['Dipulangkan', 'Rosak', 'Hilang'].includes(matchedLoan.status);
                        return (
                          <tr key={book.id}>
                            <td className="border border-black p-1.5 text-center">{idx + 1}</td>
                            <td className="border border-black p-1.5">{book.id}</td>
                            <td className="border border-black p-1.5">{book.title}</td>
                            <td className="border border-black p-1.5 text-center">{isReturned ? (matchedLoan?.returnDate || '-') : '-'}</td>
                            <td className="border border-black p-1.5 text-center font-bold">
                              {isReturned ? matchedLoan.status : 'Belum Pulang'}
                            </td>
                          </tr>
                        );
                      }
                    })}
                  </tbody>
                </table>
              </div>

              <p className="text-[10px] leading-relaxed border border-dashed border-stone-400 p-2.5 rounded">
                <strong>PENGAKUAN:</strong> Buku teks SPBT adalah peninggalan kerajaan yang mesti diselia rapi. Pelajar adalah komited menjaga buku dari sebarang contengan, keciciran, kelembapan, dan peminjaman haram kepada individu lain.
              </p>

              {/* Float double sign */}
              <div className="grid grid-cols-2 gap-8 pt-6">
                <div className="space-y-10">
                  <span className="block font-semibold">Tandatangan Murid,</span>
                  <div>
                    <p className="border-b border-black w-40"></p>
                    <p className="text-[10px] mt-1">Nama: {singlePupil.name}</p>
                    <p className="text-[10px]">Tarikh: ___________________</p>
                  </div>
                </div>

                <div className="space-y-10">
                  <span className="block font-semibold">Tandatangan Pengesahan Guru / Pengawas SPBT,</span>
                  <div>
                    <p className="border-b border-black w-40"></p>
                    <p className="text-[10px] mt-1">Nama Penerima: _______________________</p>
                    <p className="text-[10px]">Tarikh: ___________________________</p>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Bulk Print Jobs (landscape layout) */}
          {(job.type === 'pukal-pinjam' || job.type === 'pukal-pulang') && (
            <div className="space-y-4">
              <div className="text-center bg-stone-100 border border-stone-300 p-1.5 rounded">
                <h4 className="text-[11px] font-bold uppercase">
                  {job.type === 'pukal-pinjam' ? 'REKOD PENERIMAAN BUKU TEKS SPBT BERKELOMPOK (PUKAL KELAS)' : 'REKOD PEMULANGAN BUKU TEKS SPBT BERKELOMPOK (PUKAL KELAS)'}
                </h4>
              </div>

              <div className="flex justify-between font-mono font-bold text-[10px] border border-black p-2 rounded">
                <span>TAHUN: TAHUN {targetYear} {targetClass && `/ ${targetClass.toUpperCase()}`}</span>
                <span>JUMLAH: {targetPupils.length} ORANG</span>
                <span>TARIKH CETAK: {getTodayFormatted()}</span>
              </div>

              <table className="w-full border-collapse border border-black text-[9px] text-left">
                <thead>
                  <tr className="bg-stone-50 font-bold">
                    <th className="border border-black p-1 text-center w-8">BIL</th>
                    <th className="border border-black p-1">NAMA MURID</th>
                    <th className="border border-black p-1 w-12 text-center font-mono">KELAS</th>
                    {yearBooks.slice(0, 7).map(b => (
                      <th key={b.id} className="border border-black p-1 text-center w-16 truncate max-w-[65px]" title={b.title}>
                        {b.id}
                      </th>
                    ))}
                    <th className="border border-black p-1 w-24 text-center">TANDATANGAN MURID</th>
                  </tr>
                </thead>
                <tbody>
                  {targetPupils.map((pupil, idx) => {
                    const pupilLoans = loans.filter(l => l.pupilId === pupil.id && l.session === currentSession);
                    return (
                      <tr key={pupil.id}>
                        <td className="border border-black p-1 text-center">{idx + 1}</td>
                        <td className="border border-black p-1 font-bold uppercase">{pupil.name}</td>
                        <td className="border border-black p-1 text-center uppercase font-mono">{pupil.className}</td>
                        {yearBooks.slice(0, 7).map(b => {
                          const m = pupilLoans.find(l => l.bookId === b.id);
                          const isReturned = m && ['Dipulangkan', 'Rosak', 'Hilang'].includes(m.status);
                          if (job.type === 'pukal-pinjam') {
                            const isLent = m?.status === 'Dipinjam';
                            return (
                              <td key={b.id} className="border border-black p-1 text-center font-bold">
                                {isLent ? '✓' : '-'}
                              </td>
                            );
                          } else {
                            return (
                              <td key={b.id} className="border border-black p-1 text-center font-bold">
                                {isReturned ? (m.status === 'Dipulangkan' ? '✓' : m.status.substr(0,1)) : '-'}
                              </td>
                            );
                          }
                        })}
                        <td className="border border-black p-1 text-center text-[8px] text-stone-400">
                          {idx+1}. ________________
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>

              <div className="grid grid-cols-2 gap-8 pt-8 text-[10px]">
                <div className="space-y-8">
                  <p className="font-semibold">Disediakan oleh Ketua Pengawas SPBT,</p>
                  <div>
                    <p className="border-b border-black w-36"></p>
                    <p className="mt-1">Nama: _______________________</p>
                  </div>
                </div>

                <div className="space-y-8">
                  <p className="font-semibold">Disahkan oleh Penyelaras SPBT SK Felda Lui Muda,</p>
                  <div>
                    <p className="border-b border-black w-36"></p>
                    <p className="mt-1">Nama: _______________________</p>
                  </div>
                </div>
              </div>
            </div>
          )}

        </div>

      </div>

    </div>
  );
}
