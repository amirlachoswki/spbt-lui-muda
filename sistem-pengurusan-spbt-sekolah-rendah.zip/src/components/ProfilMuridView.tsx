import { Book, Pupil, Loan } from '../types';
import { 
  User, 
  MapPin, 
  Calendar, 
  Activity, 
  BookOpen, 
  CheckCircle, 
  XCircle, 
  AlertTriangle,
  ArrowLeft,
  Printer,
  BookMarked
} from 'lucide-react';

interface ProfilMuridViewProps {
  pupil: Pupil;
  books: Book[];
  loans: Loan[];
  currentSession: string;
  onBack: () => void;
}

export default function ProfilMuridView({ pupil, books, loans, currentSession, onBack }: ProfilMuridViewProps) {
  // Saring semua pinjaman khusus untuk murid ini sahaja
  const pupilLoans = loans.filter(l => l.pupilId === pupil.id);
  
  // Saring mengikut sesi aktif murid
  const activeLoans = pupilLoans.filter(l => l.session === pupil.session);

  // Hitung statistik murid
  const countLent = activeLoans.filter(l => l.status === 'Dipinjam').length;
  const countReturned = activeLoans.filter(l => l.status === 'Dipulangkan').length;
  const countLost = activeLoans.filter(l => l.status === 'Hilang').length;
  const countDamaged = activeLoans.filter(l => l.status === 'Rosak').length;

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="space-y-6 animate-fade-in">
      
      {/* Butang Kembali & Cetak */}
      <div className="flex justify-between items-center print:hidden">
        <button
          id="profil_kembali_btn"
          onClick={onBack}
          className="flex items-center gap-1.5 text-slate-500 hover:text-slate-900 dark:text-slate-400 dark:hover:text-white text-xs font-bold font-mono tracking-wider uppercase transition-colors cursor-pointer"
        >
          <ArrowLeft className="w-3.5 h-3.5" />
          <span>Kembali ke Senarai</span>
        </button>
        
        <button
          id="profil_cetak_btn"
          onClick={handlePrint}
          className="flex items-center gap-1.5 bg-slate-900 hover:bg-slate-800 dark:bg-emerald-950 dark:hover:bg-emerald-900 text-white dark:text-emerald-400 text-[10px] font-bold font-mono tracking-wider uppercase py-2 px-3.5 border border-slate-900 dark:border-emerald-800 rounded transition-all cursor-pointer shadow-xs"
        >
          <Printer className="w-3.5 h-3.5" />
          <span>Cetak Kad Profil SPBT</span>
        </button>
      </div>

      {/* Bahagian yang Dioptimumkan untuk Cetakan */}
      <div className="bg-white dark:bg-slate-900 border border-stone-200 dark:border-slate-800 rounded-xl p-6 sm:p-8 shadow-2xs space-y-8 print:border-none print:shadow-none print:p-0">
        
        {/* Kepala Profil */}
        <div className="flex flex-col sm:flex-row justify-between items-start border-b border-stone-150 dark:border-slate-850 pb-6 gap-4">
          <div className="flex items-start gap-4">
            <div className="p-3 bg-stone-50 dark:bg-slate-950 text-slate-800 dark:text-slate-300 rounded border border-stone-200 dark:border-slate-800">
              <User className="w-6 h-6" />
            </div>
            <div className="space-y-1">
              <span className="text-[9px] font-bold font-mono tracking-widest text-emerald-600 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-950/40 px-2 py-0.5 rounded uppercase">Profil Murid SPBT</span>
              <h2 className="text-xl sm:text-2xl font-sans font-bold text-slate-900 dark:text-white tracking-tight leading-none mt-1">{pupil.name}</h2>
              <p className="text-xs text-slate-500 dark:text-slate-400 font-sans mt-1">
                Sesi Persekolahan: <span className="font-mono font-bold text-slate-700 dark:text-slate-350">{pupil.session}</span> {pupil.isArchived && <span className="text-rose-600 font-mono font-bold"> (ARKIB)</span>}
              </p>
            </div>
          </div>

          <div className="flex flex-wrap gap-2 text-[10px] font-bold font-mono">
            <div className="bg-stone-50 dark:bg-slate-950 border border-stone-200 dark:border-slate-850 px-3 py-1.5 rounded flex items-center gap-1.5 text-slate-700 dark:text-slate-350 uppercase">
              <MapPin className="w-3.5 h-3.5 text-emerald-500" />
              <span>Tahun {pupil.year}</span>
            </div>
            <div className="bg-stone-50 dark:bg-slate-955 border border-stone-200 dark:border-slate-850 px-3 py-1.5 rounded flex items-center gap-1.5 text-slate-700 dark:text-slate-350 uppercase">
              <Calendar className="w-3.5 h-3.5 text-emerald-500" />
              <span>Kelas {pupil.className}</span>
            </div>
          </div>
        </div>

        {/* Ringkasan Statistik Buku Murid */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 font-sans">
          {/* Dipinjam */}
          <div className="bg-stone-50 dark:bg-slate-955/60 border border-stone-200 dark:border-slate-850 p-4.5 rounded-lg flex items-center gap-3">
            <span className="p-2 bg-amber-50 dark:bg-amber-955/20 text-amber-600 dark:text-amber-450 rounded">
              <BookOpen className="w-4 h-4" />
            </span>
            <div>
              <p className="text-[10px] font-bold tracking-wider text-slate-400 dark:text-slate-500 uppercase font-mono">Dipinjam</p>
              <h4 className="text-base font-bold font-mono text-slate-855 dark:text-white">{countLent} Buku</h4>
            </div>
          </div>

          {/* Dipulangkan */}
          <div className="bg-stone-50 dark:bg-slate-955/60 border border-stone-200 dark:border-slate-850 p-4.5 rounded-lg flex items-center gap-3">
            <span className="p-2 bg-emerald-50 dark:bg-emerald-955/20 text-emerald-600 dark:text-emerald-455 rounded">
              <CheckCircle className="w-4 h-4" />
            </span>
            <div>
              <p className="text-[10px] font-bold tracking-wider text-slate-400 dark:text-slate-500 uppercase font-mono">Dipulangkan</p>
              <h4 className="text-base font-bold font-mono text-slate-855 dark:text-white">{countReturned} Buku</h4>
            </div>
          </div>

          {/* Hilang */}
          <div className="bg-stone-50 dark:bg-slate-955/60 border border-stone-200 dark:border-slate-850 p-4.5 rounded-lg flex items-center gap-3">
            <span className="p-2 bg-rose-50 dark:bg-rose-955/20 text-rose-600 dark:text-rose-455 rounded">
              <XCircle className="w-4 h-4" />
            </span>
            <div>
              <p className="text-[10px] font-bold tracking-wider text-slate-400 dark:text-slate-500 uppercase font-mono">Hilang</p>
              <h4 className="text-base font-bold font-mono text-rose-600 dark:text-rose-455">{countLost} Buku</h4>
            </div>
          </div>

          {/* Rosak */}
          <div className="bg-stone-50 dark:bg-slate-955/60 border border-stone-200 dark:border-slate-850 p-4.5 rounded-lg flex items-center gap-3">
            <span className="p-2 bg-orange-50 dark:bg-orange-955/20 text-orange-600 dark:text-orange-455 rounded">
              <AlertTriangle className="w-4 h-4" />
            </span>
            <div>
              <p className="text-[10px] font-bold tracking-wider text-slate-400 dark:text-slate-500 uppercase font-mono">Rosak</p>
              <h4 className="text-base font-bold font-mono text-orange-600 dark:text-orange-455">{countDamaged} Buku</h4>
            </div>
          </div>
        </div>

        {/* Jadual Rekod Buku Lengkap untuk Skim Murid */}
        <div className="space-y-4">
          <div className="flex justify-between items-center border-b border-stone-150 dark:border-slate-850 pb-3">
            <h3 className="font-sans font-bold text-slate-900 dark:text-white text-base flex items-center gap-2">
              <BookMarked className="w-4 h-4 text-emerald-500" />
              Rekod Pengedaran & Pemulangan Buku Teks SPBT
            </h3>
            <span className="text-xs text-slate-400 font-mono">TAHUN {pupil.year}</span>
          </div>

          <div className="border border-stone-200 dark:border-slate-850 rounded-lg overflow-hidden shadow-3xs">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="bg-stone-50 dark:bg-slate-950 text-slate-550 dark:text-slate-400 text-[10px] uppercase font-bold tracking-wider border-b border-stone-200 dark:border-slate-855 font-mono">
                  <th className="px-6 py-3.5">Nama Buku Teks</th>
                  <th className="px-4 py-3.5">Tarikh Pinjam</th>
                  <th className="px-4 py-3.5">Tarikh Pulang</th>
                  <th className="px-6 py-3.5 text-right font-bold">Status Buku</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-stone-100 dark:divide-slate-800/60 bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-350">
                {books
                  .filter(b => b.year === pupil.year)
                  .map(book => {
                    // Cari pinjaman untuk murid & buku yang sedia ada
                    const loan = activeLoans.find(l => l.bookId === book.id);
                    const status = loan ? loan.status : 'Belum Dipinjam';

                    let statusStyle = 'bg-stone-100 dark:bg-slate-800 text-slate-650 dark:text-slate-400';
                    if (status === 'Dipinjam') {
                      statusStyle = 'bg-amber-50 dark:bg-amber-955/40 text-amber-700 dark:text-amber-450';
                    } else if (status === 'Dipulangkan') {
                      statusStyle = 'bg-emerald-50 dark:bg-emerald-955 text-emerald-700 dark:text-emerald-450';
                    } else if (status === 'Hilang') {
                      statusStyle = 'bg-rose-50 dark:bg-rose-955/40 text-rose-700 dark:text-rose-455';
                    } else if (status === 'Rosak') {
                      statusStyle = 'bg-orange-50 dark:bg-orange-955/40 text-orange-700 dark:text-orange-455';
                    }

                    return (
                      <tr key={book.id} className="hover:bg-stone-55/50 dark:hover:bg-slate-955/20 transition-colors">
                        <td className="px-6 py-4">
                          <p className="font-bold text-slate-900 dark:text-white leading-tight">{book.title}</p>
                          <p className="text-[10px] text-slate-400 dark:text-slate-500 font-mono tracking-wider mt-1">Siri Kod: {book.id}</p>
                        </td>
                        <td className="px-4 py-4 font-mono text-slate-550 dark:text-slate-400">
                          {loan?.lendDate || <span className="text-slate-300 dark:text-slate-700">—</span>}
                        </td>
                        <td className="px-4 py-4 font-mono text-slate-550 dark:text-slate-400">
                          {loan?.returnDate || <span className="text-slate-300 dark:text-slate-700">—</span>}
                        </td>
                        <td className="px-6 py-4 text-right">
                          <span className={`inline-block text-[10px] font-bold font-mono uppercase tracking-wider px-2 py-0.5 rounded ${statusStyle}`}>
                            {status}
                          </span>
                        </td>
                      </tr>
                    );
                  })}
              </tbody>
            </table>
          </div>
        </div>

        {/* Akuan Penerimaan Tandatangan (Untuk dicetak) */}
        <div className="hidden print:block pt-12 space-y-12">
          <p className="text-xs text-slate-500 italic leading-relaxed font-sans">
            * Adalah diakui bahawa senarai buku di atas telah diagih / dipulangkan berdasarkan rekod fizikal yang disemak secara bertulis oleh guru SPBT / Pengawas bertugas.
          </p>
          <div className="grid grid-cols-2 gap-12 pt-8">
            <div className="border-t border-stone-300 dark:border-slate-800 text-center pt-2 text-xs font-semibold text-slate-600 dark:text-slate-400 font-sans">
              Tandatangan Penerima (Murid)
            </div>
            <div className="border-t border-stone-300 dark:border-slate-800 text-center pt-2 text-xs font-semibold text-slate-600 dark:text-slate-400 font-sans">
              Tandatangan Guru SPBT / Wakil Pengawas
            </div>
          </div>
        </div>

      </div>
    </div>
  );
}
