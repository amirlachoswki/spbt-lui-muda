import { useState } from 'react';
import { Book, Pupil, Loan } from '../types';
import { Search, User, Gift, Check, Flame, HelpCircle, RefreshCw, Eye, BookOpen, Printer } from 'lucide-react';

interface PulangBukuProps {
  pupils: Pupil[];
  books: Book[];
  loans: Loan[];
  currentSession: string;
  onUpdateReturnStatus: (
    loanId: string, 
    status: 'Dipulangkan' | 'Hilang' | 'Rosak' | 'Dipinjam', 
    returnDate: string | null
  ) => void;
  onSelectPupil: (pupil: Pupil) => void;
  onPrintIndividu?: (pupilId: string) => void;
  onPrintPukal?: (year: number) => void;
}

export default function PulangBuku({
  pupils,
  books,
  loans,
  currentSession,
  onUpdateReturnStatus,
  onSelectPupil,
  onPrintIndividu,
  onPrintPukal
}: PulangBukuProps) {
  const [activeYear, setActiveYear] = useState<number>(1);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedPupilId, setSelectedPupilId] = useState<string | null>(null);

  // Active, non-archived pupils for the current session in the active year
  const activePupilsInYear = pupils.filter(p => !p.isArchived && p.session === currentSession && p.year === activeYear);

  // Search filter
  const filteredPupils = activePupilsInYear.filter(p => 
    p.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
    p.className.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const selectedPupil = pupils.find(p => p.id === selectedPupilId);

  // Get active loans for the selected pupil in the current session
  const pupilLoans = selectedPupil 
    ? loans.filter(l => l.pupilId === selectedPupil.id && l.session === currentSession) 
    : [];

  const getTodayDate = () => {
    const today = new Date();
    const offset = today.getTimezoneOffset();
    const localToday = new Date(today.getTime() - (offset * 60 * 1000));
    return localToday.toISOString().split('T')[0];
  };

  const handleStatusChange = (loanId: string, newStatus: 'Dipulangkan' | 'Hilang' | 'Rosak' | 'Dipinjam') => {
    const todayDate = ['Dipulangkan', 'Hilang', 'Rosak'].includes(newStatus) ? getTodayDate() : null;
    onUpdateReturnStatus(loanId, newStatus, todayDate);
  };

  return (
    <div className="space-y-6 animate-fade-in">
      
      {/* Tab Filter Tahun 1 - 6 - Gaya Editorial Klasik */}
      <div className="bg-white dark:bg-slate-900 border border-stone-200 dark:border-slate-800 p-1.5 rounded-xl shadow-2xs flex flex-wrap gap-1">
        {[1, 2, 3, 4, 5, 6].map((yr) => (
          <button
            key={yr}
            id={`pulang_tab_year_${yr}`}
            onClick={() => {
              setActiveYear(yr);
              setSelectedPupilId(null);
            }}
            className={`flex-1 min-w-[75px] py-2.5 px-3 rounded-lg text-xs font-sans font-bold transition-all cursor-pointer ${
              activeYear === yr
                ? 'bg-slate-900 text-white dark:bg-emerald-950 dark:text-emerald-400 border border-slate-900 dark:border-emerald-800 shadow-sm'
                : 'bg-transparent text-slate-650 dark:text-slate-400 hover:bg-stone-50 dark:hover:bg-slate-800/40'
            }`}
          >
            Tahun {yr}
          </button>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        
        {/* Kolum Kiri: Senarai Murid dalam Sesi dengan Gaya Editorial */}
        <div className="bg-white dark:bg-slate-900 border border-stone-200 dark:border-slate-800 rounded-xl shadow-2xs p-6 space-y-4 self-start">
          <div className="flex justify-between items-center border-b border-stone-100 dark:border-slate-800 pb-3">
            <div>
              <h3 className="font-sans font-bold text-slate-950 dark:text-white text-base">Senarai Pemulangan (T- {activeYear})</h3>
              <p className="text-[10px] text-slate-500 font-mono">SESI {currentSession}</p>
            </div>
            {onPrintPukal && (
              <button
                type="button"
                id="btn_print_pukal_pulang"
                onClick={() => onPrintPukal(activeYear)}
                className="flex items-center gap-1.5 px-2.5 py-1 bg-emerald-50 hover:bg-emerald-100/80 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-450 border border-emerald-100 dark:border-emerald-900 rounded-lg text-[10px] font-bold cursor-pointer transition-colors"
                title="Cetak Borang Akuan Pukal/Kelas Pemulangan untuk tanda tangan murid"
              >
                <Printer className="w-3.5 h-3.5" />
                <span>Cetak Pukal</span>
              </button>
            )}
          </div>

          <div className="relative">
            <Search className="w-3.5 h-3.5 absolute left-3 top-3 text-slate-400" />
            <input
              id="pulang_carian_pupil"
              type="text"
              placeholder="Cari murid / nama kelas..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-stone-50/50 dark:bg-slate-950 border border-stone-200 dark:border-slate-850 rounded-lg pl-9 pr-3 py-2 text-xs text-slate-950 dark:text-white focus:outline-none focus:border-slate-900 dark:focus:border-emerald-600 focus:bg-white transition-colors"
            />
          </div>

          <div className="divide-y divide-stone-100 dark:divide-slate-800/50 max-h-[380px] overflow-y-auto pr-1 space-y-1">
            {filteredPupils.length === 0 ? (
              <div className="py-8 text-center text-xs text-neutral-400 dark:text-neutral-500">
                Tiada murid berdaftar dalam Tahun {activeYear}.
              </div>
            ) : (
              filteredPupils.map((pupil) => {
                const isSelected = selectedPupilId === pupil.id;
                
                // Hitung jumlah pinjaman aktif yang masih berkategori 'Dipinjam'
                const loansAll = loans.filter(l => l.pupilId === pupil.id && l.session === currentSession);
                const pendingCount = loansAll.filter(l => l.status === 'Dipinjam').length;
                const totalLoansCount = loansAll.length;

                return (
                  <button
                    key={pupil.id}
                    id={`btn_pulang_pilih_murid_${pupil.id}`}
                    onClick={() => setSelectedPupilId(pupil.id)}
                    className={`w-full flex items-center justify-between p-3 rounded-xl text-left transition-all cursor-pointer ${
                      isSelected 
                        ? 'bg-emerald-600 text-white font-semibold' 
                        : 'hover:bg-neutral-50 dark:hover:bg-neutral-800/40 text-neutral-800 dark:text-neutral-300'
                    }`}
                  >
                    <div className="space-y-1">
                      <p className="text-xs font-bold leading-tight">{pupil.name}</p>
                      <p className={`text-[10px] ${isSelected ? 'text-emerald-100' : 'text-neutral-400'}`}>
                        Kelas: {pupil.className}
                      </p>
                    </div>
                    <div className="flex items-center gap-1.5">
                      {totalLoansCount === 0 ? (
                        <span className="text-[9px] bg-neutral-100 dark:bg-neutral-800 text-neutral-400 px-1.5 py-0.5 rounded font-bold">
                          Tiada Pinjaman
                        </span>
                      ) : pendingCount === 0 ? (
                        <span className="text-[9px] bg-emerald-500 text-white px-1.5 py-0.5 rounded font-bold">
                          Selesai
                        </span>
                      ) : (
                        <span className={`text-[9px] font-bold px-1.5 py-0.5 rounded ${
                          isSelected ? 'bg-emerald-700 text-white' : 'bg-red-50 dark:bg-red-950/40 text-red-600 dark:text-red-400'
                        }`}>
                          Baki {pendingCount}
                        </span>
                      )}
                    </div>
                  </button>
                );
              })
            )}
          </div>
        </div>

        {/* Kolum Kanan: Borang Mengurus Pulang/Hilang/Rosak - Gaya Panel Editorial */}
        <div className="lg:col-span-2 bg-white dark:bg-slate-900 border border-stone-200 dark:border-slate-800 rounded-xl shadow-2xs p-6 flex flex-col min-h-[400px]">
          {selectedPupil ? (
            <div className="space-y-6 flex-1 flex flex-col justify-between">
              
              {/* Profil Ringkas */}
              <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center bg-stone-50/50 dark:bg-slate-950 p-4 border border-stone-200/60 dark:border-slate-850 rounded-lg gap-3">
                <div className="flex items-center gap-3">
                  <div className="p-2.5 bg-slate-900 dark:bg-emerald-950 border border-slate-850 dark:border-emerald-800 text-white rounded-lg">
                    <User className="w-4 h-4 text-emerald-400" />
                  </div>
                  <div>
                    <h4 className="font-sans font-bold text-slate-900 dark:text-white text-base">{selectedPupil.name}</h4>
                    <p className="text-xs text-slate-500 dark:text-slate-400 font-mono">
                      TAHUN {selectedPupil.year} • KELAS {selectedPupil.className.toUpperCase()}
                    </p>
                  </div>
                </div>
                
                <div className="flex gap-1.5 self-end sm:self-auto">
                  <button
                    id="pulang_lihat_profil_btn"
                    onClick={() => onSelectPupil(selectedPupil)}
                    className="text-[10px] font-bold text-slate-900 dark:text-white hover:bg-stone-50 bg-white dark:bg-slate-800 px-3 py-1.5 border border-stone-200 dark:border-slate-700/80 rounded shadow-xs cursor-pointer uppercase tracking-wider font-mono"
                  >
                    Profil
                  </button>
                  {onPrintIndividu && (
                    <button
                      type="button"
                      id="pulang_print_individu_btn"
                      onClick={() => onPrintIndividu(selectedPupil.id)}
                      className="text-[10px] font-bold text-emerald-750 dark:text-emerald-400 hover:bg-emerald-100/30 bg-emerald-50 dark:bg-emerald-950/40 px-3 py-1.5 border border-emerald-100 dark:border-emerald-800/80 rounded shadow-xs cursor-pointer uppercase tracking-wider font-mono flex items-center gap-1.5"
                      title="Cetak Akuan Pemulangan Buku SPBT Murid ini"
                    >
                      <Printer className="w-3.5 h-3.5" />
                      <span>Cetak Slip</span>
                    </button>
                  )}
                </div>
              </div>

              {/* Senarai Buku Pinjam Yang Perlu Ditukar Status */}
              <div className="flex-1 space-y-4 animate-fade-in">
                <div className="flex justify-between items-center border-b border-stone-100 dark:border-slate-800/85 pb-2">
                  <h4 className="text-xs font-bold text-slate-900 dark:text-white flex items-center gap-1.5 uppercase tracking-widest font-mono">
                    <BookOpen className="w-4 h-4 text-emerald-500" />
                    Urus Status Pemulangan Buku ({pupilLoans.length} Tajuk)
                  </h4>
                  <span className="text-[10px] text-slate-400 dark:text-slate-550 font-mono">Auto-Kemaskini</span>
                </div>

                {pupilLoans.length === 0 ? (
                  <div className="p-12 text-center text-xs text-slate-400 dark:text-slate-500 border border-stone-200/60 dark:border-slate-850 rounded-lg bg-stone-50/50">
                    Tiada rekod pinjaman buku ditemui untuk murid ini bagi Sesi {currentSession}. Sila tandakan pinjaman murid dahulu di modul "Peminjaman Buku".
                  </div>
                ) : (
                  <div className="space-y-3">
                    {pupilLoans.map((loan) => {
                      const book = books.find(b => b.id === loan.bookId);
                      if (!book) return null;

                      return (
                        <div 
                          key={loan.id}
                          className="flex flex-col sm:flex-row justify-between items-start sm:items-center p-4 bg-white dark:bg-slate-950/40 border border-stone-200 dark:border-slate-850 rounded-lg gap-4"
                        >
                          <div className="space-y-1">
                            <span className="text-xs font-bold text-slate-900 dark:text-white block">{book.title}</span>
                            <div className="flex items-center gap-1.5 text-[9px] font-mono font-semibold text-slate-400">
                              <span>Kod: {book.id}</span>
                              <span>•</span>
                              <span>Dipinjam: {loan.lendDate || 'Tiada Tarikh'}</span>
                              {loan.returnDate && (
                                <>
                                  <span>•</span>
                                  <span>Tukar: {loan.returnDate}</span>
                                </>
                              )}
                            </div>
                          </div>

                          {/* Pilihan Status Pemulangan */}
                          <div className="flex flex-wrap items-center gap-1 bg-stone-50 dark:bg-slate-900 p-1 rounded-lg border border-stone-200 dark:border-slate-800 w-full sm:w-auto justify-stretch sm:justify-start">
                            {/* Dipulangkan */}
                            <button
                              id={`status_pulangkan_${loan.id}`}
                              onClick={() => handleStatusChange(loan.id, 'Dipulangkan')}
                              className={`flex-1 sm:flex-initial flex items-center justify-center gap-1 py-1.5 px-3 rounded text-[10px] font-mono uppercase tracking-wider font-bold transition-all cursor-pointer ${
                                loan.status === 'Dipulangkan'
                                  ? 'bg-slate-900 text-white dark:bg-emerald-950 dark:text-emerald-400 border border-slate-900 dark:border-emerald-800 shadow-2xs'
                                  : 'text-slate-650 dark:text-slate-450 hover:bg-stone-100 dark:hover:bg-slate-800'
                              }`}
                            >
                              <Check className="w-3 h-3" />
                              <span>Dipulangkan</span>
                            </button>

                            {/* Hilang */}
                            <button
                              id={`status_hilang_${loan.id}`}
                              onClick={() => handleStatusChange(loan.id, 'Hilang')}
                              className={`flex-1 sm:flex-initial flex items-center justify-center gap-1 py-1.5 px-3 rounded text-[10px] font-mono uppercase tracking-wider font-bold transition-all cursor-pointer ${
                                loan.status === 'Hilang'
                                  ? 'bg-rose-900 text-white border border-rose-950 shadow-2xs'
                                  : 'text-slate-650 dark:text-slate-450 hover:bg-stone-100 dark:hover:bg-slate-800'
                              }`}
                            >
                              <Flame className="w-3 h-3" />
                              <span>Hilang</span>
                            </button>

                            {/* Rosak */}
                            <button
                              id={`status_rosak_${loan.id}`}
                              onClick={() => handleStatusChange(loan.id, 'Rosak')}
                              className={`flex-1 sm:flex-initial flex items-center justify-center gap-1 py-1.5 px-3 rounded text-[10px] font-mono uppercase tracking-wider font-bold transition-all cursor-pointer ${
                                loan.status === 'Rosak'
                                  ? 'bg-amber-800 text-white border border-amber-900 shadow-2xs'
                                  : 'text-slate-650 dark:text-slate-450 hover:bg-stone-100 dark:hover:bg-slate-800'
                              }`}
                            >
                              <HelpCircle className="w-3 h-3" />
                              <span>Rosak</span>
                            </button>

                            {/* Reset to Dipinjam */}
                            {loan.status !== 'Dipinjam' && (
                              <button
                                id={`status_reset_${loan.id}`}
                                onClick={() => handleStatusChange(loan.id, 'Dipinjam')}
                                className="p-1 text-slate-400 hover:text-slate-900 dark:hover:text-slate-200 hover:bg-stone-200/50 dark:hover:bg-slate-800 rounded transition-colors cursor-pointer"
                                title="Reset kepada status Dipinjam"
                              >
                                <RefreshCw className="w-3 h-3 animate-spin-hover" />
                              </button>
                            )}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>

            </div>
          ) : (
            <div className="flex-1 flex flex-col items-center justify-center text-slate-400 dark:text-slate-550 p-12 space-y-4">
              <BookOpen className="w-10 h-10 text-stone-300 dark:text-slate-700" />
              <div className="text-center">
                <p className="text-sm font-sans font-bold text-slate-800 dark:text-slate-200">Pilih Murid Untuk Mengurus Pemulangan</p>
                <p className="text-[11px] text-slate-400 dark:text-slate-500 mt-1.5 max-w-sm leading-relaxed mx-auto">
                  Klik pada nama murid di kolum sebelah kiri mengikut senarai gred sasaran untuk mendaftar buku yang telah dipulangkan, hilang atau rosak secara berpusat.
                </p>
              </div>
            </div>
          )}
        </div>

      </div>
    </div>
  );
}
