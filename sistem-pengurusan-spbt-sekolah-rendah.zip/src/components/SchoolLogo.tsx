import React from 'react';

interface SchoolLogoProps {
  className?: string;
}

export default function SchoolLogo({ className = 'w-16 h-16' }: SchoolLogoProps) {
  return (
    <svg 
      className={`${className} select-none shrink-0`} 
      viewBox="0 0 100 100" 
      fill="none" 
      xmlns="http://www.w3.org/2000/svg"
      aria-hidden="true"
    >
      {/* Outer Shield Border (Luxury Gold/Bronze Gradient Accent) */}
      <path 
        d="M50 5 L85 20 V55 C85 75 50 93 50 93 C50 93 15 75 15 55 V20 L50 5 Z" 
        fill="#047857" /* Deep Emerald/Royal Green base */
        stroke="#EAB308" /* Gold border */
        strokeWidth="3.5" 
        strokeLinejoin="round"
      />
      
      {/* Inner Shield Area (Crisp White/Slate background) */}
      <path 
        d="M50 10 L80 23 V53 C80 69 50 86 50 86 C50 86 20 69 20 53 V23 L50 10 Z" 
        fill="#FFFFFF" 
      />

      {/* Blue Top Inset Banner */}
      <path 
        d="M50 10 L80 23 V32 L50 25 L20 32 V23 L50 10 Z" 
        fill="#1E3A8A" /* Royal Blue accent */
      />

      {/* Yellow/Gold Star of Excellence */}
      <polygon 
        points="50,14 53,20 60,20 55,24 57,30 50,26 43,30 45,24 40,20 47,20" 
        fill="#FACC15" 
      />

      {/* Open Book of Knowledge (Primary Education / SPBT) */}
      <path 
        d="M30 55 C37 49 47 49 50 52 C53 49 63 49 70 55 V42 C63 37 53 37 50 40 C47 37 37 37 30 42 V55 Z" 
        fill="#EAB308" 
        stroke="#1E293B"
        strokeWidth="1.2"
        strokeLinejoin="round"
      />
      
      {/* Center line page separator */}
      <path 
        d="M50 40 V52" 
        stroke="#1E293B" 
        strokeWidth="1.5" 
      />

      {/* Minimal Quill / Feather of Pen */}
      <path 
        d="M48 45 L52 41" 
        stroke="#FFFFFF" 
        strokeWidth="1.2" 
        strokeLinecap="round"
      />

      {/* Decorative Golden Stars in White Area */}
      <circle cx="28" cy="38" r="1.5" fill="#EAB308" />
      <circle cx="72" cy="38" r="1.5" fill="#EAB308" />
      
      {/* Ribbon with school banner "SKFLM" */}
      <path 
        d="M22 68 H78 L81 76 L75 74 L50 78 L25 74 L19 76 L22 68 Z" 
        fill="#1E3A8A" 
        stroke="#FACC15" 
        strokeWidth="1.2" 
        strokeLinejoin="round"
      />
      
      {/* "SKFLM" Text on Ribbon */}
      <text 
        x="50" 
        y="75" 
        fill="#FFFFFF" 
        fontSize="6.5" 
        fontWeight="bold" 
        textAnchor="middle" 
        fontFamily="ui-sans-serif, system-ui, -apple-system, sans-serif"
        letterSpacing="0.5"
      >
        SKFLM
      </text>
    </svg>
  );
}
