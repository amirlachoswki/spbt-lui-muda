import React, { useState } from 'react';
import { Book } from '../types';
import { BookOpen, BookMarked, Edit, Trash2, Plus, Check, X } from 'lucide-react';

interface UrusBukuProps {
  books: Book[];
  onAddBook: (title: string, year: number) => void;
  onEditBook: (id: string, title: string, year: number) => void;
  onDeleteBook: (id: string) => void;
}

export default function UrusBuku({ books, onAddBook, onEditBook, onDeleteBook }: UrusBukuProps) {
  const [activeTab, setActiveTab] = useState<number>(1); // Tahun 1 - 6

  // Form states to add
  const [newTitle, setNewTitle] = useState('');
  
  // Edit states
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editTitle, setEditTitle] = useState('');
  const [editYear, setEditYear] = useState<number>(1);

  // Delete confirm state
  const [deleteConfirmId, setDeleteConfirmId] = useState<string | null>(null);
  const [deleteConfirmTitle, setDeleteConfirmTitle] = useState<string>('');

  const filteredBooks = books.filter(b => b.year === activeTab);

  const handleAddSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim()) {
      alert('Sila isi tajuk buku teks!');
      return;
    }
    onAddBook(newTitle.trim(), activeTab);
    setNewTitle('');
  };

  const startEdit = (book: Book) => {
    setEditingId(book.id);
    setEditTitle(book.title);
    setEditYear(book.year);
  };

  const saveEdit = (id: string) => {
    if (!editTitle.trim()) {
      alert('Sila masukkan tajuk buku teks.');
      return;
    }
    onEditBook(id, editTitle.trim(), editYear);
    setEditingId(null);
  };

  const cancelEdit = () => {
    setEditingId(null);
  };

  const handleDelete = (id: string, title: string) => {
    setDeleteConfirmId(id);
    setDeleteConfirmTitle(title);
  };

  const years = [1, 2, 3, 4, 5, 6];

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 animate-fade-in font-sans">
      
      {/* Bahagian Tambah Buku */}
      <div className="bg-white dark:bg-slate-900 border border-stone-200 dark:border-slate-800 p-6 rounded-xl shadow-2xs self-start space-y-5">
        <div className="flex items-center gap-2 text-emerald-600 dark:text-emerald-450">
          <BookMarked className="w-5 h-5" />
          <h3 className="font-sans font-bold text-slate-900 dark:text-white text-base">Tambah Buku Teks</h3>
        </div>

        <form onSubmit={handleAddSubmit} className="space-y-4">
          <div>
            <label className="block text-[10px] font-bold tracking-wider text-slate-400 dark:text-slate-500 uppercase font-mono mb-2">Tahun Sasaran</label>
            <div className="bg-stone-50 dark:bg-slate-950 p-3 rounded border border-stone-250 dark:border-slate-850 font-bold font-mono text-xs text-slate-800 dark:text-slate-300 uppercase tracking-wider">
              Tahun {activeTab}
            </div>
          </div>

          <div>
            <label className="block text-[10px] font-bold tracking-wider text-slate-400 dark:text-slate-500 uppercase font-mono mb-2">Tajuk Buku Teks</label>
            <input
              id="urus_buku_tajuk_input"
              type="text"
              required
              placeholder="Contoh: Sains Tahun SK"
              value={newTitle}
              onChange={(e) => setNewTitle(e.target.value)}
              className="w-full bg-stone-50/50 dark:bg-slate-955 border border-stone-200 dark:border-slate-850 rounded-lg px-3.5 py-2.5 text-xs text-slate-900 dark:text-white focus:outline-none focus:border-slate-900 dark:focus:border-emerald-600 focus:bg-white transition-all"
            />
          </div>

          <button
            id="urus_buku_submit"
            type="submit"
            className="w-full bg-slate-900 hover:bg-slate-850 dark:bg-emerald-950 dark:hover:bg-emerald-900 text-white dark:text-emerald-400 font-bold text-[10px] font-mono tracking-wider uppercase py-3 px-4 rounded border border-slate-900 dark:border-emerald-800 transition-all cursor-pointer flex items-center justify-center gap-2 shadow-xs"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Tambah Buku (Tahun {activeTab})</span>
          </button>
        </form>

        <div className="p-4 bg-stone-50 dark:bg-slate-955/65 border border-stone-200 dark:border-slate-850 rounded-lg text-[11px] text-slate-500 dark:text-slate-400 leading-normal">
          📖 Buku teks yang didaftarkan bagi <strong className="text-slate-700 dark:text-slate-350">Tahun {activeTab}</strong> akan dipaparkan secara automatik bagi setiap murid Tahun {activeTab} semasa proses peminjaman.
        </div>
      </div>

      {/* Bahagian Editor & Senarai mengikut Tahun */}
      <div className="lg:col-span-2 space-y-6">
        
        {/* Tab Tahun 1 - 6 */}
        <div className="bg-white dark:bg-slate-900 border border-stone-200 dark:border-slate-800 p-2 rounded-xl shadow-2xs flex flex-wrap gap-1 font-mono">
          {years.map((yearNum) => (
            <button
              key={yearNum}
              id={`tab_tahun_${yearNum}`}
              onClick={() => {
                setActiveTab(yearNum);
                cancelEdit();
              }}
              className={`flex-1 min-w-[70px] py-2 px-2.5 rounded text-[10px] font-bold uppercase tracking-wider transition-all cursor-pointer ${
                activeTab === yearNum
                  ? 'bg-slate-900 dark:bg-emerald-950 text-white dark:text-emerald-400 font-bold shadow-xs'
                  : 'bg-transparent text-slate-500 dark:text-slate-400 hover:bg-stone-55 dark:hover:bg-slate-850/60'
              }`}
            >
              Thn {yearNum}
            </button>
          ))}
        </div>

        {/* Senarai Buku bagi Tahun dipilh */}
        <div className="bg-white dark:bg-slate-900 border border-stone-200 dark:border-slate-800 rounded-xl overflow-hidden shadow-2xs">
          <div className="p-4.5 border-b border-stone-150 dark:border-slate-850 bg-stone-50 dark:bg-slate-950 flex justify-between items-center">
            <h4 className="font-sans font-bold text-slate-900 dark:text-white text-sm">
              Senarai Buku SPBT: Tahun {activeTab} ({filteredBooks.length} tajuk)
            </h4>
          </div>

          {filteredBooks.length === 0 ? (
            <div className="p-16 text-center text-slate-400 dark:text-slate-500 space-y-3">
              <BookOpen className="w-8 h-8 mx-auto text-stone-300 dark:text-slate-750" />
              <p className="text-xs font-sans text-slate-500">Tiada buku teks berdaftar bagi Tahun {activeTab}.</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs border-collapse font-sans">
                <thead>
                  <tr className="bg-stone-50 dark:bg-slate-950 text-slate-550 dark:text-slate-400 text-[10px] uppercase font-bold tracking-wider border-b border-stone-200 dark:border-slate-855 font-mono">
                    <th className="px-6 py-3.5 font-bold w-1/4">Kod Buku</th>
                    <th className="px-6 py-3.5 font-bold">Tajuk Buku Teks</th>
                    {editingId && <th className="px-4 py-3.5 font-bold w-1/6">Tahun</th>}
                    <th className="px-6 py-3.5 font-bold text-right w-1/4">Tindakan</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-stone-100 dark:divide-slate-800/60 bg-white dark:bg-slate-900 text-slate-750 dark:text-slate-350">
                  {filteredBooks.map((book) => {
                    const isEditing = editingId === book.id;

                    return (
                      <tr 
                        key={book.id} 
                        className="hover:bg-stone-55/40 dark:hover:bg-slate-955/20 transition-colors"
                      >
                        <td className="px-6 py-4 font-mono text-xs text-slate-500 dark:text-slate-400 font-bold">
                          {book.id}
                        </td>
                        
                        <td className="px-6 py-4">
                          {isEditing ? (
                            <input
                              type="text"
                              value={editTitle}
                              onChange={(e) => setEditTitle(e.target.value)}
                              className="w-full bg-white dark:bg-slate-955 border border-stone-300 dark:border-slate-750 px-3 py-1.5 rounded text-xs text-slate-900 dark:text-white focus:outline-none focus:border-slate-900 dark:focus:border-emerald-650"
                            />
                          ) : (
                            <span className="font-bold text-slate-900 dark:text-white">{book.title}</span>
                          )}
                        </td>

                        {isEditing && (
                          <td className="px-4 py-4 font-mono text-xs">
                            <select
                              value={editYear}
                              onChange={(e) => setEditYear(parseInt(e.target.value))}
                              className="bg-white dark:bg-slate-955 border border-stone-350 dark:border-slate-750 px-2 py-1 rounded text-xs text-slate-900 dark:text-white font-mono"
                            >
                              {[1, 2, 3, 4, 5, 6].map(yr => (
                                <option key={yr} value={yr}>Thn {yr}</option>
                              ))}
                            </select>
                          </td>
                        )}

                        <td className="px-6 py-4 text-right">
                          <div className="flex gap-2 justify-end">
                            {isEditing ? (
                              <>
                                <button
                                  onClick={() => saveEdit(book.id)}
                                  className="p-1.5 bg-emerald-50 text-emerald-600 dark:bg-emerald-950/40 dark:text-emerald-400 hover:bg-emerald-100 rounded transition-colors cursor-pointer"
                                  title="Simpan"
                                >
                                  <Check className="w-3.5 h-3.5" />
                                </button>
                                <button
                                  onClick={cancelEdit}
                                  className="p-1.5 bg-stone-105 text-slate-500 dark:bg-slate-800 dark:text-slate-400 hover:bg-stone-200 rounded transition-colors cursor-pointer"
                                  title="Batal"
                                >
                                  <X className="w-3.5 h-3.5" />
                                </button>
                              </>
                            ) : (
                              <>
                                <button
                                  onClick={() => startEdit(book)}
                                  className="p-1.5 bg-stone-50 text-slate-650 dark:bg-slate-800 dark:text-slate-350 hover:bg-stone-200 dark:hover:bg-slate-750 rounded transition-colors cursor-pointer"
                                  title="Ubah Tajuk"
                                >
                                  <Edit className="w-3.5 h-3.5" />
                                </button>
                                <button
                                  onClick={() => handleDelete(book.id, book.title)}
                                  className="p-1.5 bg-rose-50 text-rose-600 dark:bg-rose-955/20 dark:text-rose-455 hover:bg-rose-100 dark:hover:bg-rose-950/60 rounded transition-colors cursor-pointer"
                                  title="Padam"
                                >
                                  <Trash2 className="w-3.5 h-3.5" />
                                </button>
                              </>
                            )}
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>

      {/* Model Overlay Padam Buku Kastam */}
      {deleteConfirmId && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-fade-in">
          <div className="bg-white dark:bg-slate-900 rounded-xl p-6 max-w-sm w-full border border-stone-200 dark:border-slate-800 shadow-xl space-y-4">
            <div className="flex items-center gap-2.5 text-rose-600 dark:text-rose-400">
              <Trash2 className="w-5 h-5" />
              <h3 className="text-base font-sans font-bold text-slate-900 dark:text-white">
                Padam Buku Teks?
              </h3>
            </div>
            <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed">
              Adakah anda pasti untuk memadam buku teks <strong className="text-slate-800 dark:text-slate-200">"{deleteConfirmTitle}"</strong>? 
              Sebarang rekod pinjaman aktif berkaitan buku ini akan terjejas.
            </p>
            <div className="flex justify-end gap-2.5 pt-2">
              <button
                type="button"
                id="btn_cancel_delete_book"
                onClick={() => {
                  setDeleteConfirmId(null);
                  setDeleteConfirmTitle('');
                }}
                className="px-3.5 py-2 text-xs font-bold text-slate-700 dark:text-slate-300 bg-stone-100 hover:bg-stone-200 dark:bg-slate-800 dark:hover:bg-slate-755 rounded-lg cursor-pointer transition-colors"
              >
                Batal
              </button>
              <button
                type="button"
                id="btn_confirm_delete_book"
                onClick={() => {
                  onDeleteBook(deleteConfirmId);
                  setDeleteConfirmId(null);
                  setDeleteConfirmTitle('');
                }}
                className="px-3.5 py-2 text-xs font-bold text-white bg-rose-600 hover:bg-rose-700 rounded-lg cursor-pointer transition-colors"
              >
                Ya, Padam
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
}
