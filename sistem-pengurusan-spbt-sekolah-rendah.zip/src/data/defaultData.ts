import { Book, Pupil, Loan, UserAccount } from '../types';

export const defaultBooks: Book[] = [
  // Tahun 1
  { id: 'B1-01', title: 'Bahasa Melayu Tahun 1 SK', year: 1 },
  { id: 'B1-02', title: 'English Year 1 (Super Minds)', year: 1 },
  { id: 'B1-03', title: 'Matematik Jilid 1 Tahun 1 SK', year: 1 },
  { id: 'B1-04', title: 'Matematik Jilid 2 Tahun 1 SK', year: 1 },
  { id: 'B1-05', title: 'Sains Tahun 1 SK', year: 1 },
  { id: 'B1-06', title: 'Pendidikan Islam Tahun 1 SK', year: 1 },
  { id: 'B1-07', title: 'Pendidikan Seni Visual Tahun 1', year: 1 },

  // Tahun 2
  { id: 'B2-01', title: 'Bahasa Melayu Tahun 2 SK', year: 2 },
  { id: 'B2-02', title: 'English Year 2 SK', year: 2 },
  { id: 'B2-03', title: 'Matematik Jilid 1 Tahun 2 SK', year: 2 },
  { id: 'B2-04', title: 'Matematik Jilid 2 Tahun 2 SK', year: 2 },
  { id: 'B2-05', title: 'Sains Tahun 2 SK', year: 2 },
  { id: 'B2-06', title: 'Pendidikan Islam Tahun 2 SK', year: 2 },
  { id: 'B2-07', title: 'Pendidikan Muzik Tahun 2', year: 2 },

  // Tahun 3
  { id: 'B3-01', title: 'Bahasa Melayu Tahun 3 SK', year: 3 },
  { id: 'B3-02', title: 'English Year 3 SK', year: 3 },
  { id: 'B3-03', title: 'Matematik Jilid 1 Tahun 3 SK', year: 3 },
  { id: 'B3-04', title: 'Matematik Jilid 2 Tahun 3 SK', year: 3 },
  { id: 'B3-05', title: 'Sains Tahun 3 SK', year: 3 },
  { id: 'B3-06', title: 'Pendidikan Islam Tahun 3 SK', year: 3 },

  // Tahun 4
  { id: 'B4-01', title: 'Bahasa Melayu Tahun 4 SK', year: 4 },
  { id: 'B4-02', title: 'English Year 4 SK (Get Smart Plus)', year: 4 },
  { id: 'B4-03', title: 'Matematik Tahun 4 SK', year: 4 },
  { id: 'B4-04', title: 'Sains Tahun 4 SK', year: 4 },
  { id: 'B4-05', title: 'Sejarah Tahun 4 SK', year: 4 },
  { id: 'B4-06', title: 'Reka Bentuk & Teknologi Tahun 4 SK', year: 4 },
  { id: 'B4-07', title: 'Pendidikan Islam Tahun 4 SK', year: 4 },

  // Tahun 5
  { id: 'B5-01', title: 'Bahasa Melayu Tahun 5 SK', year: 5 },
  { id: 'B5-02', title: 'English Year 5 SK', year: 5 },
  { id: 'B5-03', title: 'Matematik Tahun 5 SK', year: 5 },
  { id: 'B5-04', title: 'Sains Tahun 5 SK', year: 5 },
  { id: 'B5-05', title: 'Sejarah Tahun 5 SK', year: 5 },
  { id: 'B5-06', title: 'Reka Bentuk & Teknologi Tahun 5 SK', year: 5 },
  { id: 'B5-07', title: 'Pendidikan Islam Tahun 5 SK', year: 5 },

  // Tahun 6
  { id: 'B6-01', title: 'Bahasa Melayu Tahun 6 SK', year: 6 },
  { id: 'B6-02', title: 'English Year 6 SK', year: 6 },
  { id: 'B6-03', title: 'Matematik Tahun 6 SK', year: 6 },
  { id: 'B6-04', title: 'Sains Tahun 6 SK', year: 6 },
  { id: 'B6-05', title: 'Sejarah Tahun 6 SK', year: 6 },
  { id: 'B6-06', title: 'Reka Bentuk & Teknologi Tahun 6 SK', year: 6 },
  { id: 'B6-07', title: 'Pendidikan Islam Tahun 6 SK', year: 6 },
];

export const defaultPupils: Pupil[] = [];

export const defaultLoans: Loan[] = [];

export const defaultUsers: UserAccount[] = [
  { id: 'U-01', username: 'admin', name: 'Cikgu Penyelaras', role: 'Guru Penyelaras', password: 'admin123' },
  { id: 'U-02', username: 'pengawas', name: 'Ketua Pengawas SPBT', role: 'Pengawas SPBT', password: 'pengawas123' }
];
