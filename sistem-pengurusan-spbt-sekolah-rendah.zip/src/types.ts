export type BookStatus = 'Belum Dipinjam' | 'Dipinjam' | 'Dipulangkan' | 'Hilang' | 'Rosak';

export interface Book {
  id: string; // Unique book ID (e.g., standard code or UUID)
  title: string;
  year: number; // 1 to 6
}

export interface Pupil {
  id: string;
  name: string;
  year: number; // 1 to 6
  className: string; // e.g., "Amanah", "Bestari"
  session: string; // e.g., "2026"
  isArchived: boolean;
  archiveSession?: string; // Sesi di mana dia diasinkan / diarkibkan
}

export interface Loan {
  id: string;
  pupilId: string;
  bookId: string;
  lendDate: string | null; // Date as ISO string or local date
  returnDate: string | null;
  status: BookStatus;
  session: string; // The academic year session for this loan
}

export interface UserAccount {
  id: string;
  username: string;
  name: string;
  role: 'Guru Penyelaras' | 'Pengawas SPBT';
  password: string;
}

export interface SystemData {
  books: Book[];
  pupils: Pupil[];
  loans: Loan[];
  currentSession: string;
  users?: UserAccount[];
}
