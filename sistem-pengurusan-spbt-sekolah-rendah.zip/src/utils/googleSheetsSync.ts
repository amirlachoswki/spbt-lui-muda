import { SystemData } from '../types';

export const APPS_SCRIPT_TEMPLATE = `/*
  ==============================================================
  SKRIP SEGERAK GOOGLE SHEETS (SISTEM SPBT SEKOLAH RENDAH)
  ==============================================================
  Sila ikuti langkah di bawah untuk menggunakan Google Sheets sebagai Database:

  1. Buka Google Sheets baharu.
  2. Di menu atas, klik "Extensions" (Sambungan) > "Apps Script".
  3. Padam sebarang kod sedia ada, dan tampalkan KESELURUHAN kod di bawah ini.
  4. Klik ikon Save (Disket) untuk menyimpan fail.
  5. Klik butang biru "Deploy" (Atur Sedia) di kanan atas > Pilih "New deployment".
  6. Klik ikon gear (di sebelah "Select type") > Pilih "Web app".
  7. Konfigurasikan tetapan berikut:
     - Description: SPBT Database Sync
     - Execute as: "Me" (E-mel delima / akaun anda)
     - Who has access: "Anyone" (SANGAT PENTING - untuk membolehkan web SPBT menulis data)
  8. Klik "Deploy". 
  9. Benarkan akses sekiranya didesak oleh Google (pilih "Advanced" > "Go to Untitled project (unsafe)" jika amaran keselamatan dipaparkan).
  10. Salin "Web app URL" yang tertera (contohnya bermula dengan https://script.google.com/macros/s/...)
  11. Tampalkan URL tersebut ke dalam kotak sambungan Sistem SPBT di pelayar web anda.
*/

function doGet(e) {
  var action = e.parameter.action;
  var sheet = SpreadsheetApp.getActiveSpreadsheet();
  
  // Set CORS headers
  var output = "";
  
  if (action === "getData") {
    var data = {};
    
    // Ambil data Buku
    var sheetBuku = sheet.getSheetByName("Buku") || createBukuSheet(sheet);
    data.books = getSheetRowsAsJson(sheetBuku);
    
    // Ambil data Murid
    var sheetMurid = sheet.getSheetByName("Murid") || createMuridSheet(sheet);
    data.pupils = getSheetRowsAsJson(sheetMurid);
    
    // Ambil data Pinjaman
    var sheetRekod = sheet.getSheetByName("Rekod_Pinjaman") || createRekodSheet(sheet);
    data.loans = getSheetRowsAsJson(sheetRekod);
    
    // Ambil data Sesi Semasa
    var sheetSesi = sheet.getSheetByName("Sesi") || createSesiSheet(sheet);
    var sesiRows = getSheetRowsAsJson(sheetSesi);
    data.currentSession = sesiRows.length > 0 ? sesiRows[0].currentSession : "2026";
    
    output = JSON.stringify({ status: "success", data: data });
  } else {
    output = JSON.stringify({ status: "error", message: "Tindakan 'action' tidak sah atau kosong." });
  }
  
  return ContentService.createTextOutput(output)
    .setMimeType(ContentService.MimeType.JSON);
}

function doPost(e) {
  try {
    var postData = JSON.parse(e.postData.contents);
    var sheet = SpreadsheetApp.getActiveSpreadsheet();
    
    if (postData.books) {
      var sheetBuku = sheet.getSheetByName("Buku") || createBukuSheet(sheet);
      writeJsonToSheet(sheetBuku, postData.books, ["id", "title", "year"]);
    }
    
    if (postData.pupils) {
      var sheetMurid = sheet.getSheetByName("Murid") || createMuridSheet(sheet);
      writeJsonToSheet(sheetMurid, postData.pupils, ["id", "name", "year", "className", "session", "isArchived", "archiveSession"]);
    }
    
    if (postData.loans) {
      var sheetRekod = sheet.getSheetByName("Rekod_Pinjaman") || createRekodSheet(sheet);
      writeJsonToSheet(sheetRekod, postData.loans, ["id", "pupilId", "bookId", "lendDate", "returnDate", "status", "session"]);
    }
    
    if (postData.currentSession) {
      var sheetSesi = sheet.getSheetByName("Sesi") || createSesiSheet(sheet);
      writeJsonToSheet(sheetSesi, [{ currentSession: postData.currentSession }], ["currentSession"]);
    }
    
    return ContentService.createTextOutput(JSON.stringify({ status: "success", message: "Data berjaya diselaraskan di Google Sheets secara masa nyata!" }))
      .setMimeType(ContentService.MimeType.JSON);
  } catch (error) {
    return ContentService.createTextOutput(JSON.stringify({ status: "error", message: error.toString() }))
      .setMimeType(ContentService.MimeType.JSON);
  }
}

// Fungsi Penciptaan Lembaran Kerja jika tiada
function createBukuSheet(sheet) {
  var s = sheet.insertSheet("Buku");
  s.appendRow(["id", "title", "year"]);
  return s;
}

function createMuridSheet(sheet) {
  var s = sheet.insertSheet("Murid");
  s.appendRow(["id", "name", "year", "className", "session", "isArchived", "archiveSession"]);
  return s;
}

function createRekodSheet(sheet) {
  var s = sheet.insertSheet("Rekod_Pinjaman");
  s.appendRow(["id", "pupilId", "bookId", "lendDate", "returnDate", "status", "session"]);
  return s;
}

function createSesiSheet(sheet) {
  var s = sheet.insertSheet("Sesi");
  s.appendRow(["currentSession"]);
  return s;
}

// Menukar Rekod Sheet kepada JSON
function getSheetRowsAsJson(sheet) {
  var range = sheet.getDataRange();
  var values = range.getValues();
  if (values.length <= 1) return [];
  
  var headers = values[0];
  var rows = [];
  
  for (var i = 1; i < values.length; i++) {
    var row = {};
    for (var j = 0; j < headers.length; j++) {
      var headerVal = headers[j];
      var cellVal = values[i][j];
      
      // Mengurus jenis penukaran khas
      if (headerVal === "year" && cellVal !== "") {
        row[headerVal] = parseInt(cellVal);
      } else if (headerVal === "isArchived") {
        row[headerVal] = cellVal === true || cellVal === "true";
      } else if (cellVal === "" || cellVal === undefined) {
        row[headerVal] = null;
      } else {
        row[headerVal] = cellVal;
      }
    }
    rows.push(row);
  }
  return rows;
}

// Menulis JSON kembali ke tab di Google Sheet
function writeJsonToSheet(sheet, dataArray, keys) {
  sheet.clear();
  sheet.appendRow(keys);
  
  if (dataArray.length === 0) return;
  
  var rowsToWrite = [];
  for (var i = 0; i < dataArray.length; i++) {
    var item = dataArray[i];
    var row = [];
    for (var j = 0; j < keys.length; j++) {
      var key = keys[j];
      var val = item[key];
      if (val === undefined || val === null) {
        row.push("");
      } else {
        row.push(val);
      }
    }
    rowsToWrite.push(row);
  }
  
  sheet.getRange(2, 1, rowsToWrite.length, keys.length).setValues(rowsToWrite);
}
`;

/**
 * Memuatkan data daripada Google Apps Script Web App
 */
export async function fetchFromGoogleSheet(url: string): Promise<SystemData | null> {
  try {
    const fetchUrl = `${url}${url.includes('?') ? '&' : '?'}action=getData`;
    const response = await fetch(fetchUrl, {
      method: 'GET',
      headers: {
        'Accept': 'application/json',
      },
      mode: 'cors',
    });
    
    if (!response.ok) {
      throw new Error(`HTTP Error: ${response.status}`);
    }
    
    const result = await response.json();
    if (result.status === 'success' && result.data) {
      return result.data as SystemData;
    } else {
      throw new Error(result.message || 'Ralat tidak diketahui daripada server Sheets');
    }
  } catch (error) {
    console.error('Ralat menarik data daripada Google Sheets:', error);
    throw error;
  }
}

/**
 * Menghantar (sinkroni) seluruh data ke Google Sheets
 */
export async function pushToGoogleSheet(url: string, data: SystemData): Promise<boolean> {
  try {
    const response = await fetch(url, {
      method: 'POST',
      headers: {
        'Content-Type': 'text/plain', // Mengelakkan preflight OPTIONS request untuk Apps Script
      },
      body: JSON.stringify(data),
      mode: 'cors',
    });
    
    if (!response.ok) {
      throw new Error(`HTTP Error: ${response.status}`);
    }
    
    const result = await response.json();
    return result.status === 'success';
  } catch (error) {
    console.error('Ralat menghantar data ke Google Sheets:', error);
    return false;
  }
}
